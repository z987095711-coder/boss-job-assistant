"""Offline verification and reproducible source ZIP. Does not open a browser or send messages."""
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT.parent / "releases"
NODE = shutil.which("node")
assert NODE, "Node is required for offline checks"

run = subprocess.run([NODE, "--test", *map(str, sorted((ROOT / "tests").glob("*.test.cjs")))],
                     cwd=ROOT, capture_output=True, text=True, timeout=60)
(ROOT / "tests/node-results.txt").write_text(run.stdout + run.stderr, encoding="utf-8")
print("\n".join(run.stdout.splitlines()[-12:]))
if run.returncode:
    print(run.stderr)
    raise SystemExit(run.returncode)

checks = []
for path in sorted((ROOT / "extension").iterdir()):
    if path.suffix in (".js", ".mjs"):
        subprocess.run([NODE, "--check", str(path)], check=True, capture_output=True, text=True)
        checks.append("PASS syntax " + str(path.relative_to(ROOT)))

manifest = json.loads((ROOT / "extension/manifest.json").read_text())
package = json.loads((ROOT / "package.json").read_text())
version = manifest["version"]
assert version == package["version"]
assert "const VERSION = '" + version + "'" in (ROOT / "extension/core.js").read_text()
display_version = manifest.get("version_name", "v" + version)
assert display_version in (ROOT / "extension/panel.html").read_text()
assert display_version in (ROOT / "START_HERE.html").read_text()
checks.append("PASS release version " + version)

class HTMLIDs(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
    def handle_starttag(self, tag, attrs):
        self.ids.extend(value for name, value in attrs if name == "id")

html = HTMLIDs()
html.feed((ROOT / "extension/panel.html").read_text())
assert len(html.ids) == len(set(html.ids)), "Duplicate panel IDs"
js = (ROOT / "extension/panel.js").read_text() + (ROOT / "extension/branding.js").read_text()
referenced = set(re.findall(r"\$\(['\"]([^'\"]+)['\"]\)", js))
referenced.update(re.findall(r"bind\(['\"]([^'\"]+)['\"]\s*,", js))
assert not referenced - set(html.ids), "Missing panel IDs: " + str(referenced - set(html.ids))
checks.append("PASS " + str(len(referenced)) + " referenced panel controls and unique IDs")

for size, relative in manifest["icons"].items():
    data = (ROOT / "extension" / relative).read_bytes()
    assert data[:8] == b"\x89PNG\r\n\x1a\n"
    assert struct.unpack(">II", data[16:24]) == (int(size), int(size))
    assert manifest["action"]["default_icon"][size] == relative
    checks.append("PASS icon " + size + "x" + size)
refs = [manifest["background"]["service_worker"], manifest["side_panel"]["default_path"], manifest["options_page"]]
for entry in manifest["content_scripts"]:
    refs.extend(entry["js"])
assert all((ROOT / "extension" / name).is_file() for name in refs)
checks.append("PASS manifest references")
(ROOT / "tests/syntax-results.txt").write_text("\n".join(checks) + "\n", encoding="utf-8")
print("\n".join(checks))

excluded = {"ui-desktop.png", "ui-sidepanel.png", "browser-results.json", "ui-results.json",
            "revision-browser-results.json", "ui-preview.html", "ui-preview-mock.js"}
OUT.mkdir(parents=True, exist_ok=True)
target = OUT / ("social-edge-bot-" + display_version + ".zip")
with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if not path.is_file() or path.name in excluded or "__pycache__" in relative.parts:
            continue
        if any(part.startswith(".") for part in relative.parts):
            continue
        archive.write(path, "social-edge-bot-" + display_version + "/" + relative.as_posix())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert not any(Path(name).name in excluded for name in archive.namelist())
    print("ZIP entries:", len(archive.namelist()))
print("ZIP:", target)
print("Bytes:", target.stat().st_size)
print("SHA256:", hashlib.sha256(target.read_bytes()).hexdigest())
