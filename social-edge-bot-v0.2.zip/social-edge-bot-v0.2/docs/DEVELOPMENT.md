# v0.2 开发补充

## 连续模式状态机

投递边界 `finishOutreach` → `startManagedReply` → `robot_entry` → `robot_watch` → `robot_open` → `robot_read` → `robot_execute` → `robot_watch`。单一 worker mutex 和持久化 mutate 链继续承担全部写操作；观察者只入队。

连续模式不使用有限批次的 r.order 作为监听白名单。列表变化携带稳定会话键、摘要 token 和未读／最后发言方，不携带完整聊天正文到观察器日志。首次核验每个会话一次，复查原生请求；未知资料状态保留 manual。列表最多扫描60页并明确报告限制。

每次写动作都记录 preparing/dispatched；简历有 opening-picker/submit/confirm 子步骤。点击同意后原请求卡片自身状态变化不当成新问题，但其他新消息、收件人变化、手工回复或撤销请求阻止旧提交。直接默认附件发送被标记为 website-default，而不是声称点选第一份。

## Chrome API 依据

官方 power：`https://developer.chrome.com/docs/extensions/reference/api/power`。system 请求阻止闲置系统休眠，但允许显示器关闭；不保证强制休眠／关机后工作。

官方 alarms：`https://developer.chrome.com/docs/extensions/reference/api/alarms`。30秒恢复节拍可能被延迟；设备休眠时不被此API唤醒，worker每次实例化时检查闹钟存在，不依赖新版本专有持久选项。

官方生命周期：`https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle`。MV3 worker可以终止，不能依赖永久内存循环；本地状态、消息事件与闹钟用于恢复。

官方 tabs：`https://developer.chrome.com/docs/extensions/reference/api/tabs`。工作页 autoDiscardable=false 是临时防丢弃设置，不承诺绝不冻结；发现冻结时尝试激活后再核验，暂停恢复原设置。

上述资料是技术接口依据，不是该自动化产品获得网站许可或符合平台条款的证明。

## 以下是旧版开发记录

# v0.1.11 当前实现补充

以下优先于历史说明；已提交的外部动作仍不重放。

- C.jobTitleBase / compatibleJobTitle：NFKC、零宽处理、明确福利前后缀；不删除业务方向词。adapter.checkDetail 仍要求身份辅助证据，checkChat/matchChat 使用同一兼容定义。
- settings.resumeSelection：first（默认）或 bound。cleanConfig 迁移保留旧绑定；first 的 C.validate 不要求附件导入。C.robotPlan 生成 resume，不默认生成原生 resumeConsent。snapshot.resumePickerOpen 支持原地续发。
- resumePicker 找 header/files/footer 的共同语义容器，exact 的 includeDisabled 只用于检测，不授权点击禁用按钮；fileRows 限定选择框，resumeSelected 必须看到网站真实选中标记。
- résumé 日志：opening-picker 在工具栏点击前落地；submit 在最终文件发送前落地；confirm 使用确认框签名且不允许重复。content.js 原有授权、用户暂停、锁与结果上报保留。
- ACTION_STAGE 仅允许 résumé 的合法子阶段；第一次后重复 submit 一律拒绝；确认签名最多三个且各一次。页面卸载或通信超时后只读观察；opening-picker 可恢复成 selecting，但已 submit 时看到 picker 不算发送成功。
- first 模式最终核验会话、选中行信息、该行仍为第一项且没有其他选中；实际文件名写回本地状态／跟踪。新诊断 resumePicker 记录结构、状态，不采集 PDF 正文。
- liveChatTab / repairMonitor / forgetClosedTab：仅在安全边界修复可选监听引用；当前正在发送的工作页异常仍遵守暂停保护。restore 分支先保存新引用，之后才删除扩展自开的多余旧监听页。
- setup 对旧 reply 的未提交计划重新生成；pending 已 dispatched 的操作原样保留，不因升级改变 payload 或重发。

当前测试：296 Node，16 Chromium 新故障，25 Chromium 保留功能/面板。tests/v011_browser_test.py 使用真实 worker/content/adapter 源码和模拟 chrome 通道，页面位于 about:blank、外部请求禁止。不是已安装扩展的账号 E2E。

---
# v0.1.10 当前实现

以下条目优先于后面的历史说明。

`completedCycles` 决定新增岗位批次上限；`liveVerified` 只统计介绍确认为我方消息并完成返回的岗位。`cycleRunId`、`verifiedRunId` 防止重入计数，`seenJobs` 保留历史去重。`skipTask` 不再对 intro 强制 halt，平台和用户阻断仍优先。

`C.messageKey` 处理空白和零宽符号；adapter 读取所有正文片段，克隆后剔除具体消息元数据节点，不删除正文中的“未读”等字样。`C.textReceipt` 只接受当前聊天的新我方消息：数量增加，或发送前未见过的原生稳定消息 ID；发送中／失败不确认。自动生成的回退 ID 不能作为原生 ID 证据。

`unconfirmedOps` 保存最多 200 条原始操作快照、runId、opId、chatKey、jobKey、回执基线；长期去重旗标独立保留。`ACTION_RESULT` 校验操作、来源标签、批次和类型，pending 时仅保存 observedResult，归档后仅更新原记录。`reconcileSnapshot` 在回复读取阶段比对晚到消息；不导航，不重放，不冒充当前动作回执。

消息桥接分别设置 ACTION 30 秒、NAV 16 秒、读请求 9 秒的通道上限，已提交动作不因通道超时重发。发送按钮就绪最长约 6 秒、回执观察约 6.5 秒，后续只读恢复最多三轮；单岗位实际总耗时还含加载和调度。

空闲使用 `chrome.idle.queryState(7200)`、`onStateChanged` 和持久化 `idleAutomation`。授权只在手动 START/RESUME 真实投递时建立；正常完成为 `pauseKind=completed` 可以等待接管，手动／异常 halt 会撤销。Chrome locked 不等于已满两小时，还要检查 lockedSince。原生活动事件与可信人工事件重置时间；合成输入、面板轮询、心跳不重置。arm 时间也必须满两小时。

每次 worker 创建都检查 `sbl-tick` alarm 并设置检测间隔，避免只依赖全局 setTimeout。alarm 每半分钟补查；精确执行时间不承诺。空闲标记 requestedAt 不抢占 pending 或当前岗位；完成 restore/check_return 后，保存 `outreachCheckpoint`，调用 `R.start(...,{onlyPending:true,source:'idle'})`。仍是一个执行器，不产生第二个并行发送器。浏览器启动和扩展更新后需重新授权继续。

会话 discovery 最多 60 次滚动、1000 候选。rank：未读0、已读未答1、未知2、我方最后发言3、待核验4、已结束6（未读标记先帮助读取待核验对象，实际发送仍受禁止重发限制）。优先级只决定顺序；发送由右侧稳定聊天历史决定。每次已完成一个外发步骤重新规划，入站与出站 token 均做一致性检查。

官方接口依据：
- https://developer.chrome.com/docs/extensions/reference/api/idle
- https://developer.chrome.com/docs/extensions/reference/api/alarms
- https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle

验证：`npm test`；`python tests/v010_browser_test.py`；`python scripts/release.py <输出目录>`。本环境禁止 native extension 安装，未绕过策略；用 Node Chrome API/时钟替身验证状态机，用 Chromium 渲染验证真实 DOM 操作与面板。测试结果不等于真实账号或原生 idle 行为验证。

---
以下为历史维护记录；其中旧停止策略、回执规则与测试数字不适用于本版。

# v0.1.9 发送与批次调度

当前行为优先于下方历史说明。

- enabled 同时检查可见性、原生 disabled、disabled 属性、aria-disabled、CSS disabled/unable/loading 和 pointer-events。等待发送按钮最多 6 秒；clickSafe 在授权与检查点之后再次检查。不强行改动网站禁用状态。
- putText 对 contenteditable 优先 execCommand(insertText)，不可用时设置纯文本；再通知 input/change/非 Enter keyup。原生编辑可同步触发受信任 input，writingInput 仅包住当前编辑过程；content 的人工输入处理只排除这一对象和时段。
- 同文草稿可重用，不同草稿拒绝覆盖。发送前记录对应文本数量，发送后数量增加才形成回执。beforeClick 明确指出提交尚未发生，可有限重试；已提交的不明结果只读恢复。
- 参考：[MDN execCommand](https://developer.mozilla.org/en-US/docs/Web/API/Document/execCommand)（已弃用，保留后备输入路径）与 [MDN input](https://developer.mozilla.org/en-US/docs/Web/API/Element/input_event)。不能仅设置 DOM 文本便假定页面业务状态已更新。
- workTab 复用匹配 jobs/chat 的官网标签页，否则直接创建公开页面 URL。jobs_entry/robot_entry 等待加载完成，不以前置人工 INSPECT 为门槛。
- liveVerified 在介绍确认后、check_return 看到岗位列表时增加。新批次归零；默认达到目标后 halt。keepListeningAfterBatch 是步骤五的单独设置；STOP_NEW 仍可显式保留监听。步骤六的 robot.keepListening 设置保持独立。
- 扫描保存方向切换前列表哈希，等待变化；当前方向列表末尾重复检查三次后再推进方向。全部已加载方向耗尽时清楚报告未达目标，不转入无解释监听。
- reports 增加目标、完成数、扫描位置和历史状态数量；不包含完整个人配置。
- tests/reported_send.test.cjs 使用诊断 (4) 的实际层级与类名重建离线 DOM。异步启用按钮及事件监听为模拟行为，不是网站源码；测试提供独立 performance 时钟，避免加速 Date 时钟被查询缓存消耗。

# 0.1.8 页面动作顺序

- rosterSurface 以联系人搜索框为范围，从头像定位最小含身份文字的行；不读取输入框作为列表就绪条件。
- currentChat 只返回包含编辑器的右侧区域，排除同时包住左侧列表的外层容器；陌生结构以顶部身份文字与左侧行相互对应。
- NAV conversation 总是点击实际行；robot_open 后进入 robot_read，右侧匹配后才计入“已打开”。
- action 文本写入顺序是点击编辑器、focus、原生 value setter／contenteditable 更新、input/change、点发送、观察新发出消息。禁用发送按钮不阻碍输入区定位。
- uiTrace 记录实际动作及文本哈希，不记录聊天或草稿正文；resolved 记录解析数量，counts 保留旧选择器匹配数量。
- settleResume 读取提交后的文件选择、确认弹窗、送达和待同意状态；确认弹窗限定为简历内容，选择后的不同文件不确认。
- 批量 await_chat 先检查所有相关页，随后才尝试点击联系人，避免在旧监听页抢先处理导致新页遗留。
- tests/screenshot_flow.test.cjs 是按截图行为重建的离线场景，包含空白右侧、行点击绑定、禁用发送按钮、发送后重排和行业差异回复。未使用真实站点 HTML。

以下是历史实现说明，若存在差异以上述当前行为为准。

# 开发维护说明

`core` 负责已审核话术规则，`background` 调度，`robot` 执行独立回复批次，`content` 桥接，`adapter` 读取可见 DOM 与执行动作。

## v0.1.7 入口和诊断修复

robot_entry 负责真实消息菜单点击、跨标签页结果发现和列表就绪；入口点击前保存 entryClicked，导航卸载后只观察不重放。没有列表时区分未进入消息页与聊天组件未识别，失败保存 diagnosticBundle。

DIAGNOSTIC / REPLY_REPORT 均通过 diagnosticBundle 自动采集 working / chat / jobs / selected 标签页，最多八页。主 inspection 优先实际工作页，避免本次上传的两份报告仅含 jobs。包含当前和失败当时的结构，所有 URL 仅保留 origin+pathname；不导出草稿和完整聊天。

可见 DOM 查询扩展到浏览器允许访问的 iframe 文档和开放 ShadowRoot，根集合短暂缓存以降低扫描成本。跨窗口输入框使用 ownerDocument.defaultView 的原生 setter；跨域框架只记录地址与不可访问状态。

Continue 恢复 1.4 的先持久化 await_chat 再 NAV 点击，不再用 CHAT_TARGET 分支决定能否点击。原 URL 上的内嵌聊天也参与匹配，不只按 /chat 路径找目标。

## v0.1.6 回复机器人

START_REPLY 仅由扩展面板调用；主动切换时暂停上一流程，归档未确认动作，保留历史。无需创建职位来源或登记托管会话。robot_scan 从消息列表取稳定键；robot_open 查找并点击；robot_read 等待身份及消息稳定、有限补读历史；robot_execute 逐个执行计划，结果回写后才切换。

第一轮 visited/order 固定去重；第二轮按同一组键查找未回复者的简历申请。列表重排或虚拟化需要时回到顶部再滚动查找，设有读取和查找上限。最后 robot_watch 仅监听本批键，复用已有队列通知。单一 worker ticking 锁与 pending 操作跨两种流程共用。

robotPlan 根据可见历史、introVerified、seenInbound、answered、resumeStatus、rejectionAsked 生成介绍、回复、单次原因追问、简历请求动作。行业匹配仅使用岗位／公司文字，按唯一最高关键词分数匹配；同题取行业、方向、通用优先级。未知事实不填充。hardStop 与普通 declined 分开，后者收到新问题可继续答。

resumeConsent / resumeOffer 点击前持久化检查点；网站返回送达、申请等待、文件选择三个分支。selecting 保存继续选择义务，再用独立 resume 动作选择绑定文件。默认附件需要 robot.allowDefaultResume 开启；关闭时只操作已经可见的文件选择框。会话结束或错误放弃前清理选择框，无法关闭则暂停。

回测用 robot.previewConversations，禁止调用 ACTION，仅执行 NAV 和读操作，消息已读状态可能由网站改变。trace 保存最多 3500 条结构化事件；导出默认去除选用话术 text，不包含完整入站聊天。可选 includeText 只包含实际选用话术。

Web DOM 操作能力依据 [Chrome content scripts 官方说明](https://developer.chrome.com/docs/extensions/develop/concepts/content-scripts)。任务和点击记录持久化到 chrome.storage.local，避免依赖服务工作线程全局变量；生命周期依据 [Chrome extension service worker 官方说明](https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle)。本版未以真实 Chrome 验证生命周期恢复。

## 操作记录

1. 后台记录 pending(stage=preparing)。
2. 内容脚本完成对象、输入框和按钮识别。
3. 紧邻真实写入前发送 ACTION_STAGE，后台验证 runId、epoch、opId、tabId，持久化 stage=dispatched 并保存回执基线。
4. 内容脚本再次验证授权与当前对象后点击。
5. 明确结果才更新成功计数。失去响应时，不重放已提交的 ACTION，而通过只读 RECOVER 查找对应回执。

preparing 可有限重试；dispatched/旧版未知阶段只查回执。恢复失败保留去重：未发起项为 skipped，已建联／已提交项为 needs-attention；已确认介绍的 complete 不被后续附件错误覆盖。暂停撤销后续写入授权。

继续沟通是 NAV：先保存 await_chat，再直接点击，允许导航销毁消息通道。发送介绍后优先历史后退；返回无效时才加载原职位 URL，保留一个聊天页。

## v0.1.5 队列

content 中 MutationObserver 和 5 秒补查只调用 activity()，发送哈希、未读标记与稳定会话键。worker 验证来源标签页及版本，由 core.ingestActivity 合并进入持久化 replyQueue。task 和 pending 非空时绝不切换对象。

队列按消息／明确附件请求、主动附件、其他检查／跟进排序。最多 3 个队列会话后优先 1 个新岗位；无待处理项则继续新增，到达目标后只监听。队列 revision 防止旧任务删除执行期间到达的新消息。连续输入超过合并预算会延后该对象。

nextTaskAt 仅为发送任务冷却；只读检查不重复等待。详情、弹窗和回执仍按条件检查，不以固定 2 秒冒充网站处理完成。

回复载荷记录 handledIds / handledKeys / inboundToken。恢复原确认结果后再生成后续回复。附件使用建联时的文件快照，不调用默认“同意”；未关闭的附件弹窗阻断切换。

Chrome goBack 可按标签页后退，frozen / discarded 用于提示暂停；后退不保证网站保留缓存，冻结页也不能继续执行任务。参见 [Chrome Tabs 官方 API](https://developer.chrome.com/docs/extensions/reference/api/tabs)。

新批次保留历史去重与会话方向、附件快照。关闭或待补充资料的会话不自动复活。新批次归档旧未完成动作，防止使用新配置重放旧消息。

## 适配与诊断

选择器仍是候选，未在本次真实 BOSS 登录页验证。外层 active 状态只有在容器中不含第二个独立候选时才可确认选中；截断标题需要这个选中依据。发送仍检查岗位和会话身份。

动作失败自动保存 INSPECT 结构与阶段。诊断导出不包含消息正文、简历正文、Cookie 或完整页面源码；完整个人配置不应作为诊断文件共享。

## 测试

运行 `node --test tests/*.test.cjs`。Python 浏览器测试是供具备正常 Chromium 测试环境的开发者使用的可选脚本，本版未执行。不得将历史浏览器截图或结果记入本版验证。


## v0.1.4 诊断修复

已知 BOSS 卡片结构中，列表语义字段优先于旧的 jobTitle 容器校准；其他卡片仍用原覆盖。详情限定 header 的 job-name，不使用 HR 的 h2.name。显示文字与提示属性分开读取；标题不匹配仍不允许提交沟通。

NAV job 先验证详情是否就绪，未就绪或 force=true 时点击卡片本体。不能只凭 active 样式略过重选。合成 DOM 回归调用正式 adapter 的 action/navigate，并测试点击传播和文本输入。具体限制见 TEST_REPORT.md。
