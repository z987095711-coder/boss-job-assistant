/* Sequential existing-conversation runner. IO is injected by the single worker. */
(function(root){
  'use strict';const C=root.SBLCore;
  const inboundToken=ms=>C.hash(ms.filter(m=>m.side==='in').map(m=>m.id+'|'+m.text).join('\n'));
  const store=s=>s.robot.dryRun?s.robot.previewConversations:s.conversations;
  function trace(s,event,details={}){
    const r=s.robot;r.trace.push({seq:++r.seq,at:Date.now(),round:r.round,index:r.round===1?r.order.length:r.cursor+1,phase:s.task?.phase||'',event,...details});
    if(r.trace.length>3500)r.trace.shift();
  }
  function start(old,c,dryRun,policy={}){
    const s=C.newBatch(old,dryRun?'reply-preview':'live');s.workflow='reply';s.stopNew=true;
    s.robot={dryRun,onlyPending:policy.onlyPending===true,source:policy.source||'manual',discoveryDone:false,discoveryStarted:false,candidates:{},discoveryPages:0,round:1,limit:c.robot.limit,order:[],visited:{},failed:{},cursor:0,stalls:0,scanSignature:'',cooldownUntil:0,seq:0,trace:[],previewConversations:{},
      summary:{opened:0,processed:0,introductions:0,replies:0,resumes:0,requests:0,rejections:0,skipped:0,manual:0,uncertain:0}};
    s.robot.continuous=policy.continuous===true&&!dryRun;s.robot.watch={phase:'top',pages:0,stalls:0,signature:'',nextSweepAt:0,sweeps:0,lastCheckAt:0};if(s.robot.continuous){s.robot.round=3;s.robot.onlyPending=true;}
    s.task={phase:'robot_entry',entryAttempts:0};s.reason=dryRun?'回测：自动打开消息页，不发送':'一键回复：自动打开消息页，等待会话列表';trace(s,'start',{reason:s.reason,limit:c.robot.limit});return s;
  }
  function summaryPlan(p){return {profile:p.wording.profile?.name||'通用',industry:p.wording.industry,source:p.wording.source,topics:p.keys,missing:p.missing,reason:p.reason,steps:p.steps.map(x=>({kind:x.kind,chars:x.text?.length||0,textHash:x.text?C.hash(x.text):'',file:x.resume?.name||'网站默认附件'}))};}
  function payload(t,step,c){return {chatKey:t.chatKey,jobKey:t.job.key,title:t.job.title,company:t.job.company,robot:true,
    text:step.text,resume:step.resume,inboundToken:t.inboundToken,outboundToken:t.outboundToken,allowSoftRejection:step.allowSoftRejection===true,allowDefaultResume:c.robot.allowDefaultResume,resumeSelection:c.settings.resumeSelection||'first',
    handledIds:step.ids||[],handledKeys:step.keys||[],requested:!!step.requested};}
  function apply(s,c,t,step,result){
    const r=s.robot,x=store(s)[t.chatKey],live=!r.dryRun;
    if(step.kind==='intro'){x.introVerified=true;x.introText=step.text;x.roundInbound=t.inboundIds;if(!result.already){r.summary.introductions++;if(live)s.stats.introductions++;}}
    if(step.kind==='reply'){if(step.wantsResume)x.resumeRequested=true;if(!result.already){r.summary.replies++;if(live)s.stats.replies++;}}
    if(step.kind==='rejection'){x.rejectionAsked=true;x.status='declined';if(!result.already){r.summary.rejections++;if(live)s.stats.followups++;}}
    if(['resume','resumeOffer','resumeConsent'].includes(step.kind)){
      x.resumeStatus=result.resumeStatus;x.resumeMode=result.resumeSelection|| (step.kind==='resume'?'bound-file':'website-default');if(result.resumeName)x.sentResumeName=result.resumeName;
      if(result.resumeStatus==='selecting'){
        x.resumeRequested=true;
        if(!x.resume&&result.candidate)x.resume=result.candidate;
        const next={kind:'resume',resume:step.resume||result.candidate,ids:step.ids,keys:step.keys,requested:step.requested,allowSoftRejection:step.allowSoftRejection};
        s.task.steps.splice(s.task.stepIndex+1,0,next);
      }else if(result.resumeStatus==='waiting'){x.resumeRequested=false;if(!result.already)r.summary.requests++;}
      else if(result.resumeStatus==='sent'){x.resumeRequested=false;if(!result.already){r.summary.resumes++;if(live)s.stats.resumes++;}}
    }
    if(result.resumeStatus!=='selecting'){
      x.seenInbound=[...new Set([...(x.seenInbound||[]),...(step.ids||[])])];
      x.answered=[...new Set([...(x.answered||[]),...(step.keys||[])])];
    }
    if(step.text)x.lastBotOutboundText=step.text;
    x.lastOutboundAt=Date.now();s.task.stepIndex++;s.task.effectPayload=null;s.task.effectCompleted=true;
    for(const event of result.uiActions||[])trace(s,event,{chatKey:t.chatKey,kind:step.kind});
    r.cooldownUntil=Date.now()+(r.dryRun||result.resumeStatus==='selecting'?0:c.settings.intervalSeconds*1000);
    trace(s,r.dryRun?'planned':result.already?'already_sent':'confirmed',{chatKey:t.chatKey,kind:step.kind,text:step.text||'',textHash:step.text?C.hash(step.text):'',resumeStatus:result.resumeStatus||'',resumeName:result.resumeName||(step.kind==='resume'?step.resume?.name||'弹窗第一份简历':'网站默认附件'),topics:step.keys||[]});
  }
  function skip(s,reason,submitted=false){
    const t=s.task,r=s.robot,key=t?.chatKey;
    if(key){r.failed[key]=reason;const x=store(s)[key];if(x){x.status='manual';x.reason=reason;if(submitted)x.uncertainWrite=true;}}
    r.summary[submitted?'uncertain':'skipped']++;if(!r.dryRun)s.stats[submitted?'attention':'skipped']++;
    trace(s,submitted?'uncertain':'skipped',{chatKey:key||'',reason});s.pending=null;s.recovered=null;
    if(r.round===2)r.cursor++;s.task={phase:r.round===1?'robot_scan':r.round===2?'robot_pick':'robot_watch'};s.nextAt=Date.now();
  }
  async function done(s,c,io){
    await io.page(s.chatTabId,'NAV',{kind:'reply_cleanup'});
    await io.persistRun(s.runId,state=>{
      const t=state.task,r=state.robot,x=store(state)[t.chatKey];
      if(x){x.pendingReply=!!t.needsAnswer;x.seenInbound=[...new Set([...(x.seenInbound||[]),...(t.ackIds||[])])];x.roundInbound=t.inboundIds;
        if(t.terminal==='closed'){x.status='closed';x.hardStop=!!t.hardStop;}
        else if(t.terminal==='declined')x.status='declined';
        else if(t.needsAnswer||t.terminal==='manual'){x.status='manual';x.reason=t.planReason;r.manualCounted||={};if(!r.manualCounted[t.chatKey]){r.manualCounted[t.chatKey]=true;r.summary.manual++;}}
      }
      if(r.round===1||r.continuous)r.summary.processed++;else if(r.round===2)r.cursor++;
      state.replyQueue=(state.replyQueue||[]).filter(q=>q.chatKey!==t.chatKey||q.revision!==t.queueRevision);
      trace(state,'finished',{chatKey:t.chatKey,reason:t.planReason,terminal:t.terminal||'',needsAnswer:!!t.needsAnswer});
      state.task={phase:r.round===1?'robot_scan':r.round===2?'robot_pick':'robot_watch'};state.nextAt=Date.now();
    });
  }
  async function watch(s,c,io){
    const activity=await io.page(s.chatTabId,'ACTIVITY');if(activity.blocker)throw Error(activity.blocker);
    let selected=false;
    await io.persistRun(s.runId,state=>{
      const r=state.robot;r.watch.lastCheckAt=Date.now();C.ingestActivity(state,activity);
      // Include newly arrived contacts: the initial quantity is not a lifetime whitelist.
      const q=C.nextQueued(state);
      if(q){
        selected=true;const row=state.conversations[q.chatKey]?.row;
        if(!r.order.includes(q.chatKey))r.order.push(q.chatKey);if(r.order.length>1000)r.order.shift();
        state.task={phase:'robot_open',chatKey:q.chatKey,queueRevision:q.revision,row,seekTurns:0};state.nextAt=Date.now();
        state.reason='检测到待回复消息，自动打开联系人';trace(state,'watch_message',{chatKey:q.chatKey,reason:state.reason});
      }
    });
    if(selected)return;
    const w=s.robot.watch;
    if(w.phase==='idle'&&Date.now()<w.nextSweepAt){await io.persistRun(s.runId,state=>{state.reason='值守中 · 暂无可自动回复的新消息';const due=(state.replyQueue||[]).map(q=>q.dueAt).filter(x=>x>Date.now());state.nextAt=Math.min(Date.now()+5000,...due);});return;}
    if(w.phase==='top'||w.phase==='idle'){
      await io.page(s.chatTabId,'NAV',{kind:'conversations_top'});
      await io.persistRun(s.runId,state=>{Object.assign(state.robot.watch,{phase:'scan',pages:0,stalls:0,signature:''});state.nextAt=Date.now()+400;});return;
    }
    const signature=C.hash((activity.rows||[]).map(row=>row.key).join('|'));
    const more=await io.page(s.chatTabId,'NAV',{kind:'conversations_more'});
    const stalls=signature===w.signature?w.stalls+1:0,pages=w.pages+1;
    const end=(more.end&&stalls>=1)||stalls>=3||pages>=60;
    if(end)await io.page(s.chatTabId,'NAV',{kind:'conversations_top'});
    await io.persistRun(s.runId,state=>{
      const v=state.robot.watch;Object.assign(v,{phase:end?'idle':'scan',signature,stalls,pages});
      if(end){v.sweeps++;v.nextSweepAt=Date.now()+30000;v.limited=pages>=60;trace(state,'watch_sweep',{pages,limited:v.limited,reason:'扫描后回到消息列表顶部，继续监听；不刷新网页'});}
      state.reason='值守中 · 扫描已读未答与简历请求';state.nextAt=Date.now()+(end?1000:400);
    });
  }
  async function tick(s,c,io){
    const r=s.robot,t=s.task||{phase:'robot_watch'};
    if(t.phase==='robot_entry'){await io.connectInbox(s);return;}
    if(Date.now()<r.cooldownUntil){await io.persistRun(s.runId,x=>{x.nextAt=r.cooldownUntil;});return;}
    if(t.phase==='robot_watch'){
      if(r.continuous){await watch(s,c,io);return;}
      if(r.dryRun||!c.robot.keepListening){await io.halt(r.dryRun?'回测完成：本次没有发送消息或附件':'两轮处理完成');return;}
      const activity=await io.page(s.chatTabId,'ACTIVITY');if(activity.blocker)throw Error(activity.blocker);
      await io.persistRun(s.runId,state=>{
        C.ingestActivity(state,activity);
        const q=(state.replyQueue||[]).find(x=>r.order.includes(x.chatKey)&&x.dueAt<=Date.now()&&!['closed','manual'].includes(state.conversations[x.chatKey]?.status));
        if(q){state.task={phase:'robot_open',chatKey:q.chatKey,queueRevision:q.revision,seekTurns:0};state.nextAt=Date.now();}
        else{state.reason='两轮完成；监听本批会话的新消息';state.nextAt=Date.now()+3000;}
      });return;
    }
    if(t.phase==='robot_pick'){
      if(r.cursor>=r.order.length){await io.persistRun(s.runId,state=>{state.robot.round=3;state.task={phase:'robot_watch'};state.nextAt=Date.now();trace(state,'rounds_complete',{summary:state.robot.summary});});return;}
      const key=r.order[r.cursor];
      await io.persistRun(s.runId,state=>{if(r.failed[key]){state.robot.cursor++;return;}state.task={phase:'robot_open',chatKey:key,seekTurns:0};state.nextAt=Date.now();});return;
    }
    const snap=await io.page(s.chatTabId,'SNAPSHOT');if(snap.blocker)throw Error(snap.blocker);
    const rows=(snap.conversations||[]).filter(x=>x.key&&!x.system);
    if(t.phase==='robot_scan'){
      if(snap.route&&snap.route!=='chat'&&!rows.length){await io.persistRun(s.runId,state=>{state.task={phase:'robot_entry',entryAttempts:0};trace(state,'wrong_page',{path:snap.route,reason:'工作页不是消息页，重新点击实际消息入口'});});return;}
      if(r.order.length>=r.limit){await io.persistRun(s.runId,state=>{state.robot.round=2;state.robot.cursor=0;state.task={phase:'robot_pick'};trace(state,'second_round',{reason:'第一轮结束，检查仍未回复者的简历请求'});});return;}
      if(!r.discoveryDone){
        if(!r.discoveryStarted){await io.page(s.chatTabId,'NAV',{kind:'conversations_top'});await io.persistRun(s.runId,state=>{state.robot.discoveryStarted=true;state.nextAt=Date.now()+300;trace(state,'priority_scan',{reason:'先只读扫描联系人，再按未读／已读未答优先打开'});});return;}
        if(!rows.length&&!snap.emptyInbox){
          if((t.waits||0)>=24)throw Error('已经到达消息页，但没有识别到会话行；故障结构已自动保存');
          await io.persistRun(s.runId,state=>{state.task.waits=(t.waits||0)+1;state.nextAt=Date.now()+500;trace(state,'waiting_list',{rows:0});});return;
        }
        const more=await io.page(s.chatTabId,'NAV',{kind:'conversations_more'});
        await io.persistRun(s.runId,state=>{
          const rr=state.robot;rr.candidates ||= {};const before=Object.keys(rr.candidates).length;
          for(const row of rows)if(rr.candidates[row.key]||Object.keys(rr.candidates).length<1000)rr.candidates[row.key]={...row,discoveryIndex:rr.candidates[row.key]?.discoveryIndex??Object.keys(rr.candidates).length};
          const count=Object.keys(rr.candidates).length;rr.discoveryPages++;rr.stalls=count===before?rr.stalls+1:0;
          trace(state,'priority_scan',{discovered:count,pages:rr.discoveryPages,end:!!more.end});
          // End confirmation waits for lazy loading once; bound a broken/infinite list.
          if(snap.emptyInbox||more.end&&rr.stalls>=2||rr.stalls>=4||rr.discoveryPages>=60||count>=1000){rr.discoveryDone=true;rr.stalls=0;trace(state,'priority_ready',{discovered:count,limited:rr.discoveryPages>=60||count>=1000});}
          state.nextAt=Date.now()+350;state.reason='优先扫描未回复会话；已发现 '+count+' 位联系人';
        });return;
      }
      const candidates=Object.values(r.candidates||{}).map(row=>({...row,...rows.find(x=>x.key===row.key)}));
      const row=candidates.filter(x=>!r.visited[x.key]).sort((a,b)=>C.replyPriority(a,store(s)[a.key]).rank-C.replyPriority(b,store(s)[b.key]).rank||a.discoveryIndex-b.discoveryIndex)[0];
      if(row){await io.persistRun(s.runId,state=>{state.robot.visited[row.key]=true;state.robot.order.push(row.key);state.robot.stalls=0;state.task={phase:'robot_open',chatKey:row.key,row,seekTurns:0};state.nextAt=Date.now();trace(state,'selected',{chatKey:row.key,name:row.name||'',company:row.company||'',title:row.title||'',...C.replyPriority(row,store(state)[row.key])});});return;}
      await io.persistRun(s.runId,state=>{state.robot.round=2;state.robot.cursor=0;state.task={phase:'robot_pick'};state.nextAt=Date.now();trace(state,'second_round',{reason:'首轮已按待回复优先处理完毕'});});return;
    }
    if(t.phase==='robot_open'){
      const row=rows.find(x=>x.key===t.chatKey);
      if(!row){
        if((t.seekTurns||0)>=65){await io.persistRun(s.runId,state=>skip(state,'滚动查找后仍未找到该会话，没有发送'));return;}
        await io.page(s.chatTabId,'NAV',{kind:t.seekTurns?'conversations_more':'conversations_top'});
        await io.persistRun(s.runId,state=>{state.task.seekTurns=(t.seekTurns||0)+1;state.nextAt=Date.now()+300;trace(state,'seeking',{chatKey:t.chatKey,attempt:state.task.seekTurns});});return;
      }
      await io.page(s.chatTabId,'NAV',{kind:'conversation',payload:{chatKey:t.chatKey}});
      await io.persistRun(s.runId,state=>{state.task={...t,row,phase:'robot_read',waits:0};state.nextAt=Date.now()+250;trace(state,'opened',{chatKey:t.chatKey,name:row.name||'',company:row.company||''});});return;
    }
    if(t.phase==='robot_read'){
      if(snap.chat?.key!==t.chatKey||snap.chatLoading){
        if((t.waits||0)>=20){await io.persistRun(s.runId,state=>skip(state,'会话未正确打开或消息仍在加载，未发送'));return;}
        if([4,12].includes(t.waits))await io.page(s.chatTabId,'NAV',{kind:'conversation',payload:{chatKey:t.chatKey}});
        await io.persistRun(s.runId,state=>{state.task.waits=(t.waits||0)+1;state.nextAt=Date.now()+250;trace(state,'waiting_chat',{expected:t.chatKey,actual:snap.chat?.key||'',loading:!!snap.chatLoading});});return;
      }
      if(!t.openVerified){await io.persistRun(s.runId,state=>{state.task.openVerified=true;state.robot.summary.opened++;trace(state,'chat_ready',{chatKey:t.chatKey,title:snap.chat.title,company:snap.chat.company,editor:snap.readiness?.editor!==false});});}
      if(snap.historyMore&&(t.historyReads||0)<3){await io.page(s.chatTabId,'NAV',{kind:'history_more'});await io.persistRun(s.runId,state=>{state.task.historyReads=(t.historyReads||0)+1;state.nextAt=Date.now()+350;});return;}
      const signature=C.hash(JSON.stringify([snap.chat,snap.messages]));
      if(t.readSignature!==signature){
        if((t.readChanges||0)>=12){await io.persistRun(s.runId,state=>skip(state,'消息持续变化，本次未发送；待消息稳定后可重新运行'));return;}
        await io.persistRun(s.runId,state=>{state.task.readSignature=signature;state.task.readChanges=(t.readChanges||0)+1;state.nextAt=Date.now()+500;});return;
      }
      if(io.reconcileSnapshot&&await io.reconcileSnapshot(snap)){await io.persistRun(s.runId,state=>{state.nextAt=Date.now();});return;}
      const old=store(s)[t.chatKey]||s.conversations[t.chatKey]||{},plan=C.robotPlan(snap,c,old,r.round,{onlyPending:r.onlyPending});
      const job={key:snap.chat.jobKey||'chat-job:'+C.hash(t.chatKey),title:snap.chat.title||t.row?.title||'',company:snap.chat.company||t.row?.company||''};
      await io.persistRun(s.runId,state=>{
        const x=structuredClone(old);Object.assign(x,{key:t.chatKey,job,profileId:plan.wording.profile?.id||x.profileId||'',profile:plan.wording.profile||x.profile,resume:x.resume||plan.wording.resume,status:'waiting',seenInbound:plan.history.seenInbound,answered:plan.history.answered});
        if(plan.history.introExists)x.introVerified=true;
        x.lastMessageSide=snap.messages.filter(m=>['in','out'].includes(m.side)).at(-1)?.side||'';x.pendingReply=plan.history.fresh.length>0||!!old.resumeRequested||old.resumeStatus==='selecting';x.lastReadAt=Date.now();
        if(snap.resumeReceipt)x.resumeStatus='sent';
        else if(snap.resumeWaiting&&x.resumeStatus!=='selecting')x.resumeStatus='waiting';
        store(state)[t.chatKey]=x;
        state.task={...state.task,job,phase:'robot_execute',steps:plan.steps,stepIndex:0,effectCompleted:false,outboundToken:C.outboundToken(snap.messages),inboundToken:inboundToken(snap.messages),inboundIds:snap.messages.filter(m=>m.side==='in').map(m=>m.id),ackIds:plan.ackIds||[],terminal:plan.terminal||'',hardStop:!!plan.hardStop,needsAnswer:plan.needsAnswer,planReason:plan.reason};
        trace(state,'decision',{chatKey:t.chatKey,inbound:snap.messages.filter(m=>m.side==='in').length,outbound:snap.messages.filter(m=>m.side==='out').length,alreadyHandled:plan.history.seenInbound.length,historyLimited:!!snap.historyMore,...summaryPlan(plan)});
        state.nextAt=Date.now();
      });return;
    }
    if(t.phase==='robot_execute'){
      if(snap.chat?.key!==t.chatKey)throw Error('当前对象已改变，未执行队列发送');
      if(!s.recovered&&(t.effectCompleted||t.inboundToken!==inboundToken(snap.messages)||t.outboundToken!==C.outboundToken(snap.messages))){
        await io.persistRun(s.runId,state=>{state.task={...state.task,phase:'robot_read',readSignature:'',readChanges:0,effectPayload:null};state.nextAt=Date.now()+500;trace(state,'replan',{chatKey:t.chatKey,reason:t.effectCompleted?'上一发送步骤已完成，重新核对最新消息': '发送前消息或我方回复变化，重新合并'});});return;
      }
      const step=t.steps[t.stepIndex];if(!step){await done(s,c,io);return;}
      if(r.dryRun){await io.persistRun(s.runId,state=>apply(state,c,t,step,{verified:true,resumeStatus:'sent',simulated:true}));return;}
      const data=t.effectPayload||payload(t,step,c);
      await io.persistRun(s.runId,state=>{state.task.effectPayload=data;trace(state,'preparing',{chatKey:t.chatKey,kind:step.kind,text:step.text||'',textHash:step.text?C.hash(step.text):''});});
      await io.action(s,s.chatTabId,step.kind,data,(state,result)=>apply(state,c,t,step,result));return;
    }
    throw Error('未知回复机器人阶段：'+t.phase);
  }
  function report(s,includeText=false){
    const r=s.robot;if(!r)return {version:C.VERSION,reason:'尚未运行回复机器人'};
    const events=r.trace.map(e=>{const x={...e};if(!includeText)delete x.text;return x;});
    return {version:C.VERSION,runId:s.runId,mode:r.dryRun?'打开会话的只读回测':'实际发送',status:s.status,reason:s.reason,round:r.round,target:r.limit,onlyPending:r.onlyPending,continuous:!!r.continuous,watch:r.watch,source:r.source,discovered:Object.keys(r.candidates||{}).length,summary:r.summary,events,
      privacy:includeText?'包含选用话术；不含完整聊天、Cookie、验证码或附件正文':'仅含识别信息、话术哈希、匹配主题和执行状态；不含聊天正文、话术正文、Cookie 或附件正文'};
  }
  root.SBLRobot={start,tick,skip,trace,report};
})(globalThis);
