(function(){
  'use strict';if(globalThis.__sblContentReady)return;globalThis.__sblContentReady=true;
  let busy=false,humanAt=0;const A=globalThis.SBLAdapter;
  const send=m=>chrome.runtime.sendMessage(m).catch(()=>null);
  chrome.runtime.onMessage.addListener((m,sender,respond)=>{
    if(sender.id!==chrome.runtime.id || !m?.sbl)return;
    (async()=>{
      const cfg=await send({sbl:true,type:'GET_SELECTORS'});A.setSelectors(cfg?.data?.selectors);
      if(m.type==='INSPECT')return A.inspect();
      if(m.type==='CALIBRATE'){if(busy)throw Error('请先暂停');busy=true;try{return await A.calibrate();}finally{busy=false;}}
      if(m.type==='READ_PROFILE')return {directions:A.directions(),attachments:A.attachments(),url:location.href,inspect:A.inspect()};
      if(m.type==='SNAPSHOT')return A.snapshot();
      if(m.type==='ACTIVITY')return A.activity();
      if(m.type==='CHAT_TARGET')return A.chatTarget(m.payload);
      if(m.type==='RECOVER')return A.observe(m.kind,m.payload,m.evidence);
      if(m.type==='NAV'){
        if(busy)throw Error('页面正在执行动作');busy=true;
        try{return await A.navigate(m.kind,m.payload);}finally{busy=false;}
      }
      if(m.type==='ACTION'){
        if(busy)throw Error('页面正在执行动作');busy=true;
        try{const result=await A.action(m.kind,m.payload,async()=>{
          if(Date.now()-humanAt<2500)throw Error('用户正在手动操作，已停止');
          const ok=await send({sbl:true,type:'ALLOW',runId:m.runId,epoch:m.epoch,opId:m.opId});
          if(!ok?.ok || !ok.data?.allowed)throw Error(ok?.error||'任务已暂停或授权失效');
          const b=A.blocker();if(b)throw Error(b);
        },async evidence=>{
          const r=await send({sbl:true,type:'ACTION_STAGE',runId:m.runId,epoch:m.epoch,opId:m.opId,evidence});
          if(!r?.ok||!r.data?.allowed)throw Error(r?.error||'动作状态记录失败，尚未点击');
        });
          await send({sbl:true,type:'ACTION_RESULT',opId:m.opId,runId:m.runId,kind:m.kind,result});return result;
        }finally{busy=false;}
      }
      throw Error('未知页面请求');
    })().then(data=>respond({ok:true,data,version:globalThis.SBLCore.VERSION})).catch(e=>respond({ok:false,error:e.message,beforeClick:e.beforeClick===true,blocker:!!A.blocker(),version:globalThis.SBLCore.VERSION}));
    return true;
  });
  // Real user interaction wins. Do not treat synthetic events produced by this extension as input.
  document.addEventListener('input',ev=>{if(ev.isTrusted&&!A.isWritingInput?.(ev.target)&&(ev.target.isContentEditable||ev.target.matches('textarea'))){humanAt=Date.now();send({sbl:true,type:'HUMAN_INPUT'});}},true);
  document.addEventListener('pointerdown',ev=>{if(!ev.isTrusted)return;if(ev.target.closest('textarea,[contenteditable="true"],.geek-item,.user-list-item,.friend-content,[data-sbl-conversation]')){humanAt=Date.now();send({sbl:true,type:'HUMAN_INPUT'});}},true);
  // Only genuine user events reset inactivity; synthetic editor events and heartbeats do not.
  let lastHumanReport=0;
  for(const type of ['pointermove','pointerdown','keydown','wheel'])document.addEventListener(type,ev=>{
    if(!ev.isTrusted||A.isWritingInput?.(ev.target))return;
    if(Date.now()-lastHumanReport<15000)return;lastHumanReport=Date.now();send({sbl:true,type:'HUMAN_ACTIVITY'});
  },{capture:true,passive:true});
  // Read-only observer: no clicks, typing, reply generation, or navigation in this path.
  let activityTimer=null,lastActivity='';
  async function reportActivity(){
    activityTimer=null;if(!/\/web\/geek\/chat/.test(location.pathname)&&!A.currentChat?.()?.key)return;
    const a=A.activity(),token=JSON.stringify(a);if(token===lastActivity)return;
    const r=await send({sbl:true,type:'CHAT_ACTIVITY',activity:a,version:globalThis.SBLCore.VERSION});
    if(r?.ok&&r.data?.accepted)lastActivity=token;
  }
  const observer=new MutationObserver(()=>{if(!activityTimer)activityTimer=setTimeout(reportActivity,250);});
  observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['class','data-unread','data-last-message','data-sbl-unread']});
  setInterval(reportActivity,5000);
  setInterval(()=>send({sbl:true,type:'HEARTBEAT'}),5000);
})();
