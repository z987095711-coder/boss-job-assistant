import './core.js';
import './robot.js';
const C=globalThis.SBLCore;
const R=globalThis.SBLRobot;
let chain=Promise.resolve(),ticking=false,wakeTimer=null;
const internal=sender=>sender.id===chrome.runtime.id && sender.url?.startsWith(chrome.runtime.getURL(''));
const isSite=url=>!!C.safeUrl(url);
const read=async()=>{const d=await chrome.storage.local.get(['config','state']);return {config:d.config||C.defaults(),state:d.state||C.initialState()};};
function mutate(fn){const p=chain.then(async()=>{const d=await read();const result=await fn(d);await chrome.storage.local.set(d);return result;});chain=p.catch(()=>{});return p;}
function log(s,text){s.logs.unshift({at:Date.now(),text:String(text).slice(0,260)});s.logs=s.logs.slice(0,180);}
async function persistRun(runId,fn){return mutate(d=>{if(d.state.runId!==runId||d.state.status!=='running')throw Error('任务已暂停或批次已变更');return fn(d.state,d.config);});}
async function halt(reason,status='paused',allowIdle=false){
  if(wakeTimer)clearTimeout(wakeTimer);wakeTimer=null;
  await mutate(({state:s})=>{s.status=status;s.reason=reason;s.epoch++;s.pauseKind=allowIdle?'completed':'manual';
    if(!allowIdle&&s.idleAutomation){s.idleAutomation.armed=false;s.idleAutomation.requestedAt=0;}
    log(s,reason);
  });await releaseWatchTabs();const {config:c,state:x}=await read();if(allowIdle&&x.idleAutomation?.armed&&c.settings.keepAwake)chrome.power.requestKeepAwake('system');else chrome.power.releaseKeepAwake();await badge();
}
async function finishOutreach(reason){
  const {state:s,config:c}=await read();
  if(s.status==='running'&&s.mode==='live'&&c.settings.autoReplyAfterBatch!==false&&!s.pending){await startManagedReply(s,c,reason);return;}
  const armed=!!s.idleAutomation?.armed;
  await halt(reason+(armed?'；空闲接管仍已授权，电脑连续两小时无人操作后进入第六步':''),'paused',armed);
}
function armIdle(s,c){s.idleAutomation={armed:c.settings.idleReplyEnabled!==false&&s.mode==='live'&&s.workflow!=='reply',armedAt:Date.now(),lastHumanAt:Date.now(),requestedAt:0,lockedSince:0,lastCheckAt:0,idleState:'active'};s.pauseKind='';}
async function ensureInfrastructure(){
  if(!await chrome.alarms.get('sbl-tick'))await chrome.alarms.create('sbl-tick',{periodInMinutes:0.5});
  chrome.idle?.setDetectionInterval(C.IDLE_REPLY_SECONDS);
}
// Runs on every service-worker instantiation, not only extension installation.
ensureInfrastructure().catch(()=>{});
async function checkIdleAutomation(force=false){
  const {state:s}=await read(),a=s.idleAutomation;
  if(!a?.armed||!chrome.idle?.queryState||!force&&Date.now()-(a.lastCheckAt||0)<15000)return;
  let idle;try{idle=await chrome.idle.queryState(C.IDLE_REPLY_SECONDS);}catch{return;}
  await mutate(({state:x,config:c})=>{
    if(x.runId!==s.runId||!x.idleAutomation?.armed)return;
    const now=Date.now(),v=x.idleAutomation;v.lastCheckAt=now;v.idleState=idle;
    if(idle==='locked')v.lockedSince ||= now;else v.lockedSince=0;
    // 'locked' by itself does not mean two hours have passed.
    const ready=C.idleEligible(x,c,now)&&(idle==='idle'||idle==='locked'&&now-v.lockedSince>=C.IDLE_REPLY_SECONDS*1000);
    if(ready&&!v.requestedAt){v.requestedAt=now;x.nextAt=0;log(x,'电脑连续两小时无人操作；当前步骤收尾后转入第六步，不领取新岗位');}
    if(!ready&&v.requestedAt){v.requestedAt=0;log(x,'空闲条件已变化，取消尚未执行的自动接管');}
  });
}
async function humanActivity(sender,pause=false){
  const {state:s}=await read();
  if(!internal(sender)&&(!isSite(sender.url)||![s.jobTabId,s.chatTabId,...(s.openedTabs||[])].includes(sender.tab?.id)))return {};
  await mutate(({state:x})=>{if(x.idleAutomation){x.idleAutomation.lastHumanAt=Date.now();x.idleAutomation.requestedAt=0;x.idleAutomation.lockedSince=0;}});
  if(pause&&s.status==='running')await halt('检测到用户手动操作，自动任务已暂停');return {};
}
chrome.idle?.onStateChanged.addListener(async value=>{
  await mutate(({state:s})=>{const a=s.idleAutomation;if(!a?.armed)return;
    if(value==='active'){a.lastHumanAt=Date.now();a.requestedAt=0;a.lockedSince=0;}
    if(value==='locked')a.lockedSince ||= Date.now();
  });
  await checkIdleAutomation(true);await tick();
});
function bounded(promise,ms,label){let timer;return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error(label+'通信超时；不会把未确认操作重发')),ms);timer?.unref?.();})]).finally(()=>clearTimeout(timer));}

async function scheduleTick(){
  if(wakeTimer)clearTimeout(wakeTimer);wakeTimer=null;
  const {state:s}=await read();if(s.status!=='running')return;
  wakeTimer=setTimeout(()=>{wakeTimer=null;tick();},Math.max(50,Math.min(30000,(s.nextAt||0)-Date.now())));
  wakeTimer?.unref?.(); // Node regression harness; Chrome returns a numeric timer ID.
}
async function badge(){const {state:s}=await read();await chrome.action.setBadgeText({text:s.status==='running'?(s.mode==='preview'||s.robot?.dryRun?'回测':s.workflow==='reply'?'回复':'运行'):s.status==='idle'?'':'停'});await chrome.action.setBadgeBackgroundColor({color:s.status==='running'?'#147D75':'#9B4931'});}
async function setup(){
  const {config,state}=await read();
  state.replyQueue ||= [];state.activity ||= {};state.stats.attention ||= 0;state.unconfirmedOps ||= {};state.completedCycles ??= state.liveVerified||0;state.idleAutomation ||= {armed:false};
  if(state.version!==C.VERSION){
    let restored=0;
    for(const [key,record] of Object.entries(state.seenJobs||{})){
      const hasConversation=Object.values(state.conversations||{}).some(c=>c.job?.key===key);
      if(record.status==='skipped'&&/^未点击发送；/.test(record.reason||'')&&(record.reason||'').includes('未点击：详情标题未匹配所选职位')&&!hasConversation){delete state.seenJobs[key];restored++;}
    }
    if(restored)log(state,'已恢复 '+restored+' 个此前因标题识别失败而未点击的岗位，可重新处理');
    if(state.workflow==='reply'&&state.task?.chatKey&&['robot_execute','robot_read'].includes(state.task.phase)&&(!state.pending||state.pending.stage==='preparing')){
      state.pending=null;state.recovered=null;state.task={...state.task,phase:'robot_read',effectPayload:null,effectCompleted:false,readSignature:'',readChanges:0};
      log(state,'已清理旧版尚未提交的附件计划；继续后重新读取当前会话，已发送内容不重发');
    }
    if(config.settings?.autoReplyAfterBatch===undefined){config.settings ||= {};config.settings.autoReplyAfterBatch=true;config.settings.keepAwake=true;log(state,'v0.2：默认开启投递后消息值守与防闲置睡眠；启动前可取消勾选');}
    state.version=C.VERSION;
  }
  await chrome.storage.local.set({config:C.cleanConfig(config),state});
  await chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'}).catch(()=>{});
  // Content scripts request selectors through runtime; personal answers are never exposed to the page.
  await chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true});
  await ensureInfrastructure();
}
chrome.runtime.onInstalled.addListener(async()=>{await setup();const {state}=await read();if(state.status==='running'||state.idleAutomation?.armed)await halt('扩展已更新，请刷新 BOSS 页面后继续本批');});
chrome.runtime.onStartup.addListener(async()=>{await setup();const {state:s}=await read();if(s.status==='running'||s.idleAutomation?.armed)await halt('浏览器已重启，点击继续本批后自动恢复未完成步骤');});
async function page(tabId,type,payload={}){
  if(!Number.isInteger(tabId))throw Error('没有已绑定的 BOSS 标签页');
  let tab;try{tab=await chrome.tabs.get(tabId);}catch{const e=Error('已绑定的 BOSS 标签页已关闭');e.tabClosed=true;throw e;}
  if(!isSite(tab.url||tab.pendingUrl))throw Error('标签页不在授权的 BOSS 网站');
  if(tab.frozen||tab.discarded)throw Error('BOSS 工作页被浏览器休眠，请激活该页面后继续');
  let r;
  try{r=await bounded(chrome.tabs.sendMessage(tabId,{sbl:true,type,...payload}),type==='ACTION'?30000:type==='NAV'?16000:9000,type);}
  catch(e){
    // A closed message channel may mean the click already took effect. Never replay it.
    if(!/receiving end does not exist|could not establish connection/i.test(e.message))throw e;
    await chrome.scripting.executeScript({target:{tabId},files:['core.js','adapter.js','content.js']});
    r=await bounded(chrome.tabs.sendMessage(tabId,{sbl:true,type,...payload}),type==='ACTION'?30000:type==='NAV'?16000:9000,type);
  }
  if(!r?.ok){const e=Error(r?.error||'网页未返回有效结果');e.blocker=!!r?.blocker;e.beforeClick=r?.beforeClick===true;throw e;}if((r.version&&r.version!==C.VERSION)||(type==='INSPECT'&&r.data?.version&&r.data.version!==C.VERSION))throw Error('BOSS 页面仍在运行旧版脚本。请按 F5 刷新 BOSS 页面，再重新检测。');return r.data;
}
async function action(s,tabId,kind,payload,apply){
  const recovered=s.recovered;
  if(recovered&&recovered.kind===kind&&JSON.stringify(recovered.payload)===JSON.stringify(payload)){
    await persistRun(s.runId,state=>{state.recovered=null;apply(state,recovered.result);state.nextAt=Date.now()+100;});return;
  }
  const op={id:'op:'+crypto.randomUUID(),kind,tabId,at:Date.now(),stage:'preparing',subject:payload.chatKey||payload.key||'',payload};
  await persistRun(s.runId,state=>{if(state.pending)throw Error('上一动作正在自动恢复');state.pending=op;state.recovered=null;log(state,'准备'+actionName(kind));});
  let result;
  try{result=await page(tabId,'ACTION',{kind,payload,runId:s.runId,epoch:s.epoch,opId:op.id});}
  catch(e){await actionFailure(s,op,e);return;}
  if(!result.verified&&!result.existing){const e=Error(result.reason||'暂未读到回执');e.definitiveFailure=result.definitiveFailure===true;await actionFailure(s,op,e);return;}
  await mutate(({state})=>{
    if(state.runId!==s.runId||state.pending?.id!==op.id)return;
    // Record a completed external effect even if Pause was pressed while it was in flight.
    state.pending=null;state.recovered=null;if(state.task)state.task.actionRetries=0;apply(state,result);state.nextAt=state.task?Date.now():Math.max(Date.now(),state.nextTaskAt||0);
  });
}
const actionName=kind=>({initiate:'点击立即沟通',intro:'发送方向介绍',reply:'回复消息',followup:'发送跟进',rejection:'追问一次拒绝原因',resumeConsent:'同意简历请求',resumeOffer:'主动申请发送简历',resume:'发送附件'}[kind]||kind);
const platformStop=e=>e.blocker||/验证页面|平台验证|登录或额度|用户正在手动|用户手动操作|授权失效|任务已暂停|旧版脚本|标签页已关闭|不在授权|附件弹窗未关闭|沟通弹窗未关闭|浏览器休眠|已有不同草稿|输入框内容已变化/.test(e.message);
async function actionFailure(s,op,e){
  const {state:now}=await read();if(now.runId!==s.runId||now.pending?.id!==op.id)return;
  let inspection=null;try{inspection=await page(op.tabId,'INSPECT');}catch{}
  await mutate(({state})=>{if(state.runId!==s.runId||state.pending?.id!==op.id)return;state.lastError={at:Date.now(),phase:state.task?.phase||'',kind:op.kind,stage:state.pending.stage||'unknown',message:e.message.slice(0,500),inspection};log(state,actionName(op.kind)+'：'+e.message);});
  if(now.status!=='running')return;
  if(e.beforeClick&&['intro','reply','followup','rejection','resume'].includes(op.kind)&&!platformStop(e)){
    await persistRun(s.runId,state=>{state.pending.stage='preparing';});await retryBeforeClick({...now,pending:{...now.pending,stage:'preparing'}},e.message);return;
  }
  if(now.pending.stage==='preparing'&&/新消息已变化/.test(e.message)){
    await persistRun(s.runId,state=>{state.pending=null;state.recovered=null;state.nextAt=Date.now()+750;log(state,'合并刚收到的新消息后重新生成回复，未点击发送');});return;
  }
  if(platformStop(e)){
    if(now.pending.stage==='preparing')await persistRun(s.runId,state=>{state.pending=null;});
    await halt(e.message,'blocked');return;
  }
  if(now.pending.stage==='preparing'){await retryBeforeClick(now,e.message);return;}
  if(e.definitiveFailure){await skipTask(now,'页面明确显示发送失败，不自动重发：'+e.message);return;}
  await persistRun(s.runId,state=>{state.pending.lastError=e.message;state.pending.polls=0;state.reason='已点击，正在自动读取结果';state.nextAt=Date.now()+600;});
}
async function retryBeforeClick(s,reason){
  if(!s.task){await skipTask(s,reason);return;}
  if((s.task.actionRetries||0)>=2){await skipTask(s,'未点击发送；重试两次仍失败：'+reason);return;}
  await persistRun(s.runId,state=>{state.pending=null;state.recovered=null;state.task.actionRetries=(state.task.actionRetries||0)+1;state.task.reselect=state.task.phase==='initiate';state.stats.retries=(state.stats.retries||0)+1;state.reason='尚未点击，自动重试 '+state.task.actionRetries+'/2';state.nextAt=Date.now()+1000;log(state,state.reason+'：'+reason);});
}
async function skipTask(s,reason){
  if(s.workflow==='reply'){
    try{await page(s.chatTabId,'NAV',{kind:'reply_cleanup'});}catch(e){await halt(e.message,'blocked');return;}
    await persistRun(s.runId,state=>{archiveUnconfirmed(state,reason);R.skip(state,reason,!!state.pending&&state.pending.stage!=='preparing');});return;
  }
  if(s.task?.phase==='monitor_read')try{await page(s.chatTabId,'NAV',{kind:'reply_cleanup'});}catch(e){await halt(e.message,'blocked');return;}
  await persistRun(s.runId,state=>{
    const t=state.task,old=t?.job?state.seenJobs[t.job.key]:null,submitted=state.pending&&state.pending.stage!=='preparing';
    const partial=old&&['contacted','complete','needs-attention'].includes(old.status);
    const attention=partial||submitted||t?.phase==='monitor_read';
    archiveUnconfirmed(state,reason);
    state.pending=null;state.recovered=null;
    state.stats[attention?'attention':'skipped']=(state.stats[attention?'attention':'skipped']||0)+1;
    if(t?.job&&t.phase!=='monitor_read')state.seenJobs[t.job.key]={...old,at:Date.now(),profileId:t.profileId,status:old?.status==='complete'?'complete':attention?'needs-attention':'skipped',reason};
    if(t?.chatKey&&state.conversations[t.chatKey]){state.conversations[t.chatKey].status='manual';state.conversations[t.chatKey].reason=reason;}
    if(t?.phase==='monitor_read')C.finishQueued(state,t);
    state.task=t?.job&&t.phase!=='monitor_read'?{...t,phase:'restore',skipReason:reason}:null;
    state.nextAt=Date.now();state.reason=submitted?'本岗位发送结果待核验，正在返回职位列表继续投递；不会重复发送':attention?'当前岗位已记录需留意，返回职位列表继续':'未发起的岗位已跳过；返回职位列表继续';log(state,state.reason+'：'+reason);
  });
}
async function recoverPending(s){
  const op=s.pending;
  // The content script must persist dispatch before clicking. A preparing operation is safe to retry.
  if(op.stage==='preparing'){await retryBeforeClick(s,'页面通信中断，动作尚未提交');return;}
  let result;
  try{result=op.observedResult||await page(op.tabId,'RECOVER',{kind:op.kind,payload:op.payload||{},evidence:op.evidence||{}});}
  catch(e){if(platformStop(e)){await halt(e.message,'blocked');return;}result={verified:false,reason:e.message};}
  if(result.verified||result.existing){
    await persistRun(s.runId,state=>{state.recovered={kind:op.kind,payload:op.payload,result};state.pending=null;state.nextAt=Date.now();log(state,'自动读到'+actionName(op.kind)+'的结果，继续执行');});return;
  }
  if(result.definitiveFailure){await skipTask(s,'页面明确显示发送失败，不自动重发：'+result.reason);return;}
  if((op.polls||0)>=2){await skipTask(s,'提交结果未确认，不重复发送：'+(result.reason||op.lastError||'页面没有对应回执'));return;}
  await persistRun(s.runId,state=>{state.pending.polls=(op.polls||0)+1;state.reason='正在自动读取发送结果 '+state.pending.polls+'/3';state.nextAt=Date.now()+1200;log(state,state.reason);});
}
function archiveUnconfirmed(s,reason){
  const op=s.pending,t=s.task;if(!op||op.stage==='preparing')return;
  s.unconfirmedOps ||= {};
  s.unconfirmedOps[op.id]={...structuredClone(op),runId:s.runId,workflow:s.workflow||'outreach',jobKey:t?.job?.key||op.payload?.jobKey||op.payload?.key||'',chatKey:t?.chatKey||op.payload?.chatKey||'',archivedAt:Date.now(),reason,status:'pending'};
  const x=s.conversations[t?.chatKey||op.payload?.chatKey];if(x){x.uncertainWrite=true;x.uncertainOpId=op.id;x.status='manual';x.reason=reason;}
  // Bound the log; the per-job/per-conversation no-replay flags are retained indefinitely.
  const ids=Object.keys(s.unconfirmedOps);for(const id of ids.slice(0,Math.max(0,ids.length-200)))delete s.unconfirmedOps[id];
}
function resolveUnconfirmed(s,op,result){
  if(op.status!=='pending'||!result?.verified)return false;
  op.status='verified-late';op.resolvedAt=Date.now();
  const x=s.conversations[op.chatKey],job=s.seenJobs[op.jobKey];
  if(x&&x.uncertainOpId===op.id){
    x.uncertainWrite=false;delete x.uncertainOpId;
    if(x.status==='manual'&&x.reason===op.reason){x.status='waiting';x.reason='迟到回执已核验';}
    x.lastOutboundAt=Math.max(x.lastOutboundAt||0,op.dispatchedAt||op.at||0);
    if(op.payload?.text)x.lastBotOutboundText=op.payload.text;
    if(op.kind==='intro'){x.introVerified=true;x.introText=op.payload.text;}
    x.seenInbound=[...new Set([...(x.seenInbound||[]),...(op.payload?.handledIds||[])])];
    x.answered=[...new Set([...(x.answered||[]),...(op.payload?.handledKeys||[])])];
    if(['resume','resumeConsent','resumeOffer'].includes(op.kind))x.resumeStatus=result.resumeStatus;
  }
  if(op.kind==='intro'&&job){
    const already=job.introVerified;job.introVerified=true;
    if(job.cycleCompletedAt)job.status='complete';
    if(s.runId===op.runId&&!already){s.stats.introductions=(s.stats.introductions||0)+1;
      if(job.cycleRunId===s.runId&&job.verifiedRunId!==s.runId){s.liveVerified++;job.verifiedRunId=s.runId;}
    }
  }
  log(s,'迟到回执已更新原记录：'+actionName(op.kind)+'；不重发、不返回旧会话');return true;
}
async function reconcileSnapshot(snap){
  if(!snap.chat?.key)return false;
  return await mutate(({state:s})=>{let changed=false;
    for(const op of Object.values(s.unconfirmedOps||{}))if(op.status==='pending'&&op.chatKey===snap.chat.key&&['intro','reply','followup','rejection'].includes(op.kind)){
      if(op.payload.jobKey?.startsWith('job:')&&snap.chat.jobKey&&op.payload.jobKey!==snap.chat.jobKey)continue;
      changed=resolveUnconfirmed(s,op,C.textReceipt(snap.messages||[],op.payload.text,op.evidence))||changed;
    }
    return changed;
  });
}
async function archivePending(){
  // A fresh batch must not replay an interrupted write from an older batch/version.
  await mutate(({state:s})=>{
    if(s.status==='running')throw Error('请先暂停');if(!s.pending)return;archiveUnconfirmed(s,'旧批次已归档，等待只读核验');
    if(s.task?.job)s.seenJobs[s.task.job.key]={at:Date.now(),profileId:s.task.profileId,status:'interrupted-do-not-retry'};
    if(s.task?.chatKey&&s.conversations[s.task.chatKey]){s.conversations[s.task.chatKey].status='manual';s.conversations[s.task.chatKey].reason='旧批次动作已归档，不自动重发';}
    if(s.task?.chatKey&&s.conversations[s.task.chatKey]&&s.pending.stage!=='preparing')s.conversations[s.task.chatKey].uncertainWrite=true;
    s.pending=null;s.recovered=null;s.task=null;s.epoch++;log(s,'旧批次未完成动作已自动归档，保留去重记录');
  });
}
function profileFor(config,id){return config.profiles.find(p=>p.id===id&&p.enabled);}
function expected(job,chatKey){return {key:job.key,jobKey:job.key,title:job.title,company:job.company,chatKey};}
function matchChat(chat,job){
  if(!chat?.key)return false;
  if(chat.jobKey&&job.key.startsWith('job:'))return chat.jobKey===job.key;
  return C.compatibleJobTitle(chat.title,job.title)&&!!job.company&&C.compact(chat.company||chat.identityText).includes(C.compact(job.company));
}
async function liveChatTab(ids,exclude){
  for(const id of [...new Set(ids.filter(Number.isInteger))]){
    if(id===exclude)continue;
    try{const tab=await chrome.tabs.get(id);if(isSite(tab.url||tab.pendingUrl)&&/\/web\/geek\/chat(?:[/?#]|$)/.test(tab.url||tab.pendingUrl))return tab;}catch{}
  }return null;
}
async function forgetClosedTab(id){
  await mutate(({state:s})=>{
    const referenced=s.chatTabId===id||s.monitorTabId===id;
    if(s.chatTabId===id)s.chatTabId=null;if(s.monitorTabId===id)s.monitorTabId=null;
    s.openedTabs=(s.openedTabs||[]).filter(x=>x!==id);
    if(referenced)log(s,'旧聊天标签页已失效，已清理引用；不会因此终止职位循环');
  });
}
async function repairMonitor(s,c){
  const live=await liveChatTab([s.chatTabId,s.monitorTabId,...(s.openedTabs||[])],s.jobTabId);
  let tab=live;
  if(!tab&&Object.values(s.conversations||{}).some(x=>!['manual','closed'].includes(x.status))&&(c.settings.autoReply||c.settings.sendResume||s.stopNew)){
    tab=await chrome.tabs.create({url:CHAT_URL,active:false});
  }
  if((tab?.id||null)!==(s.chatTabId||null)||(tab?.id||null)!==(s.monitorTabId||null)){
    await persistRun(s.runId,state=>{
      state.chatTabId=state.monitorTabId=tab?.id||null;state.activityAt=tab?Date.now():0;
      if(tab)state.openedTabs=[...new Set([...(state.openedTabs||[]),tab.id])];
      log(state,tab?'已恢复可用的消息监听页；继续职位循环':'旧聊天页不可用，跳过监听；继续职位循环');
    });
    return (await read()).state;
  }return s;
}
async function maybeTabs(s){
  const candidates=[s.task?.chatTabId,s.jobTabId,s.chatTabId,...(s.openedTabs||[])].filter(Number.isInteger);const list=[];
  for(const id of [...new Set(candidates)])try{const tab=await chrome.tabs.get(id);if(isSite(tab.url||tab.pendingUrl))list.push(id);}catch{}
  return list;
}
const pathOnly=url=>{try{const u=new URL(url);return u.origin+u.pathname;}catch{return '';}};
async function diagnosticBundle(s,selectedId){
  const tabs=(await chrome.tabs.query({url:['https://www.zhipin.com/*','https://zhipin.com/*']})).filter(t=>isSite(t.url||t.pendingUrl));
  const activeId=s.pending?.tabId||s.task?.chatTabId||(s.workflow==='reply'||s.task?.phase==='monitor_read'?s.chatTabId:s.jobTabId);
  const ids=[...new Set([activeId,s.chatTabId,s.jobTabId,selectedId,...tabs.map(t=>t.id)].filter(Number.isInteger))].slice(0,8);
  const results=await Promise.allSettled(ids.map(async id=>({tabId:id,roles:[id===activeId?'working':'',id===selectedId?'selected':'',id===s.chatTabId?'chat':'',id===s.jobTabId?'jobs':''].filter(Boolean),path:pathOnly(tabs.find(t=>t.id===id)?.url),inspection:await page(id,'INSPECT')})));
  const pages=results.map((r,i)=>r.status==='fulfilled'?r.value:{tabId:ids[i],error:r.reason?.message||String(r.reason)});
  return {workingTabId:activeId||null,selectedTabId:selectedId||null,pages,inspection:pages.find(x=>x.tabId===activeId)?.inspection||pages.find(x=>x.tabId===selectedId)?.inspection||pages[0]?.inspection||null};
}
async function captureFailure(s,error){
  const at=Date.now(),bundle=await diagnosticBundle(s,null);
  await mutate(({state})=>{if(state.runId!==s.runId)return;state.lastError={at,phase:state.task?.phase||'',message:error.message,workingTabId:bundle.workingTabId,pages:bundle.pages};if(state.robot)R.trace(state,'failed',{reason:error.message,workingTabId:bundle.workingTabId});});
}
async function connectInbox(s){
  const t=s.task,attempt=t.entryAttempts||0;let chosen=s.chatTabId;const browserTab=await chrome.tabs.get(chosen);
  if(browserTab.status==='loading'||!browserTab.url&&browserTab.pendingUrl){
    if(attempt>=60)throw Error('自动打开消息页后仍未完成加载');
    await persistRun(s.runId,state=>{state.task.entryAttempts=attempt+1;state.nextAt=Date.now()+500;state.reason='已自动打开消息页，等待加载';});return;
  }
  const initial=await page(chosen,'SNAPSHOT');let snap=initial;if(snap.blocker)throw Error(snap.blocker);
  // A newly opened tab or a same-page embedded chat must be verified by its DOM.
  if(!(snap.conversations?.length||snap.emptyInbox)&&attempt>0&&attempt%3===0){
    const candidates=(await chrome.tabs.query({url:['https://www.zhipin.com/*','https://zhipin.com/*']})).filter(x=>isSite(x.url)&&x.id!==chosen&&(/\/chat/.test(x.url)||x.openerTabId===chosen));
    for(const tab of candidates.slice(0,5)){const next=await page(tab.id,'SNAPSHOT');if(next.conversations?.length||next.emptyInbox){chosen=tab.id;snap=next;break;}}
  }
  if(snap.conversations?.length||snap.emptyInbox){await persistRun(s.runId,state=>{state.chatTabId=chosen;state.task={phase:state.robot?.continuous?'robot_watch':'robot_scan'};state.nextAt=Date.now();state.reason=state.robot?.continuous?'消息页已连接；持续值守中，优先处理未回复':'消息页已就绪，开始逐个打开会话';R.trace(state,'inbox_ready',{tabId:chosen,path:pathOnly(snap.url),rows:snap.conversations.length});});return;}
  const onChat=snap.route==='chat'||/\/chat(?:[/?#]|$)/.test(new URL(snap.url).pathname);
  if(attempt>=45)throw Error(onChat?'已到消息页，但会话结构尚未识别；已保存此页诊断':'点击入口后仍未进入消息页；已保存实际工作页诊断');
  const shouldClick=!onChat&&!t.entryClicked;
  await persistRun(s.runId,state=>{state.task.entryAttempts=attempt+1;if(shouldClick)state.task.entryClicked=true;state.nextAt=Date.now()+500;R.trace(state,shouldClick?'click_inbox':'waiting_inbox',{tabId:chosen,path:pathOnly(snap.url),route:snap.route||'',attempt:attempt+1});});
  if(shouldClick)try{await page(chosen,'NAV',{kind:'inbox'});}catch(e){if(!/message port closed|message channel closed|frame.*removed|frame.*detached|receiving end does not exist/i.test(e.message))throw e;}
}
const JOBS_URL='https://www.zhipin.com/web/geek/jobs?ka=header-jobs',CHAT_URL='https://www.zhipin.com/web/geek/chat';
async function workTab(kind,preferredId,active=true){
  const route=kind==='jobs'?/\/web\/geek\/jobs?(?:[/?#]|$)/:/\/web\/geek\/chat(?:[/?#]|$)/;
  const tabs=(await chrome.tabs.query({url:['https://www.zhipin.com/*','https://zhipin.com/*']})).filter(t=>isSite(t.url||t.pendingUrl)&&route.test(t.url||t.pendingUrl));
  const selected=tabs.find(t=>t.id===Number(preferredId))||tabs.find(t=>t.active)||tabs[0];
  return selected?(active?await chrome.tabs.update(selected.id,{active:true}):selected):await chrome.tabs.create({url:kind==='jobs'?JOBS_URL:CHAT_URL,active});
}
async function startManagedReply(s,c,reason){
  if(s.status!=='running'||s.pending)return;
  const tab=await workTab('chat',s.chatTabId);
  await mutate(d=>{
    const old=d.state;if(old.runId!==s.runId||old.status!=='running'||old.pending)return;
    const checkpoint={runId:old.runId,jobTabId:old.jobTabId,profileIndex:old.profileIndex,completedCycles:old.completedCycles||0,liveVerified:old.liveVerified,stats:structuredClone(old.stats),savedAt:Date.now(),reason};
    const next=R.start(old,d.config,false,{onlyPending:true,continuous:true,source:'batch-complete'});
    next.chatTabId=tab.id;next.monitorTabId=tab.id;next.jobTabId=old.jobTabId;
    next.outreachCheckpoint=checkpoint;next.completedCycles=checkpoint.completedCycles;next.liveVerified=checkpoint.liveVerified;next.stats=structuredClone(checkpoint.stats);
    next.reason=reason+'；已自动进入第六步，持续监听整个消息列表';log(next,next.reason);d.state=next;
  });
}
async function protectWatchTab(s){
  if(!s.robot?.continuous||s.status!=='running')return false;
  let tab;try{tab=await chrome.tabs.get(s.chatTabId);}catch{}
  if(!tab||!isSite(tab.url||tab.pendingUrl)||!/\/web\/geek\/chat(?:[/?#]|$)/.test(tab.url||tab.pendingUrl)){
    if(tab&&isSite(tab.url||tab.pendingUrl)&&tab.status!=='loading'){const inspect=await page(tab.id,'INSPECT');if(inspect.blocker)throw Error(inspect.blocker);if(inspect.loggedIn===false)throw Error('登录已失效，请在网站重新登录后继续值守');}
    if(s.pending){await halt('消息工作页已关闭，已提交操作保留待核验；点击继续值守','blocked');return true;}
    const next=await workTab('chat',null,false);
    await persistRun(s.runId,x=>{x.chatTabId=x.monitorTabId=next.id;x.task={phase:'robot_entry',entryAttempts:0};x.nextAt=Date.now()+500;log(x,'消息页已自动重新连接；已发消息不重发');});return true;
  }
  if(!s.tabProtection?.[tab.id]){
    await persistRun(s.runId,x=>{x.tabProtection||={};x.tabProtection[tab.id]={previous:tab.autoDiscardable!==false};});
    await chrome.tabs.update(tab.id,{autoDiscardable:false});
  }
  if(tab.frozen||tab.discarded){
    // Activation is the documented way to thaw. Never fake platform presence or defeat a login challenge.
    await chrome.tabs.update(tab.id,{active:true});
    await persistRun(s.runId,x=>{x.nextAt=Date.now()+1000;log(x,'浏览器已冻结／卸载工作页，正在唤回消息页；先核验旧操作');});return true;
  }
  if(tab.status==='loading'&&s.task?.phase!=='robot_entry'){
    if((s.watchLoadingWaits||0)>=60)throw Error('消息工作页持续加载，请检查网络后继续值守；未重复提交消息');
    await persistRun(s.runId,x=>{x.watchLoadingWaits=(x.watchLoadingWaits||0)+1;x.nextAt=Date.now()+500;});return true;
  }
  if(s.watchLoadingWaits)await persistRun(s.runId,x=>{x.watchLoadingWaits=0;});
  return false;
}
async function releaseWatchTabs(){
  const {state:s}=await read();
  for(const [id,lease] of Object.entries(s.tabProtection||{}))try{await chrome.tabs.update(Number(id),{autoDiscardable:lease.previous});}catch{}
  await mutate(({state:x})=>{x.tabProtection={};});
}
async function startIdleReply(s,c){
  const tab=await workTab('chat',s.chatTabId);
  await mutate(d=>{
    const old=d.state;if(old.runId!==s.runId||!old.idleAutomation?.armed||!old.idleAutomation.requestedAt||!C.idleEligible(old,d.config))return;
    const checkpoint={runId:old.runId,jobTabId:old.jobTabId,profileIndex:old.profileIndex,completedCycles:old.completedCycles||0,liveVerified:old.liveVerified,stats:structuredClone(old.stats),savedAt:Date.now()};
    const a={...old.idleAutomation,armed:false,requestedAt:0,triggeredAt:Date.now()};
    d.state=R.start(old,d.config,false,{onlyPending:true,continuous:c.robot.keepListening!==false,source:'idle'});d.state.chatTabId=tab.id;d.state.jobTabId=old.jobTabId;
    d.state.idleAutomation=a;d.state.outreachCheckpoint=checkpoint;
    d.state.reason='连续两小时无人操作，已自动进入第六步：优先未回复会话';log(d.state,d.state.reason);
  });
}
async function jobsEntry(s){
  const t=s.task,tab=await chrome.tabs.get(s.jobTabId);let snap=null;
  if(tab.status!=='loading')try{snap=await page(s.jobTabId,'SNAPSHOT');}catch(e){if(platformStop(e))throw e;}
  if(snap?.blocker)throw Error(snap.blocker);
  if(snap?.jobs?.length){await page(s.jobTabId,'NAV',{kind:'return_list'});await persistRun(s.runId,state=>{state.task=null;state.nextAt=Date.now();log(state,'职位页已自动打开，开始完整沟通循环');});return;}
  if((t.waits||0)>=60)throw Error('职位页仍未显示岗位，请检查登录或页面加载；尚未开始发送');
  await persistRun(s.runId,state=>{state.task.waits=(t.waits||0)+1;state.nextAt=Date.now()+500;state.reason='已自动打开职位页，等待岗位加载';});
}
async function tick(){
  if(ticking)return;ticking=true;
  try{
    const {config:c,state:initial}=await read();let s=initial;
    if(s.idleAutomation?.requestedAt&&!s.pending&&(!s.task||['scan','jobs_entry'].includes(s.task.phase))){
      await checkIdleAutomation(true);s=(await read()).state;
      if(s.idleAutomation?.requestedAt&&C.idleEligible(s,c)){await startIdleReply(s,c);return;}
    }
    if(s.status!=='running'||Date.now()<s.nextAt)return;
    if(c.settings.keepAwake)chrome.power.requestKeepAwake('system');
    if(s.workflow==='reply'&&await protectWatchTab(s))return;
    if(s.pending){await recoverPending(s);return;}
    if(s.workflow==='reply'){await R.tick(s,c,{page,action,persistRun,halt,connectInbox,reconcileSnapshot});return;}
    if(s.task?.phase==='jobs_entry'){await jobsEntry(s);return;}
    const profiles=c.profiles.filter(p=>p.enabled);if(!profiles.length)throw Error('没有有效投递方向');
    const limit=c.settings.batchLimit;
    if(s.mode==='preview'){
      if(s.stats.preview>=limit){await halt('预览已完成：没有发送任何消息或简历');return;}
      const p=profiles[s.profileIndex%profiles.length];
      if(s.task?.phase!=='preview_scan'){
        await page(s.jobTabId,'NAV',{kind:'direction',payload:{label:p.sourceLabel}});
        await persistRun(s.runId,state=>{state.task={phase:'preview_scan',profileId:p.id};state.nextAt=Date.now()+1800;});return;
      }
      const snap=await page(s.jobTabId,'SNAPSHOT');if(snap.blocker)throw Error(snap.blocker);
      const jobs=snap.jobs.filter(j=>!s.seenJobs[j.key]&&!s.previewJobs[j.key]&&!c.settings.excludeWords.some(w=>j.summary.includes(w)));
      const remain=limit-s.stats.preview, chosen=jobs.slice(0,remain);
      await persistRun(s.runId,state=>{
        for(const j of chosen){state.previewJobs[j.key]=true;state.plans.push({key:j.key,title:j.title,company:j.company,profile:p.name,resume:c.attachments.find(r=>r.key===p.resumeKey)?.name,greeting:p.greeting});state.stats.preview++;}
        state.profileIndex++;state.task=null;state.scanTurns=chosen.length?0:state.scanTurns+1;state.nextAt=Date.now()+2000;
        log(state,'预览读取 '+chosen.length+' 个岗位，未发送');
      });
      if(!chosen.length){const more=await page(s.jobTabId,'NAV',{kind:'more'});if(more.end&&s.scanTurns>=profiles.length-1)await halt('当前已加载列表没有更多可预览的新岗位');}
      return;
    }
    if((s.completedCycles??s.liveVerified)>=limit&&!s.task&&!s.manualMonitor){
      if(c.settings.autoReplyAfterBatch!==false||!c.settings.keepListeningAfterBatch){await finishOutreach('已处理 '+(s.completedCycles??s.liveVerified)+' / '+limit+' 轮；确认发送 '+s.liveVerified+'，本批新增已停止');return;}
      if(!s.stopNew){await persistRun(s.runId,state=>{state.stopNew=true;state.stopReason='target';log(state,'完整沟通次数已达目标，按设置继续监听');});s.stopNew=true;}
    }
    if(s.task){await taskStep(s,c);return;}
    s=await repairMonitor(s,c);
    // Only read the list/current visible messages. This never loops through every conversation.
    if(s.chatTabId&&Date.now()-(s.activityAt||0)>=5000){
      let a;try{a=await page(s.chatTabId,'ACTIVITY');}catch(e){if(e.tabClosed){await forgetClosedTab(s.chatTabId);return;}throw e;}if(a.blocker)throw Error(a.blocker);
      await persistRun(s.runId,state=>C.ingestActivity(state,a));
    }
    await persistRun(s.runId,state=>{
      state.replyQueue=(state.replyQueue||[]).filter(x=>state.conversations[x.chatKey]&&!['closed','manual'].includes(state.conversations[x.chatKey].status));
      for(const conv of Object.values(state.conversations)){
        if((state.replyQueue||[]).some(x=>x.chatKey===conv.key))continue;
        if(conv.pendingResume&&conv.resumeStatus!=='waiting')C.enqueue(state,conv.key,conv.resumeRequested?'resume-request':'resume');
        else if(C.dueFollowup(conv,c))C.enqueue(state,conv.key,'followup');
      }
    });
    s=(await read()).state;
    if(Date.now()<(s.nextTaskAt||0)){await persistRun(s.runId,state=>{state.nextAt=state.nextTaskAt;});return;}
    const queued=C.nextQueued(s);
    // Fairness boundary: never preempt typing or a pending receipt; at most three queued turns then one new contact.
    if(queued&&s.chatTabId&&(s.stopNew||(s.replyStreak||0)<3)){await monitor(s,c,queued);return;}
    if(s.stopNew&&s.manualMonitor&&c.settings.autoReplyAfterBatch!==false){await startManagedReply(s,c,'已停止新增岗位');return;}
    if(s.stopNew){await persistRun(s.runId,state=>{const due=(state.replyQueue||[]).map(x=>x.dueAt).filter(x=>x>Date.now());state.nextAt=Math.min(Date.now()+5000,...due);state.reason='停止新增；按设置继续监听新消息';});return;}
    const p=profiles[s.profileIndex%profiles.length];
    const snap=await page(s.jobTabId,'SNAPSHOT');if(snap.blocker)throw Error(snap.blocker);
    if(!snap.jobs.length){await persistRun(s.runId,state=>{state.task={phase:'jobs_entry',waits:0};state.nextAt=Date.now()+500;});return;}
    const nav=await page(s.jobTabId,'NAV',{kind:'direction',payload:{label:p.sourceLabel}});
    await persistRun(s.runId,state=>{state.task={phase:'scan',profileId:p.id,sourceUrl:snap.url,directionChanged:!!nav.changed,previousList:C.hash(snap.jobs.map(j=>j.key).join('|')),directionWaits:0};state.nextAt=Date.now()+(nav.changed?600:0);});
  }catch(e){
    if(!/任务已暂停或批次已变更/.test(e.message)){
      const {state:now}=await read();
      if(now.status==='running'&&now.workflow==='reply'&&now.task?.chatKey&&!platformStop(e))await retryBeforeClick(now,e.message);
      else if(now.status==='running'&&now.task?.job&&!['restore','check_return'].includes(now.task.phase)&&!platformStop(e))await retryBeforeClick(now,e.message);
      else if(now.status==='running'){await captureFailure(now,e);await halt(e.message,'blocked');}
    }
  }
  finally{ticking=false;await badge();await scheduleTick();}
}
async function taskStep(s,c){
  const t=s.task,p=t.phase==='monitor_read'?(s.conversations[t.chatKey]?.profile||profileFor(c,t.profileId)):profileFor(c,t.profileId);if(!p)throw Error('方向配置已变更，需重新确认');
  if(t.phase==='scan'){
    const snap=await page(s.jobTabId,'SNAPSHOT');if(snap.blocker)throw Error(snap.blocker);
    const signature=C.hash(snap.jobs.map(j=>j.key).join('|'));
    if(!snap.jobs.length||t.directionChanged&&signature===t.previousList&&(t.directionWaits||0)<8){
      if((t.directionWaits||0)>=40)throw Error('方向切换后岗位列表未加载');
      await persistRun(s.runId,state=>{state.task.directionWaits=(t.directionWaits||0)+1;state.nextAt=Date.now()+350;});return;
    }
    const job=snap.jobs.find(j=>!s.seenJobs[j.key]&&!c.settings.excludeWords.some(w=>j.summary.includes(w)));
    if(!job){
      const more=await page(s.jobTabId,'NAV',{kind:'more'});
      const repeats=t.emptySignature===signature?(t.emptyPolls||0)+1:1;
      // One failed scroll or a transient old direction does not exhaust the batch.
      await persistRun(s.runId,state=>{
        state.task.emptySignature=signature;state.task.emptyPolls=more.end?repeats:0;
        if(more.end&&repeats>=3){state.task=null;state.profileIndex++;state.scanTurns++;log(state,'当前方向已检查至列表末尾；已见 '+snap.jobs.length+' 个岗位，切换下一方向');}
        // Keep the current direction while lazy-loaded cards arrive; do not reset its scroll.
        state.nextAt=Date.now()+1000;
      });
      if(more.end&&repeats>=3&&s.scanTurns>=c.profiles.filter(x=>x.enabled).length-1)await finishOutreach('已处理 '+(s.completedCycles??s.liveVerified)+' / '+c.settings.batchLimit+' 轮；所有方向已加载列表中没有更多未处理岗位，本批未达目标');return;
    }
    await page(s.jobTabId,'NAV',{kind:'job',payload:{key:job.key,force:true}});
    await persistRun(s.runId,state=>{state.task={...t,job,phase:'initiate'};state.nextAt=Date.now();});return;
  }
  if(t.phase==='initiate'){
    if(t.reselect){await page(s.jobTabId,'NAV',{kind:'job',payload:{key:t.job.key,force:true}});await persistRun(s.runId,state=>{state.task.reselect=false;state.nextAt=Date.now();});return;}
    await action(s,s.jobTabId,'initiate',expected(t.job), (state,result)=>{
      state.seenJobs[t.job.key]={at:Date.now(),profileId:p.id,status:result.existing?'previous':'contacted'};
      if(result.existing){state.task={...t,phase:'restore'};log(state,'跳过已建立的历史沟通，未接管');return;}
      state.stats.contacts++;state.task={...t,job:{...t.job,title:result.title||t.job.title},actionRetries:0,phase:'continue'};log(state,'平台确认已新建沟通 '+state.stats.contacts+' / '+c.settings.batchLimit);
    });return;
  }
  if(t.phase==='continue'){
    // Restore v0.1.4's direct Continue click. A failed link probe must never prevent it.
    // Save the next phase BEFORE navigation, which can destroy the content-script channel.
    await persistRun(s.runId,state=>{state.task={...t,phase:'await_chat',waits:0};state.nextAt=Date.now()+600;log(state,'直接点击网页的继续沟通，等待对应聊天出现');});
    try{await page(s.jobTabId,'NAV',{kind:'continue',payload:expected(t.job)});}
    catch(e){
      if(!/message port closed|message channel closed|frame.*removed|frame.*detached|receiving end does not exist/i.test(e.message))throw e;
      // Only observe the resulting tab; never click Continue a second time automatically.
    }
    return;
  }
  if(t.phase==='await_chat'){
    const observed=[];
    for(const tabId of await maybeTabs(s)){
      let snap;try{snap=await page(tabId,'SNAPSHOT');}catch{continue;}if(snap.blocker)throw Error(snap.blocker);
      observed.push({tabId,snap});if(!matchChat(snap.chat,t.job))continue;
      if(s.conversations[snap.chat.key]&&s.conversations[snap.chat.key].job.key!==t.job.key){await skipTask(s,'同一聊天对象已绑定另一岗位，保留原话术和简历，不切换绑定');return;}
      const convo={key:snap.chat.key,job:t.job,profileId:p.id,profile:structuredClone(p),resume:structuredClone(c.attachments.find(r=>r.key===p.resumeKey)),status:'waiting',seenInbound:[],answered:[],followupsSent:0,lastOutboundAt:Date.now(),resumeStatus:'none',createdAt:Date.now()};
      await persistRun(s.runId,state=>{state.chatTabId=tabId;state.conversations[convo.key] ||= convo;state.task={...t,chatKey:convo.key,chatTabId:tabId,phase:'intro'};});return;
    }
    // The inbox can open with a blank right pane. Only after checking all new tabs,
    // click a matching left row, then verify its right-hand job before any send.
    for(const {tabId,snap} of observed.reverse()){
      const candidates=(snap.conversations||[]).filter(row=>!row.system&&row.key&&t.job.company&&C.compact(row.company||row.identityText).includes(C.compact(t.job.company))&&!(t.triedChatRows||[]).includes(tabId+':'+row.key));
      const row=candidates.find(x=>C.compact(x.title)===C.compact(t.job.title))||candidates[0];
      if(row){await page(tabId,'NAV',{kind:'conversation',payload:{chatKey:row.key}});await persistRun(s.runId,state=>{state.task.triedChatRows=[...(state.task.triedChatRows||[]),tabId+':'+row.key];state.nextAt=Date.now()+250;log(state,'已点击左侧联系人 '+(row.name||row.company)+'，等待右侧岗位与输入框');});return;}
    }
    if((t.waits||0)>=40){await skipTask(s,'已建联，但聊天页面未匹配当前岗位，介绍未确认');return;}
    await persistRun(s.runId,state=>{state.task.waits=(t.waits||0)+1;state.nextAt=Date.now()+250;});return;
  }
  if(t.phase==='intro'){
    const snap=await page(t.chatTabId,'SNAPSHOT');if(snap.blocker)throw Error(snap.blocker);const conv=s.conversations[t.chatKey];
    // An approved introduction does not wait for HR acceptance or a question. Rejection still wins.
    const plan=snap.messages.some(m=>m.side==='in'&&C.STOP.test(m.text))?{action:'close',reason:'对方已拒绝或要求停止联系'}:snap.messages.some(m=>m.side==='unknown')?{action:'hold',reason:'无法判断消息发出方，先校准页面'}:{action:'none'};
    if(plan.action==='close'||plan.action==='hold'){
      await persistRun(s.runId,state=>{state.conversations[t.chatKey].status=plan.action==='close'?'closed':'manual';state.conversations[t.chatKey].reason=plan.reason;state.task={...t,phase:'restore'};});return;
    }
    const finishIntro=state=>{
      state.recovered=null;
      state.conversations[t.chatKey].lastOutboundAt=Date.now();
      state.conversations[t.chatKey].pendingResume=c.settings.sendResume;
      state.conversations[t.chatKey].introVerified=true;state.conversations[t.chatKey].introText=p.greeting;
      C.ingestActivity(state,snap.activity);
      C.enqueue(state,t.chatKey,'check');
      state.stats.introductions=(state.stats.introductions||0)+1;
      state.seenJobs[t.job.key]={...state.seenJobs[t.job.key],introVerified:true,status:'complete'};
      state.task={...t,introVerified:true,phase:'restore'};state.nextAt=0;
      log(state,'方向介绍已确认发送；新消息与附件进入同一队列');
    };
    if(snap.messages.some(m=>C.outgoingConfirmed(m)&&C.messageKey(m.text)===C.messageKey(p.greeting))){await persistRun(s.runId,finishIntro);return;}
    await action(s,t.chatTabId,'intro',{...expected(t.job,t.chatKey),text:p.greeting},state=>{
      finishIntro(state);
    });return;
  }
  if(t.phase==='resume'){
    const resume=c.attachments.find(r=>r.key===p.resumeKey);await action(s,t.chatTabId,'resume',{...expected(t.job,t.chatKey),resume,resumeSelection:c.settings.resumeSelection||'first'},(state,result)=>{
      const conv=state.conversations[t.chatKey];conv.resumeStatus=result.resumeStatus;conv.lastOutboundAt=Date.now();if(result.resumeStatus==='sent'&&!result.already)state.stats.resumes++;
      state.task={...t,resumeVerified:result.resumeStatus==='sent',phase:result.resumeStatus==='selecting'?'resume':'restore'};
    });return;
  }
  if(t.phase==='restore'){
    const tab=await chrome.tabs.get(s.jobTabId);
    const returnUrl=JOBS_URL;
    if(!/\/web\/geek\/jobs?(?:[/?#]|$)/.test(tab.url||'')){
      let monitorTab=await liveChatTab([s.monitorTabId,s.chatTabId],s.jobTabId);
      if(!monitorTab)monitorTab=await chrome.tabs.create({url:'https://www.zhipin.com/web/geek/chat',active:false});
      // Prefer browser history (SPA/BFCache can retain list state). Hard navigation is a fallback, not the default.
      let hardReturn=false;try{await chrome.tabs.goBack(s.jobTabId);}catch{hardReturn=true;await chrome.tabs.update(s.jobTabId,{url:returnUrl});}
      await persistRun(s.runId,state=>{state.chatTabId=monitorTab.id;state.monitorTabId=monitorTab.id;state.openedTabs=[...new Set([...(state.openedTabs||[]),monitorTab.id])];state.task={...t,returnUrl,hardReturn,phase:'check_return',waits:0};state.nextAt=Date.now()+200;log(state,hardReturn?'网站返回历史不可用，使用职位页地址恢复':'通过页面历史返回职位列表，不主动刷新');});return;
    }
    const canonical=/\/web\/geek\/jobs(?:[/?#]|$)/.test(tab.url||'');
    if(canonical)await page(s.jobTabId,'NAV',{kind:'return_list'});
    await chrome.tabs.update(s.jobTabId,canonical?{active:true}:{url:returnUrl,active:true});
    // A skipped card has no chatTabId. Keep the live monitor; never delete a tab still referenced by the run.
    const monitor=await liveChatTab([t.chatTabId,s.chatTabId,s.monitorTabId],s.jobTabId);
    await persistRun(s.runId,state=>{state.monitorTabId=monitor?.id||null;state.chatTabId=monitor?.id||null;state.task={...t,returnUrl,hardReturn:!canonical,phase:'check_return',waits:0};state.nextAt=Date.now()+350;});
    // Switch all references BEFORE retiring an extension-opened surplus monitor.
    if(monitor&&s.monitorTabId&&s.monitorTabId!==monitor.id&&s.monitorTabId!==s.jobTabId&&(s.openedTabs||[]).includes(s.monitorTabId)){
      await chrome.tabs.remove(s.monitorTabId).catch(()=>{});
      await persistRun(s.runId,state=>{state.openedTabs=(state.openedTabs||[]).filter(id=>id!==s.monitorTabId);});
    }return;
  }
  if(t.phase==='check_return'){
    let snap;try{snap=await page(s.jobTabId,'SNAPSHOT');}catch{snap=null;}
    if(snap?.blocker)throw Error(snap.blocker);
    if(!snap?.jobs?.length||snap.route==='chat'||!/\/web\/geek\/jobs(?:[/?#]|$)/.test(snap.url||'')){
      if((t.waits||0)>=4&&!t.hardReturn){
        const tab=await chrome.tabs.get(s.jobTabId);
        if(!/\/web\/geek\/jobs(?:[/?#]|$)/.test(tab.url||'')||!snap?.jobs?.length){
          await chrome.tabs.update(s.jobTabId,{url:t.returnUrl||'https://www.zhipin.com/web/geek/jobs'});
          await persistRun(s.runId,state=>{state.task.hardReturn=true;state.task.waits=0;state.nextAt=Date.now()+250;log(state,'网站未保留职位页历史，按原职位地址恢复（此分支会重新加载）');});return;
        }
      }
      if((t.waits||0)>=120)throw Error('返回职位页后列表仍未加载，请检查该页面');
      await persistRun(s.runId,state=>{state.task.waits=(t.waits||0)+1;state.nextAt=Date.now()+250;});return;
    }
    await page(s.jobTabId,'NAV',{kind:'return_list'});
    await completeTask(s,c);return;
  }
  if(t.phase==='monitor_read'){
    await monitorRead(s,c);return;
  }
  throw Error('未知执行阶段，需人工检查');
}
async function completeTask(s,c){await persistRun(s.runId,state=>{
  const record=s.task.job&&state.seenJobs[s.task.job.key];
  if(record&&record.status!=='previous'&&record.cycleRunId!==state.runId){
    state.completedCycles=(state.completedCycles??state.liveVerified??0)+1;record.cycleRunId=state.runId;record.cycleCompletedAt=Date.now();
  }
  if(record&&(s.task.introVerified||record.introVerified)){
    if(record.verifiedRunId!==state.runId){state.liveVerified++;record.verifiedRunId=state.runId;}record.status='complete';
  }else if(record?.status==='contacted'){record.status='needs-attention';state.stats.attention=(state.stats.attention||0)+1;}
  state.task=null;state.recovered=null;state.profileIndex++;state.scanTurns=0;state.replyStreak=0;
  state.reason='已返回职位列表；已处理 '+(state.completedCycles||0)+' / '+c.settings.batchLimit+' 轮，确认发送 '+state.liveVerified;
  state.nextTaskAt=Date.now()+c.settings.intervalSeconds*1000;state.nextAt=state.nextTaskAt;
});}
async function monitor(s,c,item){
  const conv=s.conversations[item.chatKey];
  const snap=await page(s.chatTabId,'SNAPSHOT');if(snap.blocker)throw Error(snap.blocker);
  if(!snap.conversations.some(x=>x.key===conv.key)){
    await persistRun(s.runId,state=>{
      const q=state.replyQueue.find(x=>x.chatKey===conv.key);if(q)q.dueAt=Date.now()+15000;
      state.nextAt=Date.now();state.conversations[conv.key].reason='该会话未加载，延后处理；不阻塞其他任务';
    });return;
  }
  await page(s.chatTabId,'NAV',{kind:'conversation',payload:{chatKey:conv.key}});
  await persistRun(s.runId,state=>{state.task={phase:'monitor_read',profileId:conv.profileId,chatKey:conv.key,job:conv.job,queueRevision:item.revision,waits:0};state.nextAt=Date.now()+700;log(state,'处理队列会话；当前对象锁定，其他消息只排队');});
}
async function monitorRead(s,c){
  const t=s.task,conv=s.conversations[t.chatKey],p=conv.profile||profileFor(c,conv.profileId);
  const snap=await page(s.chatTabId,'SNAPSHOT');if(snap.blocker)throw Error(snap.blocker);
  if(!matchChat(snap.chat,conv.job)||snap.chat.key!==conv.key){
    if((t.waits||0)>=20){await skipTask(s,'队列会话未正确打开，没有填写或发送');return;}
    await persistRun(s.runId,state=>{state.task.waits=(t.waits||0)+1;state.nextAt=Date.now()+250;});return;
  }
  // If new bubbles arrive during the open/read transition, settle briefly and merge once.
  const freshToken=C.hash(snap.messages.filter(m=>m.side==='in'&&!(conv.seenInbound||[]).includes(m.id)).map(m=>m.id+'|'+m.text).join('\n'));
  if(t.inboundToken!==freshToken){
    await persistRun(s.runId,state=>{
      if(t.settleStarted&&Date.now()-t.settleStarted>=2500&&!s.recovered){
        C.finishQueued(state,t);const item=C.enqueue(state,conv.key,'message');item.firstAt=Date.now();item.dueAt=Date.now()+750;
        state.task=null;state.nextTaskAt=0;state.nextAt=Date.now();log(state,'对方仍连续输入，暂缓这条回复，先处理其他任务');return;
      }
      state.task.inboundToken=freshToken;state.task.settleStarted ||= Date.now();state.nextAt=Date.now()+500;
    });return;
  }
  const finish=(state,plan={},wrote=false)=>{
    const x=state.conversations[conv.key];x.seenInbound=[...new Set([...(x.seenInbound||[]),...(plan.ids||[])])];x.answered=[...new Set([...(x.answered||[]),...(plan.keys||[])])];
    C.finishQueued(state,t);state.task=null;state.monitorIndex++;
    // Reading an unchanged conversation costs no configured send interval.
    state.nextTaskAt=wrote?Date.now()+c.settings.intervalSeconds*1000:0;state.nextAt=state.nextTaskAt||Date.now();
    if(x.pendingResume&&x.resumeStatus!=='waiting')C.enqueue(state,conv.key,x.resumeRequested?'resume-request':'resume');
  };
  if(s.recovered&&['reply','resume','followup'].includes(s.recovered.kind)){
    // Apply the original confirmed effect before planning around newer inbound messages.
    const r=s.recovered,meta=r.payload;
    await action(s,s.chatTabId,r.kind,meta,(state,result)=>{
      const x=state.conversations[conv.key];x.lastOutboundAt=Date.now();
      if(r.kind==='reply'){state.stats.replies++;if(meta.wantsResume){x.pendingResume=true;x.resumeRequested=true;}}
      if(r.kind==='resume'){x.pendingResume=result.resumeStatus==='selecting';x.resumeStatus=result.resumeStatus;if(result.resumeStatus==='selecting'){state.task.actionRetries=0;return;}if(result.resumeName)x.sentResumeName=result.resumeName;if(result.resumeStatus==='sent'&&!result.already)state.stats.resumes++;}
      if(r.kind==='followup'){x.followupsSent++;state.stats.followups++;}
      finish(state,{ids:meta.handledIds||[],keys:meta.handledKeys||[]},true);
      C.enqueue(state,conv.key,'check');
    });return;
  }
  if(snap.messages.some(m=>m.side==='unknown')){
    await persistRun(s.runId,state=>{state.conversations[conv.key].status='manual';state.conversations[conv.key].reason='无法确定消息发出方';finish(state);});return;
  }
  const plan=C.questionPlan(snap.messages,c,p,conv);
  if(plan.action==='close'||plan.action==='hold'){
    await persistRun(s.runId,state=>{state.conversations[conv.key].status=plan.action==='close'?'closed':'manual';state.conversations[conv.key].reason=plan.reason;finish(state,plan);});return;
  }
  if(!c.settings.autoReply&&plan.action!=='none'){
    await persistRun(s.runId,state=>{state.conversations[conv.key].status='manual';state.conversations[conv.key].reason='自动回复未启用';finish(state,plan);});return;
  }
  if(plan.action==='reply'||(plan.action==='resume'&&plan.text)){
    await action(s,s.chatTabId,'reply',{...expected(conv.job,conv.key),text:plan.text,inboundToken:C.hash(snap.messages.filter(m=>m.side==='in').map(m=>m.id+'|'+m.text).join('\n')),handledIds:plan.ids,handledKeys:plan.keys,wantsResume:plan.action==='resume'},state=>{
      const x=state.conversations[conv.key];x.lastOutboundAt=Date.now();state.stats.replies++;
      if(plan.action==='resume'){x.pendingResume=true;x.resumeRequested=true;}
      finish(state,plan,true);
    });return;
  }
  if(plan.action==='resume'||conv.pendingResume){
    if(conv.resumeStatus==='waiting'){
      await persistRun(s.runId,state=>{const x=state.conversations[conv.key];x.pendingResume=false;if(snap.resumeReceipt){x.resumeStatus='sent';state.stats.resumes++;}finish(state,plan);log(state,snap.resumeReceipt?'附件已获准送达':'附件请求已提交，等待对方；释放队列，不重复申请');});return;
    }
    if(plan.action!=='resume'&&snap.messages.some(m=>m.side==='in'&&C.NO_RESUME.test(m.text))){
      await persistRun(s.runId,state=>{state.conversations[conv.key].pendingResume=false;finish(state,plan);});return;
    }
    if(!c.settings.sendResume){await persistRun(s.runId,state=>{state.conversations[conv.key].status='manual';state.conversations[conv.key].reason='自动发送简历未启用';finish(state,plan);});return;}
    await action(s,s.chatTabId,'resume',{...expected(conv.job,conv.key),resume:conv.resume||c.attachments.find(r=>r.key===p.resumeKey),resumeSelection:c.settings.resumeSelection||'first',requested:plan.action==='resume',handledIds:plan.ids,handledKeys:plan.keys,inboundToken:C.hash(snap.messages.filter(m=>m.side==='in').map(m=>m.id+'|'+m.text).join('\n'))},(state,result)=>{
      const x=state.conversations[conv.key];x.pendingResume=result.resumeStatus==='selecting';x.resumeStatus=result.resumeStatus;x.lastOutboundAt=Date.now();if(result.resumeName)x.sentResumeName=result.resumeName;if(result.resumeStatus==='selecting'){state.task.actionRetries=0;return;}if(result.resumeStatus==='sent'&&!result.already)state.stats.resumes++;finish(state,plan,!result.already);
    });return;
  }
  // A successfully delivered attachment receipt is checked independently of text messages.
  if(conv.resumeStatus==='waiting'&&snap.resumeReceipt){await persistRun(s.runId,state=>{state.conversations[conv.key].resumeStatus='sent';state.conversations[conv.key].pendingResume=false;state.stats.resumes++;});}
  const follow=C.dueFollowup({...conv,unhandledInbound:!!plan.ids?.length},c);
  if(follow){await action(s,s.chatTabId,'followup',{...expected(conv.job,conv.key),text:follow.text,inboundToken:C.hash(snap.messages.filter(m=>m.side==='in').map(m=>m.id+'|'+m.text).join('\n')),handledIds:plan.ids,handledKeys:plan.keys},state=>{const x=state.conversations[conv.key];x.followupsSent++;x.lastOutboundAt=Date.now();state.stats.followups++;finish(state,plan,true);});return;}
  await persistRun(s.runId,state=>finish(state,plan));
}
chrome.tabs.onCreated.addListener(tab=>{
  if(!tab.openerTabId)return;
  mutate(({state:s})=>{if(s.status==='running'&&tab.openerTabId===s.jobTabId){s.openedTabs=[...(s.openedTabs||[]),tab.id].slice(-15);}}).catch(()=>{});
});
chrome.alarms.onAlarm.addListener(async a=>{if(a.name==='sbl-tick'){await checkIdleAutomation();await tick();}});
chrome.runtime.onMessage.addListener((m,sender,respond)=>{
  if(sender.id!==chrome.runtime.id||!m?.sbl)return;
  (async()=>{
    if(m.type==='GET_SELECTORS'){const {config}=await read();return {selectors:config.selectors};}
    if(m.type==='ALLOW'){
      const {state:s}=await read();return {allowed:s.status==='running'&&s.mode==='live'&&s.runId===m.runId&&s.epoch===m.epoch&&s.pending?.id===m.opId&&s.pending?.tabId===sender.tab?.id};
    }
    if(m.type==='ACTION_STAGE'){
      return await mutate(({state:s})=>{
        const allowed=s.status==='running'&&s.mode==='live'&&s.runId===m.runId&&s.epoch===m.epoch&&s.pending?.id===m.opId&&s.pending?.tabId===sender.tab?.id;
        if(!allowed)throw Error('任务已暂停或授权失效');
        const resumeKind=['resume','resumeConsent','resumeOffer'].includes(s.pending.kind);
        const substage=m.evidence?.resumeStage||'',previous=s.pending.evidence?.resumeStage||'';
        const confirmKey=String(m.evidence?.resumeConfirmKey||'').slice(0,80);
        const seen=s.pending.resumeConfirmKeys||[];
        const nextResumeStep=resumeKind&&((s.pending.kind==='resume'&&previous==='opening-picker'&&substage==='submit')||
          (substage==='confirm'&&['','submit','confirm'].includes(previous)&&confirmKey&&!seen.includes(confirmKey)&&seen.length<3));
        if(s.pending.stage!=='preparing'&&!nextResumeStep)throw Error('此动作已提交，禁止重复点击');
        if(substage==='confirm')s.pending.resumeConfirmKeys=[...seen,confirmKey];
        s.pending.stage='dispatched';s.pending.dispatchedAt=Date.now();
        s.pending.evidence={beforeCount:Number.isInteger(m.evidence?.beforeCount)?m.evidence.beforeCount:null,title:String(m.evidence?.title||'').slice(0,140),beforeIds:Array.isArray(m.evidence?.beforeIds)?m.evidence.beforeIds.filter(x=>typeof x==='string').slice(0,100):undefined,textHash:String(m.evidence?.textHash||'').slice(0,80),resumeConfirmKey:confirmKey,resumeStage:['opening-picker','submit','confirm'].includes(m.evidence?.resumeStage)?m.evidence.resumeStage:'',resumeName:String(m.evidence?.resumeName||'').slice(0,200),resumeKey:String(m.evidence?.resumeKey||'').slice(0,250),resumeSelection:m.evidence?.resumeSelection==='first'?'first':'bound'};
        if(s.workflow==='reply')R.trace(s,'dispatched',{chatKey:s.task?.chatKey||'',kind:s.pending.kind,beforeCount:s.pending.evidence.beforeCount});
        log(s,'提交'+actionName(s.pending.kind)+'，等待网页回执');return {allowed:true};
      });
    }
    if(m.type==='ACTION_RESULT'){
      return await mutate(({state:s})=>{
        const op=s.pending?.id===m.opId?s.pending:s.unconfirmedOps?.[m.opId];
        if(!op||op.tabId!==sender.tab?.id||!isSite(sender.url)||op.kind!==m.kind||(op.runId||s.runId)!==m.runId)return {accepted:false};
        if(!m.result?.verified)return {accepted:false};
        const result={verified:true,already:m.result.already===true,title:String(m.result.title||'').slice(0,140),resumeStatus:m.result.resumeStatus,resumeName:String(m.result.resumeName||'').slice(0,200),resumeSelection:m.result.resumeSelection,candidate:m.result.candidate?{name:String(m.result.candidate.name||'').slice(0,200),meta:String(m.result.candidate.meta||'').slice(0,180),key:String(m.result.candidate.key||'').slice(0,250)}:null,uiActions:m.result.uiActions};
        if(s.pending?.id===m.opId){s.pending.observedResult=result;return {accepted:true};}
        return {accepted:resolveUnconfirmed(s,op,result)};
      });
    }
    if(m.type==='HUMAN_ACTIVITY')return await humanActivity(sender);
    if(m.type==='HEARTBEAT'){const {state:s}=await read();if([s.jobTabId,s.chatTabId,...(s.openedTabs||[])].includes(sender.tab?.id))tick();return {};}
    if(m.type==='CHAT_ACTIVITY'){
      const result=await mutate(({state:s})=>{
        if(s.status!=='running'||s.mode!=='live'||sender.tab?.id!==s.chatTabId||!isSite(sender.url)||m.version!==C.VERSION)return {accepted:false};
        const changed=C.ingestActivity(s,m.activity);
        if(changed&&!s.pending&&(!s.task||s.task.phase==='robot_watch'))s.nextAt=Math.max(Date.now(),s.robot?.cooldownUntil||s.nextTaskAt||0);
        return {accepted:true,changed};
      });
      if(result.changed)await scheduleTick();return result;
    }
    if(m.type==='HUMAN_INPUT')return await humanActivity(sender,true);
    if(!internal(sender))throw Error('仅扩展设置页面可以修改任务');
    if(m.type==='GET')return await read();
    if(m.type==='START_REPLY'){
      if(m.dryRun!==true&&m.consent!==true)throw Error('点击一键回复后才能开始实际发送');
      let {config:c,state:s}=await read();c=m.config?C.cleanConfig(m.config):C.cleanConfig(c);
      if(!c.robot.greeting&&!c.profiles.some(p=>p.enabled&&p.greeting))throw Error('请先填一条通用介绍或方向介绍');
      if(s.status==='running')await halt('切换到回复机器人，保存原任务去重记录');
      if(s.pending)await archivePending();
      const tab=await workTab('chat',m.tabId||s.chatTabId);
      await mutate(d=>{d.config=c;d.state=R.start(d.state,c,m.dryRun===true,{continuous:m.continuous===true&&c.robot.keepListening&&m.dryRun!==true,onlyPending:m.continuous===true&&m.dryRun!==true,source:m.continuous===true?'manual-watch':'manual'});d.state.chatTabId=tab.id;d.state.jobTabId=null;log(d.state,d.state.reason);});
      tick();return {tabId:tab.id};
    }
    if(m.type==='REPLY_REPORT'){
      const {state:s}=await read();const report=R.report(s,m.includeText===true);
      Object.assign(report,await diagnosticBundle(s,Number(m.tabId)||null));
      report.pending=s.pending?{kind:s.pending.kind,stage:s.pending.stage,polls:s.pending.polls||0}:null;report.lastError=s.lastError||null;return report;
    }
    if(m.type==='TABS'){return (await chrome.tabs.query({url:['https://www.zhipin.com/*','https://zhipin.com/*']})).map(t=>({id:t.id,title:t.title||'BOSS 直聘',url:t.url||t.pendingUrl,active:!!t.active,windowId:t.windowId,lastAccessed:t.lastAccessed||0}));}
    if(m.type==='OPEN_JOBS'){
      const {state:s}=await read();if(s.status==='running')throw Error('请先暂停再重新绑定职位来源');
      const tab=await workTab('jobs',m.tabId);return {id:tab.id,url:tab.url||tab.pendingUrl||JOBS_URL};
    }
    if(m.type==='OPEN'){const url=C.safeUrl(m.url);if(!url)throw Error('只允许打开 BOSS 官网');const t=await chrome.tabs.create({url});return {id:t.id};}
    if(m.type==='INSPECT'||m.type==='READ_PROFILE')return await page(Number(m.tabId),m.type);
    if(m.type==='CALIBRATE'){
      const {state:s}=await read();if(s.status==='running'||s.pending)throw Error('请先暂停并处理未完成动作，再校准');
      return await page(Number(m.tabId),'CALIBRATE');
    }
    if(m.type==='SAVE'){
      const {state:s}=await read();if(s.status==='running')throw Error('请先暂停再修改配置');
      if(s.pending)await archivePending();
      const config=C.cleanConfig(m.config);await mutate(d=>{d.config=config;if(!config.settings.idleReplyEnabled&&d.state.idleAutomation){d.state.idleAutomation.armed=false;d.state.idleAutomation.requestedAt=0;}});if(!config.settings.idleReplyEnabled)chrome.power.releaseKeepAwake();return {config};
    }
    if(m.type==='START'){
      const {config:c,state:s}=await read();if(s.status==='running')throw Error('已有运行任务');
      if(s.pending)await archivePending();
      const errors=C.validate(c);if(errors.length)throw Error(errors.join('\n'));
      const mode=m.mode==='live'?'live':'preview';if(mode==='live'&&m.consent!==true)throw Error('真实发送需要本批明确授权');
      const tab=await workTab('jobs',m.tabId);
      await mutate(({state})=>{const next=C.newBatch(state,mode);next.jobTabId=tab.id;next.task={phase:'jobs_entry',waits:0};next.openedTabs=(state.openedTabs||[]).filter(id=>id!==tab.id);Object.assign(state,next);armIdle(state,c);log(state,mode==='live'?'本批真实发送已授权；自动打开职位页'+(state.idleAutomation.armed?'；两小时空闲接管已启用':''):'开始只读预览');});
      tick();return {tabId:tab.id};
    }
    if(m.type==='PAUSE'){await halt('用户已暂停；已提交的网站操作不可撤回');return {};}
    if(m.type==='STOP_NEW'){
      const {state:s}=await read();await persistRun(s.runId,state=>{state.stopNew=true;state.manualMonitor=true;state.reason='停止新增；完成当前项后继续监听回复';log(state,state.reason);});return {};
    }
    if(m.type==='RESUME'){
      const {state:s,config:c}=await read();
      if(s.mode==='live'&&m.consent!==true)throw Error('继续真实发送需要重新确认授权');
      if(s.workflow!=='reply'&&Number.isInteger(s.jobTabId))await page(s.jobTabId,'INSPECT');
      await mutate(({state})=>{state.status='running';state.reason='继续当前批次';state.nextAt=0;if(state.workflow!=='reply')armIdle(state,(m.config||c));});tick();return {};
    }
    if(m.type==='ABANDON_PENDING'){
      // Never retry unknown effects. Mark the job as seen and its conversation as manual.
      await mutate(({state:s})=>{if(s.task?.job)s.seenJobs[s.task.job.key]={at:Date.now(),profileId:s.task.profileId,status:'uncertain-do-not-retry'};
        if(s.task?.chatKey&&s.conversations[s.task.chatKey])s.conversations[s.task.chatKey].status='manual';
        s.pending=null;s.task=null;s.status='paused';s.reason='已跳过不确定操作，保留去重，不会重发';s.epoch++;log(s,s.reason);});return {};
    }
    if(m.type==='DIAGNOSTIC'){
      const {config:c,state:s}=await read();return {version:C.VERSION,generatedAt:new Date().toISOString(),...await diagnosticBundle(s,Number(m.tabId)||null),
        state:{status:s.status,workflow:s.workflow||'outreach',mode:s.mode,reason:s.reason,phase:s.task?.phase||'',jobTabId:s.jobTabId,chatTabId:s.chatTabId,target:c.settings.batchLimit,completed:s.liveVerified,completedCycles:s.completedCycles||0,idleAutomation:s.idleAutomation,outreachCheckpoint:s.outreachCheckpoint||null,unconfirmed:Object.values(s.unconfirmedOps||{}).map(x=>({kind:x.kind,status:x.status,at:x.archivedAt,resolvedAt:x.resolvedAt||0})),stopNew:s.stopNew,stopReason:s.stopReason||'',scanTurns:s.scanTurns,profileIndex:s.profileIndex,seenJobCounts:Object.values(s.seenJobs).reduce((a,j)=>(a[j.status]=(a[j.status]||0)+1,a),{}),pending:s.pending?{kind:s.pending.kind,stage:s.pending.stage||'unknown',polls:s.pending.polls||0}:null,lastError:s.lastError||null,stats:s.stats,logs:s.logs.slice(0,60)},
        reply:s.robot?R.report(s,false):null,selectorOverrideKeys:Object.keys(c.selectors),
        privacy:'自动采集机器人工作页、所选页及BOSS标签页的结构；不含完整聊天、附件正文、Cookie、验证码或URL查询参数'};
    }
    if(m.type==='CLEAR'){
      const {state:s}=await read();if(s.status==='running')throw Error('请先暂停');await chrome.storage.local.clear();await setup();return {};
    }
    throw Error('未知请求');
  })().then(data=>respond({ok:true,data})).catch(e=>respond({ok:false,error:e.message}));
  return true;
});
