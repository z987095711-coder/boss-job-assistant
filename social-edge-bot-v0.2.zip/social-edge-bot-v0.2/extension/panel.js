'use strict';
const C=globalThis.SBLCore,$=id=>document.getElementById(id);
let config=C.defaults(),state=C.initialState(),step=1,targetTab=null,tabs=[],lastWorkflow=null;
const titles=['登录','导入','绑定','行业话术','批量沟通','回复机器人'];
async function request(type,data={}){const r=await chrome.runtime.sendMessage({sbl:true,type,...data});if(!r?.ok)throw Error(r?.error||'扩展后台没有响应');return r.data;}
function msg(text,error=false){$('notice').textContent=text;$('notice').classList.toggle('error',error);$('notice').hidden=false;}
function make(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function field(label,el){const l=make('label',label);l.append(el);return l;}
function input(value,attrs={}){const e=make('input');Object.assign(e,attrs);e.value=value||'';return e;}
function textarea(value,rows=3){const e=make('textarea');e.rows=rows;e.value=value||'';return e;}
function bind(id,fn){$(id).addEventListener('click',async()=>{const b=$(id);b.disabled=true;try{await fn();}catch(e){msg(e.message,true);}finally{b.disabled=false;}});}
function showStep(n){step=Math.max(1,Math.min(titles.length,n));for(let i=1;i<=titles.length;i++)$('step'+i).hidden=i!==step;[...$('steps').children].forEach((e,i)=>e.classList.toggle('active',i+1===step));$('prev').disabled=step===1;$('next').hidden=step===titles.length;}
function readForms(){
  for(const card of $('profiles').children){const i=Number(card.dataset.index);if(!Number.isInteger(i))continue;const p=config.profiles[i];p.enabled=card.querySelector('[data-field="enabled"]').checked;p.resumeKey=card.querySelector('[data-field="resume"]').value;p.greeting=card.querySelector('[data-field="greeting"]').value;p.sourceLabel=card.querySelector('[data-field="label"]').value;
    for(const q of C.ALL_FAQ)p.overrides[q.id]=card.querySelector('[data-override="'+q.id+'"]').value;
    p.matchKeywords=C.words(card.querySelector('[data-field="matchKeywords"]').value);
  }
  for(const q of C.ALL_FAQ)config.answers[q.id]=$('answer-'+q.id).value;
  config.followups=config.followups.map((f,i)=>({enabled:$('follow-enabled-'+i).checked,text:$('follow-text-'+i).value,hours:Number($('follow-hours-'+i).value)}));
  config.settings={batchLimit:Number($('batchLimit').value),intervalSeconds:Number($('interval').value),pauseAtReplies:Number($('pauseAt').value),keepAwake:$('keepAwake').checked,autoReply:$('autoReply').checked,sendResume:$('sendResume').checked,resumeSelection:$('resumeSelection').value,keepListeningAfterBatch:$('keepListeningAfterBatch').checked,autoReplyAfterBatch:$('autoReplyAfterBatch').checked,idleReplyEnabled:$('idleReplyEnabled').checked,excludeWords:$('excludeWords').value.split('\n').map(s=>s.trim()).filter(Boolean)};
  config.industries=[...$('industryRules').children].filter(e=>e.dataset.industry!==undefined).map(card=>({name:card.querySelector('[data-industry-name]').value,keywords:C.words(card.querySelector('[data-industry-keywords]').value),greeting:card.querySelector('[data-industry-greeting]').value,answers:Object.fromEntries(C.ALL_FAQ.map(q=>[q.id,card.querySelector('[data-industry-answer="'+q.id+'"]').value]))}));
  config.robot={...config.robot,limit:Number($('replyLimit').value),profileId:$('replyProfile').value||'auto',resumeKey:$('replyResume').value,greeting:$('replyGreeting').value,rejectionText:$('rejectionText').value,
    sendResume:$('replySendResume').checked,followRejection:$('replyRejection').checked,allowDefaultResume:$('replyNativeResume').checked,keepListening:$('replyListen').checked};
  return config;
}
async function save(){readForms();const d=await request('SAVE',{config});config=d.config;return config;}
function renderConfig(){
  $('profiles').replaceChildren();
  config.profiles.forEach((p,i)=>{
    const card=make('div',undefined,'card');card.dataset.index=i;
    const toggle=input('',{type:'checkbox',checked:p.enabled});toggle.dataset.field='enabled';const label=field('启用方向 '+(i+1),toggle);label.className='check';card.append(label);
    card.append(field('官网求职方向（固定）',input(p.name,{disabled:true})));
    const select=make('select');select.dataset.field='resume';select.append(new Option('请选择对应附件',''));config.attachments.forEach(r=>select.append(new Option(r.name+(r.meta?' · '+r.meta:''),r.key)));select.value=p.resumeKey;card.append(field('严格绑定模式的附件（第一份模式不使用）',select));
    const greet=textarea(p.greeting,4);greet.dataset.field='greeting';greet.placeholder='请填写真实、获准发送的方向介绍';card.append(field('方向介绍（平台招呼之后补发）',greet));
    const sourceLabel=input(p.sourceLabel||p.name);sourceLabel.dataset.field='label';card.append(field('职位页的对应标签文字（必要时按官网修正）',sourceLabel));
    const match=textarea((p.matchKeywords||[]).join('\n'),2);match.dataset.field='matchKeywords';card.append(field('聊天中匹配这个方向的岗位关键词（每行一个）',match));
    const d=make('details');d.append(make('summary','此方向专属回答（不填则使用通用回答）'));p.overrides ||= {};
    C.ALL_FAQ.forEach(q=>{const t=textarea(p.overrides[q.id],2);t.dataset.override=q.id;d.append(field(q.title,t));});card.append(d);$('profiles').append(card);
  });
  if(!config.profiles.length)$('profiles').append(make('p','请先到第二步导入方向。','muted'));
  $('questions').replaceChildren();$('basicQuestions').replaceChildren();
  C.ALL_FAQ.forEach((q,i)=>{const t=textarea(config.answers[q.id],3);t.id='answer-'+q.id;t.placeholder=q.hint||'';
    const box=i<C.FAQ.length?$('questions'):$('basicQuestions');box.append(field((i<C.FAQ.length?(i+1)+'. ':'')+q.title,t));
    const examples=make('p','常见问法：'+q.keys.slice(0,5).join(' / '),'muted');box.append(examples);
  });
  $('followups').replaceChildren();config.followups.forEach((f,i)=>{
    const card=make('div',undefined,'card'),check=input('',{type:'checkbox',checked:f.enabled});check.id='follow-enabled-'+i;const l=field((i+C.FAQ.length+1)+'. '+(i?'第二次礼貌跟进':'第一次礼貌跟进')+'（可不选）',check);l.className='check';card.append(l);
    const text=textarea(f.text);text.id='follow-text-'+i;text.placeholder=i?'例如：补充一个与岗位相关的案例，供您参考。若暂不考虑，我就不再跟进。':'例如：您好，想确认是否还需要补充项目说明。如有需要，我可以提供。';card.append(text);
    const hours=input(String(f.hours),{type:'number',min:i?48:24,max:720});hours.id='follow-hours-'+i;card.append(field('距上一次发出消息至少多少小时',hours));$('followups').append(card);
  });
  $('resumeSelection').value=config.settings.resumeSelection||'first';$('batchLimit').value=config.settings.batchLimit;$('interval').value=config.settings.intervalSeconds;$('pauseAt').value=config.settings.pauseAtReplies;$('keepAwake').checked=config.settings.keepAwake;$('autoReply').checked=config.settings.autoReply;$('sendResume').checked=config.settings.sendResume;$('excludeWords').value=config.settings.excludeWords.join('\n');$('selectors').value=JSON.stringify(config.selectors,null,2);
  renderSourceStatus();
  $('keepListeningAfterBatch').checked=config.settings.keepListeningAfterBatch===true;$('autoReplyAfterBatch').checked=config.settings.autoReplyAfterBatch!==false;$('idleReplyEnabled').checked=config.settings.idleReplyEnabled!==false;
  renderImports();
  renderIndustries();renderRobotConfig();
}
function renderIndustries(){
  $('industryRules').replaceChildren();
  (config.industries||[]).forEach((x,i)=>{
    const card=make('details',undefined,'card');card.dataset.industry=String(i);card.append(make('summary',x.name||'新行业话术'));
    const name=input(x.name);name.dataset.industryName='';card.append(field('行业名称',name));
    const keys=textarea(x.keywords.join('\n'),2);keys.dataset.industryKeywords='';keys.placeholder='例如：审计\n会计\n财务';card.append(field('岗位／公司关键词（匹配一个即可）',keys));
    const greeting=textarea(x.greeting,3);greeting.dataset.industryGreeting='';card.append(field('该行业的介绍（空则继承方向／通用介绍）',greeting));
    C.ALL_FAQ.forEach(q=>{const a=textarea(x.answers[q.id],2);a.dataset.industryAnswer=q.id;a.placeholder='留空则继承方向／通用回答';card.append(field(q.title,a));});
    const remove=make('button','移除此行业','secondary');remove.type='button';remove.onclick=()=>{readForms();config.industries.splice(i,1);renderIndustries();};card.append(remove);$('industryRules').append(card);
  });
}
function renderRobotConfig(){
  const r=config.robot;$('replyLimit').value=r.limit;$('replyGreeting').value=r.greeting;$('rejectionText').value=r.rejectionText;
  $('replySendResume').checked=r.sendResume;$('replyRejection').checked=r.followRejection;$('replyNativeResume').checked=r.allowDefaultResume;$('replyListen').checked=r.keepListening;
  $('replyProfile').replaceChildren(new Option('自动按岗位匹配，未匹配用通用话术','auto'));config.profiles.filter(p=>p.enabled).forEach(p=>$('replyProfile').append(new Option('本批统一使用：'+p.name,p.id)));$('replyProfile').value=r.profileId;
  $('replyResume').replaceChildren(new Option('优先方向绑定；否则使用网站默认附件',''));config.attachments.forEach(x=>$('replyResume').append(new Option(x.name,x.key)));$('replyResume').value=r.resumeKey;
}
function renderRobot(){
  const r=state.robot,summary=r?.summary;
  const checked=r?.watch?.lastCheckAt;
  $('watchHealth').textContent=r?.continuous?(state.status==='running'?'● 消息值守已开启':'○ 消息值守已暂停')+'\n覆盖：消息列表中的已有与新联系人；不以首批数量结束。\n最近检查：'+(checked?new Date(checked).toLocaleTimeString():'正在连接')+' · 队列 '+(state.replyQueue||[]).length+' 个\n'+(state.status!=='running'?'防闲置睡眠：已释放（当前未运行）':config.settings.keepAwake?'防闲置睡眠：已开启；屏幕可熄灭':'防闲置睡眠：未开启')+'\n'+(r.watch?.limited?'本轮扫描达到 60 页上限，部分较早会话可能未覆盖。':''):'点击下方按钮自动打开消息页；不需要先手动点联系人。';
  $('replyStatus').textContent=r?(r.dryRun?'回测 · 不发送':'实际发送')+' · '+({running:'运行中',paused:'已暂停',blocked:'需要处理',idle:'未运行'}[state.status]||state.status):'尚未开始';
  const names={robot_entry:'打开消息页并定位左侧联系人',robot_scan:'选择下一位联系人',robot_open:'点击左侧头像／联系人行',robot_read:'打开右侧聊天后读取问题',robot_execute:'点击输入框、输入并发送',robot_pick:'第二轮检查附件',robot_watch:'监听新消息'};
  $('replyProgress').textContent=r?(r.source==='batch-complete'?'投递结束自动接管\n':r.source==='idle'?'空闲接管 · 只回复待答消息\n':'')+(r.continuous?'持续值守 · ':'第 '+r.round+' 轮 · ')+(names[state.task?.phase]||state.reason)+(r.continuous?' · 已触达 '+r.order.length+' 个会话\n':' · 本批 '+r.order.length+' / '+r.limit+' 个会话\n')+(config.settings.resumeSelection==='bound'?'附件：严格绑定文件':'附件：选择框第一份简历')+'\n'+(state.task?.job?.title||state.task?.row?.name||'')+' '+(state.task?.job?.company||'')+'\n'+(state.status==='running'?'':state.reason):'一键打开消息页，处理已有聊天；不依赖先批量投递。';
  $('replyStats').replaceChildren();if(summary)for(const [key,label] of Object.entries({opened:'已打开',processed:r.continuous?'累计处理轮次':'首轮已处理',introductions:r.dryRun?'拟发介绍':'已发介绍',replies:r.dryRun?'拟回复':'已回复',resumes:r.dryRun?'拟投附件':'已发附件',requests:'等待简历接受',rejections:r.dryRun?'拟追问':'已追问',skipped:'未执行步骤',manual:'待补话术',uncertain:'回执未确认'})){
    const el=make('div',undefined,'stat');el.append(make('strong',String(summary[key]||0)),make('small',label));$('replyStats').append(el);
  }
  $('replyTrace').replaceChildren();const events={watch_message:'新消息进入回复队列',watch_sweep:'完成一轮列表检查，继续值守',priority_scan:'只读扫描待回复会话',priority_ready:'优先队列已就绪',chat_ready:'右侧对话已打开',editor_clicked:'已点击输入框',text_entered:'文字已填入',send_clicked:'已点击发送按钮',outgoing_seen:'已看到发出的消息',click_inbox:'点击消息入口',waiting_inbox:'等待消息页加载',inbox_ready:'消息列表已找到',wrong_page:'工作页不符，重新进入',failed:'失败位置已记录',start:'启动',selected:'选择下一位',opened:'已点击左侧联系人',waiting_chat:'等待聊天加载',decision:'话术判断',preparing:'准备发送',dispatched:'即将点击提交按钮',confirmed:'回执确认',already_sent:'历史已有同文',planned:'回测拟发送',finished:'会话处理完成',skipped:'未执行',uncertain:'回执未确认',scroll_list:'滚动消息列表',seeking:'查找会话',second_round:'进入简历第二轮',rounds_complete:'两轮完成',replan:'有新消息，重新判断',waiting_list:'等待消息列表'};
  for(const e of (r?.trace||[]).slice(-100).reverse()){
    const box=make('details',undefined,'plan');box.append(make('summary',new Date(e.at).toLocaleTimeString()+' · '+(events[e.event]||e.event)+' · '+(e.company||e.name||e.reason||e.kind||'')));
    box.append(make('pre',JSON.stringify(e,null,2),'result'));$('replyTrace').append(box);
  }
}
function renderImports(){
  const box=$('importSummary');box.replaceChildren();box.append(make('h3','已读取 '+config.profiles.length+' 个方向 / '+config.attachments.length+' 份附件'));
  config.profiles.forEach(p=>box.append(make('p','方向：'+p.name)));config.attachments.forEach(r=>box.append(make('p','附件：'+r.name+(r.meta?'（'+r.meta+'）':''),'muted')));
}
async function currentWindowId(){try{return (await chrome.windows.getCurrent()).id;}catch{return null;}}
function syncTabSelects(){
  for(const id of ['targetTab','workTab']){$(id).replaceChildren();if(!tabs.length)$(id).append(new Option('尚未打开 BOSS 网站',''));
    tabs.forEach(t=>$(id).append(new Option((t.active?'当前 · ':'')+(t.title||'BOSS')+' · '+new URL(t.url).pathname,String(t.id))));$(id).value=String(targetTab||'');}
  $('sourceTab').replaceChildren();const sources=tabs.filter(t=>/\/web\/geek\/job(?:s|-recommend)?(?:[/?#]|$)/.test(t.url));
  if(!sources.length)$('sourceTab').append(new Option('请先打开官网职位列表',''));
  sources.forEach(t=>$('sourceTab').append(new Option((t.active?'当前 · ':'')+(t.title||'职位页')+' · 标签 '+t.id,String(t.id))));
  if(sources.some(t=>t.id===targetTab))$('sourceTab').value=String(targetTab);
}
async function refreshTabs(){tabs=await request('TABS');if(!tabs.some(t=>t.id===targetTab))targetTab=tabs.find(t=>t.active)?.id||tabs[0]?.id||null;syncTabSelects();}
for(const id of ['targetTab','workTab'])$(id).addEventListener('change',()=>{targetTab=Number($(id).value);syncTabSelects();});
$('sourceTab').addEventListener('change',()=>{targetTab=Number($('sourceTab').value);$('followActive').checked=false;syncTabSelects();});
function renderSourceStatus(){
  const enabled=config.profiles.filter(p=>p.enabled),bound=enabled.filter(p=>p.sourceUrl);
  $('sourceResult').textContent=bound.length?'已记录 '+bound.length+' 个方向的职位来源，可选重新读取当前网页。':'无需先连接列表；启动任务时会自动打开职位页。';
  $('runSourceCheck').textContent=bound.length===enabled.length&&enabled.length?'已记录职位来源。发送介绍后返回职位列表，继续下一个。':'开始时自动打开或复用职位页，按完整沟通次数循环。';
}
async function chooseSource(){
  tabs=await request('TABS');const t=C.selectJobTab(tabs,targetTab,{followActive:$('followActive').checked,windowId:await currentWindowId()});
  if(!t)throw Error('未找到职位列表页。请打开官网“职位”，不要停在在线简历或聊天页。');
  targetTab=t.id;syncTabSelects();return t;
}
async function inspectSource(maxAttempts=3){
  const t=await chooseSource();$('sourceResult').textContent='正在检测职位页（标签 '+t.id+'），不会发送…';
  let d;for(let attempt=0;attempt<maxAttempts;attempt++){try{d=await request('INSPECT',{tabId:t.id});}catch(e){if(attempt===maxAttempts-1||/旧版|验证|登录/.test(e.message))throw e;await new Promise(r=>setTimeout(r,550));continue;}if(d.canReadJobs||d.blocker)break;await new Promise(r=>setTimeout(r,550));}
  $('inspection').textContent=JSON.stringify(d,null,2);
  if(d.blocker)throw Error(d.blocker);
  if(!d.canReadJobs){$('sourceHelp').open=true;$('sourceResult').textContent='已经定位到职位页，但尚未读到有效岗位。候选卡片 '+(d.jobCandidatesCount??d.counts?.jobCards??0)+' 个。点击下面的“两处文字校准”或下载检测报告。';throw Error('职位页已找到，但卡片字段未识别；不是简历绑定选错了。');}
  return {t,d};
}
async function bindCurrentSource(maxAttempts=3){
  readForms();const {t,d}=await inspectSource(maxAttempts);config.profiles.forEach(p=>p.sourceUrl=t.url);
  const saved=await request('SAVE',{config});config=saved.config;renderSourceStatus();
  $('sourceResult').textContent='已记录：读到 '+(d.parsedJobsCount??d.counts?.jobCards??'多个')+' 个岗位；'+config.profiles.length+' 个方向共用此职位页。只读取，未发送。';
  msg('职位页已连接，可以直接到运行页选择数量并开始。');
}
function renderState(){
  if(state.workflow==='reply'&&lastWorkflow!=='reply')showStep(6);
  lastWorkflow=state.workflow||'outreach';
  const idle=state.idleAutomation;
  $('idleStatus').textContent=idle?.armed?'空闲接管已授权：不受机器人点击影响；当前动作收尾后进入第六步。全部暂停可取消。':idle?.triggeredAt?'已自动切入第六步；原投递进度与去重记录已保留。':'启动真实投递后开始检查；不会在安装或开机时擅自发送。电脑睡眠或浏览器关闭时无法执行。';

  renderRobot();
  const names={idle:'尚未开始',running:'运行中',paused:'已暂停',blocked:'已停止'};$('runStatus').textContent=state.pauseKind==='completed'&&state.idleAutomation?.armed?'本批结束 · 等待空闲':names[state.status]||state.status;$('runMode').textContent=state.mode==='preview'?'预览 · 不发送':'真实运行';const phases={jobs_entry:'自动打开职位页并等待岗位',scan:'查找下一个职位',initiate:'识别职位并点击立即沟通',continue:'点击继续沟通',await_chat:'等待聊天页面',intro:'填写并发送方向介绍',resume:'发送附件',restore:'返回职位列表',check_return:'等待职位列表',monitor_read:'处理回复与附件'};
  const progress=state.pending?.polls?'自动读取发送回执 '+state.pending.polls+'/3':state.workflow==='reply'?$('replyProgress').textContent:state.task?.reselect?'重新打开当前职位':phases[state.task?.phase]||state.reason;
  $('runReason').textContent=state.status==='running'?progress+(state.task?.job?' · '+state.task.job.title:''):state.reason;
  if(state.status==='running')msg('运行中：'+progress+(state.workflow==='reply'?'':'\n已发介绍 '+(state.stats.introductions||0)+' · 待处理会话 '+(state.replyQueue||[]).length+' · 需留意 '+(state.stats.attention||0)));
  else if(state.status==='blocked'||state.status==='paused')msg(state.reason,state.status==='blocked');
  $('stats').replaceChildren();const stats=[['已处理轮数',state.completedCycles||0],['确认发送并返回',state.liveVerified||0],['已建联',state.stats.contacts],['已发介绍',state.stats.introductions||0],['已回复',state.stats.replies||0],['已发附件',state.stats.resumes],['待处理会话',(state.replyQueue||[]).length],['未发起跳过',state.stats.skipped||0],['需留意 / 回执未确认',state.stats.attention||0],['自动重试',state.stats.retries||0],['待人工',Object.values(state.conversations).filter(x=>x.status==='manual').length]];
  stats.forEach(([label,value])=>{const div=make('div',undefined,'stat');div.append(make('strong',String(value)),make('small',label));$('stats').append(div);});
  $('pendingBox').hidden=!state.pending;$('pendingStatus').textContent=state.status!=='running'?'任务已暂停。点击“继续本批”后自动恢复。':state.pending?.stage==='preparing'?'正在识别页面和按钮，尚未提交发送。':'正在读取回执；仍未确认则记为待核验，返回列表继续，不重复发送。';$('plans').replaceChildren();for(const p of state.plans.slice(-40)){
    const div=make('div',undefined,'plan');div.append(make('strong',p.title),make('p',p.company),make('p',p.profile+' → '+p.resume,'meta'),make('p',p.greeting));$('plans').append(div);
  }
  if(!state.plans.length)$('plans').append(make('p','可直接开始自动沟通；需要查看队列时再选择只读预览。','muted'));
  $('manualList').replaceChildren();Object.values(state.conversations).filter(x=>x.status==='manual').slice(-40).forEach(x=>{const div=make('div',undefined,'plan');div.append(make('strong',x.job?.title||x.row?.name||'待处理会话'),make('p',x.job?.company||''),make('p',x.reason||'等待人工'));$('manualList').append(div);});
  $('logs').replaceChildren();state.logs.slice(0,60).forEach(l=>$('logs').append(make('div',new Date(l.at).toLocaleTimeString()+' '+l.text)));
}
function download(name,data){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const u=URL.createObjectURL(blob),a=make('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),5000);}
function newProfiles(names){return names.map((name,i)=>{const old=config.profiles.find(p=>p.name===name);return old||{id:'p:'+C.hash(C.compact(name)),name,sourceLabel:name,sourceUrl:'',resumeKey:'',greeting:'',enabled:true,overrides:Object.fromEntries(C.ALL_FAQ.map(q=>[q.id,'']))};});}
titles.forEach((title,i)=>{const b=make('button',(i+1)+' '+title);b.onclick=()=>showStep(i+1);$('steps').append(b);});
bind('prev',()=>showStep(step-1));bind('next',async()=>{await save();showStep(step+1);});bind('save',async()=>{await save();msg('配置已保存在本机。');});
bind('fullPage',()=>chrome.tabs.create({url:chrome.runtime.getURL('panel.html')}));
bind('openSite',async()=>{const d=await request('OPEN',{url:'https://www.zhipin.com/'});targetTab=d.id;await refreshTabs();});
bind('openResume',async()=>{const d=await request('OPEN',{url:'https://www.zhipin.com/web/geek/resume'});targetTab=d.id;await refreshTabs();});
bind('refreshTabs',refreshTabs);bind('refreshTabsBottom',refreshTabs);
bind('checkLogin',async()=>{const d=await request('INSPECT',{tabId:targetTab});$('loginResult').textContent=d.blocker|| (d.loggedIn?'检测到求职者页面。请继续准备方向与附件。':'未确认登录。请先在官网正常登录。');});
bind('readProfile',async()=>{
  readForms();const d=await request('READ_PROFILE',{tabId:targetTab});if(!d.directions.length&&!d.attachments.length)throw Error('本页没有识别到方向或附件。请选择在线简历页；仍为空时导出诊断。');
  if(d.directions.length)config.profiles=newProfiles(d.directions);
  if(d.attachments.length){config.attachments=d.attachments;for(const p of config.profiles)if(!config.attachments.some(r=>r.key===p.resumeKey))p.resumeKey='';}
  config=C.cleanConfig(config);renderConfig();await request('SAVE',{config});msg('已导入页面候选清单，请核对方向、文件名和更新时间。');
});
bind('applyManual',async()=>{
  readForms();const names=$('manualDirections').value.split('\n').map(C.normalize).filter(Boolean).slice(0,3),files=$('manualResumes').value.split('\n').map(C.normalize).filter(Boolean);
  if(!names.length||!files.length)throw Error('请分别填入方向和文件名');config.profiles=newProfiles(names);config.attachments=files.map(name=>({key:'r:'+C.hash(C.compact(name)+'|'),name,meta:''}));config=C.cleanConfig(config);renderConfig();await request('SAVE',{config});msg('已保存手动名称；真实发送仍会逐一核验附件。');
});
bind('bindSource',()=>bindCurrentSource());
bind('openBindJobs',async()=>{const d=await request('OPEN_JOBS',{tabId:targetTab});targetTab=d.id;await refreshTabs();$('followActive').checked=true;await bindCurrentSource(30);});
bind('calibrateSource',async()=>{
  await save();const t=await chooseSource();msg('现在点网页左侧一张卡片的岗位名，再点同一张卡片的公司名。不会发送。');
  const d=await request('CALIBRATE',{tabId:t.id});config.selectors={...config.selectors,...d.selectors};await request('SAVE',{config});$('selectors').value=JSON.stringify(config.selectors,null,2);await bindCurrentSource();
});
bind('quickDiagnostic',async()=>{const t=await chooseSource();const d=await request('DIAGNOSTIC',{tabId:t.id});download('社会边角料-职位页检测.json',d);msg('检测报告已保存。没有发送消息；发回这个文件即可校准。');});
bind('returnBinding',()=>{showStep(3);$('bindSource').scrollIntoView({block:'center'});});
bind('copyPrompt',async()=>{await navigator.clipboard.writeText(C.aiPrompt());msg('已复制。粘贴给你自己的 AI，再把它整理的 JSON 带回来。');});
bind('addIndustry',()=>{readForms();if(config.industries.length>=12)throw Error('最多设置 12 个行业');config.industries.push({name:'',keywords:[],greeting:'',answers:{}});renderIndustries();$('industryRules').lastElementChild.open=true;});
bind('importAI',async()=>{
  readForms();let text=$('aiJson').value.trim().replace(/^```(?:json)?\s*/,'').replace(/```$/,'');if(text.length>2000000)throw Error('导入内容过大');const d=JSON.parse(text);
  if(!d||typeof d!=='object'||Array.isArray(d))throw Error('需要 JSON 对象');
  if(d.answers)config.answers={...config.answers,...Object.fromEntries(C.ALL_FAQ.filter(q=>typeof d.answers[q.id]==='string').map(q=>[q.id,d.answers[q.id]]))};
  if(Array.isArray(d.directionAnswers))config.profiles.forEach((p,i)=>{for(const q of C.ALL_FAQ)if(typeof d.directionAnswers[i]?.[q.id]==='string')p.overrides[q.id]=d.directionAnswers[i][q.id];});
  if(Array.isArray(d.greetings))config.profiles.forEach((p,i)=>{if(typeof d.greetings[i]==='string')p.greeting=d.greetings[i];});
  if(Array.isArray(d.industries))config.industries=d.industries;
  if(Array.isArray(d.followups))config.followups=d.followups.slice(0,2);config=C.cleanConfig(config);renderConfig();await request('SAVE',{config});msg('已导入通用、方向和行业话术。缺失项保持留空；点击启动才会发送。');
});
bind('testRule',()=>{readForms();const c=C.cleanConfig(config),p=c.profiles.find(x=>x.id===c.robot.profileId);const d=C.robotPlan({chat:{title:p?.name||'',company:''},messages:[{id:'test',side:'in',text:$('testMessage').value}]},c,{},1);$('testResult').textContent=JSON.stringify(d,null,2);});
async function startReply(dryRun){
  readForms();const quantity=Number($('replyLimit').value);if(!Number.isInteger(quantity)||quantity<1||quantity>300)throw Error('回复数量请输入 1–300 内的整数');
  const started=await request('START_REPLY',{config,tabId:targetTab,dryRun,consent:true,continuous:!dryRun&&config.robot.keepListening});targetTab=started.tabId||targetTab;await refreshState();await refreshTabs();showStep(6);
}
bind('startReply',()=>startReply(false));bind('previewReply',()=>startReply(true));
bind('pauseReply',async()=>{await request('PAUSE');await refreshState();});
bind('resumeReply',async()=>{if(state.workflow!=='reply')throw Error('尚无回复批次，请点击一键自动回复');await request('RESUME',{consent:true});await refreshState();});
bind('exportReplyReport',async()=>{const d=await request('REPLY_REPORT',{includeText:$('reportIncludeText').checked});download('社会边角料-回复诊断.json',d);msg('回复执行记录已导出。');});
bind('start',async()=>{readForms();const quantity=Number($('batchLimit').value);if(!Number.isInteger(quantity)||quantity<1||quantity>300)throw Error('本批目标请输入 1–300 内的整数');await request('SAVE',{config});const started=await request('START',{tabId:targetTab,mode:$('mode').value,consent:true});targetTab=started.tabId||targetTab;await refreshState();await refreshTabs();});
bind('pause',async()=>{await request('PAUSE');await refreshState();});
bind('stopNew',async()=>{await request('STOP_NEW');await refreshState();});
bind('resume',async()=>{await request('RESUME',{consent:true});await refreshState();});
bind('inspect',async()=>{const d=await request('INSPECT',{tabId:targetTab});$('inspection').textContent=JSON.stringify(d,null,2);});
bind('exportDiagnostic',async()=>{const d=await request('DIAGNOSTIC',{tabId:targetTab});download('社会边角料-页面诊断.json',d);msg('诊断已导出。若检测未通过，把此文件发回即可；不需要密码或网页源码。');});
bind('applySelectors',async()=>{readForms();config.selectors=JSON.parse($('selectors').value||'{}');await request('SAVE',{config});msg('选择器已保存，请重新检测。');});
bind('exportConfig',async()=>{await save();download('社会边角料-个人配置-勿公开.json',config);});
bind('importConfig',()=>$('configFile').click());$('configFile').addEventListener('change',async ev=>{try{const f=ev.target.files[0];if(!f)return;if(f.size>2000000)throw Error('配置文件过大');config=C.cleanConfig(JSON.parse(await f.text()));await request('SAVE',{config});renderConfig();$('mode').value='preview';msg('配置已导入，尚未启动任务。');}catch(e){msg(e.message,true);}});
bind('clear',async()=>{if(!confirm('清除所有本机配置、对话状态和去重记录？清除后可能重复联系过去的岗位。'))return;await request('CLEAR');const d=await request('GET');config=d.config;state=d.state;renderConfig();renderState();showStep(1);});
async function refreshState(){const d=await request('GET');state=d.state;renderState();}
(async()=>{try{const d=await request('GET');config=C.cleanConfig(d.config);state=d.state;renderConfig();renderState();await refreshTabs();showStep(state.workflow==='reply'?6:state.runId?5:config.profiles.length?3:1);setInterval(()=>refreshState().catch(()=>{}),1000);}catch(e){msg(e.message,true);}})();

for(const button of document.querySelectorAll('[data-batch]'))button.addEventListener('click',()=>{$('batchLimit').value=button.dataset.batch;});
for(const button of document.querySelectorAll('[data-reply-batch]'))button.addEventListener('click',()=>{$('replyLimit').value=button.dataset.replyBatch;});

// Panel polling is not user activity. Only genuine keyboard/pointer events reset inactivity.
let lastPanelHuman=0;
for(const type of ['pointerdown','pointermove','keydown','wheel'])document.addEventListener(type,ev=>{if(!ev.isTrusted||Date.now()-lastPanelHuman<15000)return;lastPanelHuman=Date.now();request('HUMAN_ACTIVITY').catch(()=>{});},{capture:true,passive:true});
