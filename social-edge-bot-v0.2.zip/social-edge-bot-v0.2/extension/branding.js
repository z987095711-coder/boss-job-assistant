/* Local-only artwork installer. No upload, external library, image generation or network request. */
(()=>{
  'use strict';
  const $=id=>document.getElementById(id);let entries=null;
  const sizes=[16,32,48,128];
  const crcTable=Array.from({length:256},(_,i)=>{for(let j=0;j<8;j++)i=(i&1)?0xedb88320^(i>>>1):i>>>1;return i>>>0;});
  const crc=bytes=>{let c=0xffffffff;for(const b of bytes)c=crcTable[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0;};
  function storeZip(files){
    const enc=new TextEncoder(),chunks=[],central=[];let offset=0;
    for(const file of files){const name=enc.encode(file.name),bytes=file.bytes,checksum=crc(bytes);
      const local=new Uint8Array(30+name.length),v=new DataView(local.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint32(14,checksum,true);v.setUint32(18,bytes.length,true);v.setUint32(22,bytes.length,true);v.setUint16(26,name.length,true);local.set(name,30);
      const dir=new Uint8Array(46+name.length),d=new DataView(dir.buffer);d.setUint32(0,0x02014b50,true);d.setUint16(4,20,true);d.setUint16(6,20,true);d.setUint16(8,0x800,true);d.setUint32(16,checksum,true);d.setUint32(20,bytes.length,true);d.setUint32(24,bytes.length,true);d.setUint16(28,name.length,true);d.setUint32(42,offset,true);dir.set(name,46);
      chunks.push(local,bytes);central.push(dir);offset+=local.length+bytes.length;
    }
    const length=central.reduce((n,x)=>n+x.length,0),end=new Uint8Array(22),e=new DataView(end.buffer);e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,length,true);e.setUint32(16,offset,true);
    return new Blob([...chunks,...central,end],{type:'application/zip'});
  }
  function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);}
  $('pickLogo').onclick=()=>$('logoFile').click();
  if($('openBranding'))$('openBranding').onclick=()=>{$('branding').open=true;$('branding').scrollIntoView({block:'center'});};
  $('brandIcon').onclick=()=>{$('branding').open=true;$('branding').scrollIntoView({block:'center'});};
  $('logoFile').addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    try{
      if(file.size>12*1024*1024)throw Error('请使用 12 MB 以内的 PNG、JPG 或 WebP 原图。');
      if(!['image/png','image/jpeg','image/webp'].includes(file.type))throw Error('请选择 PNG、JPG 或 WebP 图片。');
      const bitmap=await createImageBitmap(file);if(!bitmap.width||!bitmap.height||bitmap.width*bitmap.height>50000000){bitmap.close();throw Error('图片尺寸过大或无效。');}
      entries=[];let preview='';const imageData={};
      for(const size of sizes){const canvas=document.createElement('canvas');canvas.width=canvas.height=size;const c=canvas.getContext('2d');c.imageSmoothingEnabled=true;c.imageSmoothingQuality='high';
        const scale=Math.min(size/bitmap.width,size/bitmap.height);const w=bitmap.width*scale,h=bitmap.height*scale;c.drawImage(bitmap,(size-w)/2,(size-h)/2,w,h);
        imageData[size]=c.getImageData(0,0,size,size);const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('未能生成图标');
        entries.push({name:'extension/icons/'+size+'.png',bytes:new Uint8Array(await blob.arrayBuffer())});if(size===128)preview=canvas.toDataURL('image/png');
      }
      bitmap.close();$('brandIcon').src=preview;
      // Temporary toolbar preview. Static manifest icons are installed via the ZIP below.
      if(chrome.action?.setIcon)await chrome.action.setIcon({imageData});
      $('downloadLogo').hidden=false;
      $('logoResult').textContent='原图已在本机转换。下载图标更新包，解压后把 extension 文件夹合并覆盖到当前安装目录，再在扩展页点击圆形刷新箭头。这样扩展库图标也会更新。仅选择图片还没有改写安装文件。';
    }catch(err){entries=null;$('downloadLogo').hidden=true;$('logoResult').textContent=err.message;}
  });
  $('downloadLogo').onclick=()=>{if(!entries)return;download(storeZip(entries),'social-edge-clown-icons.zip');};
  // Pure helper available for local automated ZIP integrity tests.
  globalThis.SBLBranding={storeZip};
})();
