/* 社会边角料 — dependency-free shared rules. No network or model calls. */
(function (root) {
  'use strict';
  const VERSION = '0.2.0';
  const normalize = s => String(s ?? '').normalize('NFKC').replace(/\s+/g, ' ').trim();
  const compact = s => normalize(s).replace(/\s/g, '');
  // Only explicit, non-role benefit labels may be dropped. Never fuzzy-match job types.
  function jobTitleBase(value){
    let text=normalize(value).replace(/[\u200b-\u200f\u2060\ufeff]/g,'');
    const benefit='(?:周末双休|双休|单休|大小周|五险一金|六险一金|七险一金|五险|包吃住|包吃|包住|带薪年假|年终奖|弹性工作)';
    const group=benefit+'(?:[ +＋/／、,，|｜-]+'+benefit+')*';
    const tail=new RegExp('(?:\\s*[-—–·|｜/／+＋]\\s*'+group+'|\\s*\\('+group+'\\)|\\s+'+group+')$');
    const head=new RegExp('^(?:'+group+'\\s*[-—–·|｜/／+＋]\\s*|\\('+group+'\\)\\s*|'+group+'\\s+)');
    for(let i=0;i<5;i++){const next=text.replace(tail,'').replace(head,'').trim();if(!next||next===text)break;text=next;}
    return compact(text).toLowerCase();
  }
  function compatibleJobTitle(a,b){
    const x=jobTitleBase(a),y=jobTitleBase(b);return !!x&&x===y;
  }
  function hash(s) { let h=2166136261; for(const ch of String(s)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);} return (h>>>0).toString(36); }
  // Eighteen conversational topics; old basic answers keep their original IDs.
  const FAQ = [
    {id:'experience',title:'有相关经验吗？做过什么、做了多久？',keys:['经验','经历','做过什么','从业多久','相关项目','项目经历','介绍一下自己','自我介绍'],hint:'分别写正式工作、实习、个人项目和研究时间，不把个人研究算成任职年限。'},
    {id:'previousJob',title:'上家公司／上一份工作是做什么的？你负责什么？',keys:['上家公司','上一家公司','上一家','上家','上一份','上份工作','之前的工作','以前的工作','原来的公司','之前在哪里','之前做什么','之前是做','之前是干','之前负责','以前做什么'],hint:'公司或行业 → 职位性质（正式／实习）→ 你的具体职责和可证实的成果。不要把客户公司写成任职公司。'},
    {id:'roleUnderstanding',title:'你对这个岗位有什么理解？为什么想做？',keys:['岗位理解','岗位的理解','岗位了解','岗位的了解','了解这个岗位','了解我们岗位','应聘原因','为什么应聘','为什么想做','为什么选择我们','了解这个职位'],hint:'建议按三个方向分别写：岗位目标 → 日常任务 → 自己能承担的部分；不替你回答没准备的专业知识题。'},
    {id:'skills',title:'会哪些工具／软件？哪些工作能独立完成？',keys:['技能','工具','软件','会哪些','擅长什么','独立完成','工作流程','工作流','熟悉哪些','会用什么','技术栈','怎么制作'],hint:'工具名称 → 实际使用程度 → 能独立交付什么；不熟悉的明确留空。'},
    {id:'portfolio',title:'有作品、项目案例或者演示吗？',keys:['作品','案例','作品集','项目链接','演示','项目成果'],hint:'只放获准公开的链接，并说清本人负责部分。不同方向可以用不同案例。'},
    {id:'status',title:'还在找工作吗？现在在做什么？',keys:['在职','还在找工作','还找工作','找工作吗','求职状态','考虑机会','考虑工作','找工作中','现在在做什么','目前在做什么','最近在做什么','现在做什么'],hint:'在职／离职／自由职业等真实状态，加一两句最近在做的事。'},
    {id:'gap',title:'为什么离职／转行？空窗期在做什么？',keys:['空窗','gap','转行','为什么离职','离职原因','为什么辞职','离职','这段时间在做什么','毕业后在做什么'],hint:'用客观、简短的说明；避免夸大未完成项目，也不必攻击前公司。'},
    {id:'salary',title:'期望薪资多少？',keys:['薪资','薪酬','工资','待遇','薪水','期望多少','月薪','年薪'],hint:'只填可以对外回复的期望区间；内部底线不要放入自动话术。'},
    {id:'industryExperience',title:'接触过我们这个行业吗？',keys:['行业经验','这个行业','我们行业','相关行业','行业背景','接触过'],hint:'写这个行业相关的真实项目，不把学习研究写成任职。'},
    {id:'projectRole',title:'项目中具体负责什么？',keys:['项目职责','项目负责','项目中负责','你负责哪','本人负责','负责什么部分','项目分工'],hint:'说明自己负责的部分，不把团队全部成果算在自己名下。'},
    {id:'projectProcess',title:'项目具体是怎么做的？',keys:['项目过程','项目怎么做','怎么做项目','实施过程','执行过程','制作过程','具体怎么做'],hint:'目标、步骤和交付结果，按行业分别填写。'},
    {id:'projectResults',title:'项目做出了什么结果？',keys:['项目效果','项目结果','项目成绩','效果如何','取得什么','量化成果','业绩'],hint:'仅写可证实的结果，没有数据不要编数字。'},
    {id:'strengths',title:'你有什么优势，为什么适合？',keys:['优势','适合这个岗位','为什么录用','为什么选你','竞争力','特长'],hint:'按行业选择最相关的经历与能力。'},
    {id:'collaboration',title:'如何与团队沟通协作？',keys:['团队协作','团队合作','协同','沟通能力','跨部门','团队配合'],hint:'写真实协作方式和案例。'},
    {id:'problemSolving',title:'遇到困难或问题怎么解决？',keys:['遇到困难','遇到问题','解决问题','解决困难','如何排查','项目难点'],hint:'用一个真实例子说明判断与处理过程。'},
    {id:'learning',title:'学习新工具或业务的能力如何？',keys:['学习能力','自学','新工具','学习新','学习速度','上手速度','快速上手'],hint:'用真实学习经历说明，不承诺未经验证的上手时间。'},
    {id:'careerPlan',title:'职业规划是什么，会长期做吗？',keys:['职业规划','职业发展','长期发展','未来规划','稳定性','长期做'],hint:'填写愿意对外表达的职业方向。'},
    {id:'workMode',title:'接受全职、兼职或项目合作吗？',keys:['工作形式','全职','兼职','项目合作','项目制','外包合作','合作方式'],hint:'只填已经确认接受的工作形式。'}
  ];
  const EXTRA_FAQ = [
    {id:'education',title:'学历、专业、学校',keys:['学历','什么专业','哪个专业','毕业院校','哪个学校','学位','科班','学的什么'],hint:'旧版已填答案会保留。'},
    {id:'location',title:'所在地、工作地点／远程／出差',keys:['在哪','哪里人','工作地点','接受异地','接受出差','接受远程','是否远程','哪个城市','到公司办公','来长沙','来深圳','来上海','来北京'],hint:'只写你确认能接受的地点和工作形式。'},
    {id:'availability',title:'何时可以到岗',keys:['到岗','入职时间','何时入职','什么时候入职','多久入职'],hint:'不是代你接受面试或签约。'}
  ];
  const ALL_FAQ=[...FAQ,...EXTRA_FAQ];
  function matchTopics(part){
    const text=part.toLowerCase();let hits=ALL_FAQ.filter(q=>q.keys.some(k=>text.includes(k.toLowerCase())));
    const add=id=>{if(!hits.some(q=>q.id===id))hits.push(ALL_FAQ.find(q=>q.id===id));};
    if(/(?:对|了解|理解|认识).{0,12}(?:岗位|职位)|(?:岗位|职位).{0,12}(?:了解|理解|认识|看法)/.test(text))add('roleUnderstanding');
    if(/(?:上家|上一家|上家公司|上一份|之前的|以前的).{0,12}(?:公司|工作|负责|职责|干什么)/.test(text))add('previousJob');
    // Context beats a bare keyword: these are one question, not two.
    if(hits.some(q=>q.id==='previousJob'))hits=hits.filter(q=>q.id!=='location');
    if(/(?:在职还是离职|离职还是在职|是否离职|已经离职|离职了吗)/.test(text)&&!/(?:原因|为什么)/.test(text)){hits=hits.filter(q=>q.id!=='gap');add('status');}
    if(hits.some(q=>q.id==='previousJob')&&!/(?:相关经验|几年|多久|经验)/.test(text))hits=hits.filter(q=>q.id!=='experience');
    if(hits.some(q=>q.id==='industryExperience'))hits=hits.filter(q=>q.id!=='experience');
    if(hits.some(q=>q.id==='learning')&&/学习|自学|上手/.test(text))hits=hits.filter(q=>q.id!=='skills');
    return hits;
  }
  function selectJobTab(tabs,selectedId,{followActive=true,windowId=null}={}){
    const candidates=tabs.filter(t=>safeUrl(t.url)&&/\/web\/geek\/job(?:s|-recommend)?(?:[/?#]|$)/.test(t.url));
    const local=candidates.filter(t=>windowId==null||t.windowId==null||t.windowId===windowId);
    const pool=local.length?local:candidates;
    if(followActive){const active=pool.find(t=>t.active);if(active)return active;}
    return pool.find(t=>t.id===selectedId)||pool.slice().sort((a,b)=>(b.lastAccessed||0)-(a.lastAccessed||0))[0]||null;
  }
  const STOP = /(?:不(?:太|是很|怎么)?(?:匹配|合适|符合)|不满足.*(?:要求|条件)|暂(?:时)?不考虑|不予录用|未通过|已招满|已经招满|岗位.{0,8}(?:关闭|取消)|无需(?:再)?联系|不要(?:再)?(?:联系|发|问)|别(?:再)?(?:联系|发|问)|请勿(?:再)?联系|停止联系|请停止|别烦|打扰了别|祝.{0,18}(?:找到|求职顺利)|不再继续沟通|不感兴趣|不需要了)/i;
  const HARD_STOP=/(?:不要|别|无需|请勿|不必|不用)(?:再)?(?:联系|打扰|发消息|发信息|追问|问了)|停止联系|请停止|别烦|别再发了|不要再发了|不再继续沟通/;
  const DECLINE=/(?:不(?:太|是很|怎么|大)?(?:匹配|合适|符合)|不满足.{0,20}(?:要求|条件)|暂(?:时)?不考虑|不予录用|未通过|招满|不感兴趣|祝.{0,18}(?:找到|求职顺利)|(?:抱歉|遗憾).{0,35}(?:考虑|需要|寻找|选择).{0,20}(?:更|其他|另外)|(?:感谢|谢谢).{0,12}(?:申请|投递).{0,20}(?:但是|不过|但).{0,25}(?:不同|其他|更适合))/;
  function rejectionIntent(text){
    const t=normalize(text);
    if(HARD_STOP.test(t))return {kind:'hard',keyword:'停止联系'};
    const candidate=/(抱歉|对不起|不好意思|遗憾|不符合|不合适|不匹配|未通过)/.exec(t)?.[0]||'';
    // Negative qualifications and apologies in normal questions are not rejections.
    const cleaned=t.replace(/(?:不是|并非|并不是|没有说|不是说|不代表|不意味着|并不代表|并不意味着)\s*(?:你|您)?\s*不(?:太)?(?:符合|合适|匹配)/g,'')
      .replace(/(?:是否|是不是|会不会)\s*不(?:太)?(?:符合|合适|匹配)[^，。！？!?]*/g,'');
    if(DECLINE.test(cleaned)||/(?:抱歉|对不起|不好意思|遗憾).{0,50}(?:无法|不能|没法).{0,15}(?:安排|录用|推进|面试|继续)|(?:岗位|职位).{0,10}(?:已关闭|取消招聘|停止招聘)|(?:决定|选择).{0,8}(?:其他|别的|另外).{0,8}(?:人选|候选人)|不(?:再)?(?:继续)?(?:推进|录用)|不符合.{0,20}(?:要求|条件)/.test(cleaned))return {kind:'soft',keyword:candidate||'拒绝语义'};
    if(/^(?:很|非常|十分|真的)?(?:抱歉|对不起|不好意思|遗憾)[，,。.!！\s]*$/.test(t))return {kind:'unclear',keyword:candidate};
    return {kind:'none',keyword:candidate};
  }
  const SENSITIVE = /(?:面试|试岗|试工|试做|试稿|笔试|身份证|银行卡|验证码|付款|缴费|交钱|押金|保证金|培训费|加(?:个|一下)?(?:微|微信|QQ)|手机号|电话号码|联系电话|微信号|合同|签约|录用通知|offer|实盘|年化|交易收益|投资业绩|英语水平|英文水平|英文面试|技术原理|算法题|代码题|客户资源)/i;
  const NO_RESUME = /(?:不用|无需|不要|不必|暂不|先不).{0,8}(?:发|提供|提交).{0,5}简历|(?:简历).{0,8}(?:不用|无需|不要|不必|暂不)/;
  const RESUME = /(?:发|提供|给|提交|传).{0,12}(?:简历)|(?:想要|索要|请求).{0,12}简历|简历.{0,10}(?:发|提供|给|提交|传)/;
  const IGNORE = /^(?:你好|您好|您好呀|哈喽|hello|hi|好的|好|嗯|嗯嗯|谢谢|感谢|收到|了解|ok|可以的|辛苦了|请问)[！!。.,，\s]*$/i;
  function defaults() {
    return {schemaVersion:3,version:VERSION,profiles:[],attachments:[],answers:Object.fromEntries(ALL_FAQ.map(x=>[x.id,''])),industries:[],
      robot:{limit:10,profileId:'auto',resumeKey:'',sendResume:true,followRejection:true,allowDefaultResume:true,keepListening:true,
        greeting:'您好，我正在寻找合适的工作机会，希望进一步了解贵公司的岗位要求。我可以根据岗位需要补充相关经历和作品，期待与您沟通。',
        rejectionText:'感谢您的回复。方便具体说一下主要是哪些要求不匹配吗？我希望了解需要补足的地方，也方便判断是否有其他更适合的岗位。'},
      followups:[{enabled:false,text:'',hours:48},{enabled:false,text:'',hours:72}],
      settings:{batchLimit:10,intervalSeconds:2,pauseAtReplies:4,keepAwake:true,autoReply:true,sendResume:true,resumeSelection:'first',keepListeningAfterBatch:false,autoReplyAfterBatch:true,idleReplyEnabled:true,excludeWords:[]},selectors:{}};
  }
  function str(s,max=2500){if(typeof s!=='string') return '';return s.replace(/\u0000/g,'').slice(0,max).trim();}
  function safeUrl(s) { try {const u=new URL(s);return u.protocol==='https:' && ['www.zhipin.com','zhipin.com'].includes(u.hostname)?u.href:'';} catch{return '';} }
  function cleanResume(r) {
    if(!r || typeof r!=='object')return null;
    const name=str(r.name,200);if(!name)return null;
    const meta=str(r.meta,180), key=str(r.key,250)||'r:'+hash(compact(name)+'|'+compact(meta));
    return {key,name,meta};
  }
  function cleanConfig(raw) {
    if(!raw || typeof raw!=='object' || Array.isArray(raw))throw Error('配置必须是 JSON 对象');
    const c=defaults();
    c.answers=Object.fromEntries(ALL_FAQ.map(q=>[q.id,str(raw.answers?.[q.id])]));
    c.attachments=(Array.isArray(raw.attachments)?raw.attachments:[]).slice(0,20).map(cleanResume).filter(Boolean);
    c.profiles=(Array.isArray(raw.profiles)?raw.profiles:[]).slice(0,3).map((p,i)=>({
      id:'p:'+hash(compact(str(p.name,100))),name:str(p.name,100),sourceUrl:safeUrl(p.sourceUrl),sourceLabel:str(p.sourceLabel||p.name,100),
      resumeKey:str(p.resumeKey,250),greeting:str(p.greeting,1200),enabled:p.enabled!==false,matchKeywords:words(p.matchKeywords),
      overrides:Object.fromEntries(ALL_FAQ.map(q=>[q.id,str(p.overrides?.[q.id])]))
    })).filter(p=>p.name);
    c.industries=(Array.isArray(raw.industries)?raw.industries:[]).slice(0,12).map(x=>({name:str(x.name,80),keywords:words(x.keywords),greeting:str(x.greeting,1200),answers:Object.fromEntries(ALL_FAQ.map(q=>[q.id,str(x.answers?.[q.id])]))})).filter(x=>x.name);
    const r=raw.robot||{};
    c.robot={...c.robot,limit:Math.max(1,Math.min(300,Math.trunc(Number(r.limit)||10))),profileId:str(r.profileId,120)||'auto',resumeKey:str(r.resumeKey,250),
      sendResume:r.sendResume!==false,followRejection:r.followRejection!==false,allowDefaultResume:r.allowDefaultResume!==false,keepListening:r.keepListening!==false,
      greeting:r.greeting===undefined?c.robot.greeting:str(r.greeting,1200),rejectionText:r.rejectionText===undefined?c.robot.rejectionText:str(r.rejectionText,600)};
    for(let i=0;i<2;i++){
      const f=raw.followups?.[i];c.followups[i]={enabled:f?.enabled===true,text:str(f?.text,600),hours:Math.max(i?48:24,Math.min(720,Number(f?.hours)|| (i?72:48)))};
    }
    const s=raw.settings||{};
    c.settings={batchLimit:Math.max(1,Math.min(300,Math.trunc(Number(s.batchLimit)||10))),
      intervalSeconds:Math.max(2,Math.min(600,Number(s.intervalSeconds)||2)),
      pauseAtReplies:Math.max(1,Math.min(20,Math.trunc(Number(s.pauseAtReplies)||4))),keepAwake:s.keepAwake!==false,
      autoReply:s.autoReply!==false,sendResume:s.sendResume!==false,resumeSelection:s.resumeSelection==='bound'?'bound':'first',keepListeningAfterBatch:s.keepListeningAfterBatch===true,autoReplyAfterBatch:s.autoReplyAfterBatch!==false,idleReplyEnabled:s.idleReplyEnabled!==false,
      excludeWords:(Array.isArray(s.excludeWords)?s.excludeWords:[]).map(v=>str(v,80)).filter(Boolean).slice(0,50)};
    // Only selectors, never executable JavaScript. Further DOM validation happens in adapter.
    const allowed=['directions','directionName','directionTabs','attachments','attachmentName','jobCards','jobTitle','jobCompany','jobDetail','detailTitle','detailCompany','conversationRows','conversationList','activeConversation','chatRoot','chatJobTitle','chatCompany','editor','messageRows','incoming','outgoing','messageText','resumeRows','resumeName','selectedResume','modal','sendButton'];
    for(const k of allowed){if(typeof raw.selectors?.[k]==='string')c.selectors[k]=str(raw.selectors[k],400);}
    return c;
  }
  function validate(c) {
    const errors=[];
    const active=c.profiles.filter(p=>p.enabled);
    if(!active.length)errors.push('至少启用一个从官网确认的方向');
    for(const p of active){
      if(/推荐|兼职/.test(p.sourceLabel) && ['推荐','兼职'].includes(compact(p.sourceLabel)))errors.push(p.name+'：不能绑定推荐或兼职入口');
      if(c.settings.sendResume&&c.settings.resumeSelection==='bound'&&!c.attachments.some(r=>r.key===p.resumeKey))errors.push(p.name+'：请选择有效附件，或关闭自动发送附件');
      if(!p.greeting)errors.push(p.name+'：首次方向介绍为空');
    }
    if(c.followups[1].enabled && !c.followups[0].enabled)errors.push('第二条跟进开启前，请先开启第一条');
    c.followups.forEach((f,i)=>{if(f.enabled&&!f.text)errors.push('跟进 '+(i+1)+' 已开启但未填写话术');});
    return errors;
  }
  function words(value){return (Array.isArray(value)?value:String(value||'').split(/[\n,，;；|]/)).map(x=>str(x,80)).filter(Boolean).slice(0,40);}
  function bestMatch(items,context,keys){
    const text=compact(context).toLowerCase();
    const scored=items.map(item=>({item,score:[...new Set(keys(item).map(compact).filter(x=>x.length>=2))].filter(k=>text.includes(k.toLowerCase())).reduce((n,k)=>n+k.length,0)})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score);
    return scored.length&&(!scored[1]||scored[0].score>scored[1].score)?scored[0].item:null;
  }
  function wording(c,chat={},conv={}){
    const context=[chat.title,chat.company,chat.industry].filter(Boolean).join(' '),profiles=c.profiles.filter(p=>p.enabled);
    let p=conv.profileId?(c.profiles.find(p=>p.id===conv.profileId)||conv.profile):null;
    let source=p?'已绑定方向':'';
    if(!p&&c.robot.profileId!=='auto'){p=profiles.find(p=>p.id===c.robot.profileId);source='指定方向';}
    if(!p){p=bestMatch(profiles,context,x=>[x.name,x.sourceLabel,...(x.matchKeywords||[])]);source=p?'关键词匹配方向':'';}
    if(!p&&profiles.length===1){p=profiles[0];source='唯一方向';}
    const industry=bestMatch(c.industries||[],context,x=>[x.name,...x.keywords]);
    const answers=Object.fromEntries(ALL_FAQ.map(q=>[q.id,industry?.answers[q.id]||p?.overrides?.[q.id]||c.answers[q.id]||'']));
    const key=conv.resume?.key||p?.resumeKey||c.robot.resumeKey;
    const resume=conv.resume||c.attachments.find(x=>x.key===key)||(c.attachments.length===1?c.attachments[0]:null);
    return {profile:p||null,source:source||'通用话术',industry:industry?.name||'',greeting:industry?.greeting||p?.greeting||c.robot.greeting,answers,resume};
  }
  function history(messages,c,conv={}){
    const introductions=new Set([c.robot.greeting,...c.profiles.map(p=>p.greeting),...(c.industries||[]).map(x=>x.greeting),conv.introText].filter(Boolean).map(compact));
    const seen=new Set(conv.seenInbound||[]),answered=new Set(conv.answered||[]);let introIndex=-1,lastAnswer=-1;
    messages.forEach((m,i)=>{
      if(m.side!=='out'||!outgoingConfirmed(m))return;
      if(introductions.has(compact(m.text))){introIndex=i;return;}
      if(!IGNORE.test(normalize(m.text))&&!/您的附件简历|请求发送.{0,12}简历|等待.{0,6}同意|^(?:你好|您好).{0,30}(?:感兴趣|期待).{0,25}(?:沟通|交流)/.test(m.text))lastAnswer=i;
    });
    for(let i=0;i<=lastAnswer;i++)if(messages[i].side==='in')seen.add(messages[i].id);
    const fresh=messages.filter(m=>m.side==='in'&&!seen.has(m.id));
    return {seenInbound:[...seen],answered:[...answered],introIndex,introExists:!!conv.introVerified||introIndex>=0,fresh};
  }
  function questionPlan(messages,config,profile={},conversation={},policy={}) {
    const inbound=messages.filter(m=>m.side==='in');
    // Reject/stop is checked over all visible inbound history, not just the newest bubble.
    if(!policy.handledRejection&&inbound.some(m=>STOP.test(normalize(m.text))))return {action:'close',reason:'对方已拒绝或要求停止联系'};
    if(conversation.uncertainWrite)return {action:'hold',reason:'该会话存在待核验发送，不自动重发'};
    if(conversation.status==='closed'||conversation.status==='manual')return {action:'hold',reason:'会话已转人工或结束'};
    const seen=new Set(conversation.seenInbound||[]);
    const fresh=inbound.filter(m=>!seen.has(m.id));
    if(!fresh.length)return {action:'none',reason:'没有未处理的新消息'};
    const text=fresh.map(m=>normalize(m.text)).join('；');
    const ids=fresh.map(m=>m.id);
    const total=new Set([...(conversation.seenInbound||[]),...inbound.map(m=>m.id)]).size;
    if(total>=config.settings.pauseAtReplies)return {action:'hold',ids,reason:'达到对方消息条数人工阈值'};
    if(SENSITIVE.test(text))return {action:'hold',ids,reason:'涉及人工决定、敏感资料或未覆盖的专业问题'};
    if(NO_RESUME.test(text))return {action:'none',ids,reason:'对方明确暂不需要简历'};
    const wantsResume=fresh.some(m=>m.resumeRequest) || RESUME.test(text);
    const parts=text.split(/[；;。！？!?\n]/).map(normalize).filter(Boolean);
    const matched=new Set();let unknown=false;
    for(const part of parts){
      if(IGNORE.test(part))continue;
      const hits=matchTopics(part);
      hits.forEach(q=>matched.add(q.id));
      if(!hits.length && !(RESUME.test(part)||fresh.some(m=>m.resumeRequest && normalize(m.text)===part)))unknown=true;
      // Conservative handling for common extra questions in a multi-question sentence.
      if(/年龄|婚育|结婚|有孩子|性别|政治面貌|是否党员|英语|英文|户籍|驾照|驾驶证|加班|单休|大小周|996/.test(part))unknown=true;
    }
    if(unknown)return {action:'hold',ids,reason:'存在未覆盖的问题，不能只回答一部分'};
    const keys=[...matched];
    if(keys.some(k=>(conversation.answered||[]).includes(k)))return {action:'hold',ids,reason:'相同问题已答过，避免机器人循环'};
    const values=keys.map(k=>str(profile.overrides?.[k]||config.answers[k]));
    if(values.some(v=>!v))return {action:'hold',ids,keys,missing:keys.filter((k,i)=>!values[i]),reason:'对应问题未填写已审核回答'};
    if(wantsResume && conversation.resumeStatus==='sent' && !keys.length)return {action:'hold',ids,reason:'该会话已发过附件，重复索要交给人工'};
    return {action:wantsResume?'resume':values.length?'reply':'none',ids,keys,text:values.join('\n\n'),reason:values.length?'匹配到已审核问答':wantsResume?'收到简历请求':'无需回复的简短确认'};
  }
  function robotPlan(snap,c,conv={},round=1,policy={}){
    const ms=snap.messages||[],ins=ms.filter(m=>m.side==='in'),h=history(ms,c,conv),w=wording(c,snap.chat||conv.job||{},conv);
    const result={steps:[],reason:'没有待回复问题',history:h,wording:w,keys:[],missing:[]};
    if(conv.hardStop||ins.some(m=>HARD_STOP.test(normalize(m.text))))return {...result,terminal:'closed',hardStop:true,reason:'对方明确要求不再联系'};
    if(conv.uncertainWrite)return {...result,terminal:'manual',reason:'该会话有提交结果未确认的操作，不重发'};
    if(ms.some(m=>m.side==='unknown'))return {...result,terminal:'manual',reason:'消息发出方无法识别'};
    // Idle takeover answers pending inbound messages only; it is not a follow-up campaign.
    const lastHuman=ms.filter(m=>['in','out'].includes(m.side)).at(-1);
    const ownPendingContinuation=conv.pendingReply&&lastHuman?.side==='out'&&messageKey(lastHuman.text)===messageKey(conv.lastBotOutboundText||conv.introText||'');
    const outstandingCard=(h.fresh.some(m=>m.resumeRequest)||snap.resumeConsentAvailable)&&conv.resumeStatus!=='sent'&&!snap.resumeReceipt;
    if(policy.onlyPending&&!outstandingCard&&(!h.fresh.length&&!conv.resumeRequested&&conv.resumeStatus!=='selecting'||lastHuman?.side==='out'&&!ownPendingContinuation))return {...result,reason:'最后一句已由我方发出或没有待答消息，等待对方；不追加催促'};
    if(h.fresh.length&&rejectionIntent(h.fresh.at(-1).text).kind==='unclear')return {...result,terminal:'manual',needsAnswer:true,reason:'仅有道歉词，拒绝意图不明确；不自动追问'};
    const lastDecline=ins.findLastIndex(m=>rejectionIntent(m.text).kind==='soft'),softHistory=lastDecline>=0;
    const rejected=softHistory&&!ins.slice(lastDecline+1).some(m=>!IGNORE.test(normalize(m.text)));
    const intro=()=>{if(!h.introExists&&w.greeting)result.steps.push({kind:'intro',text:w.greeting,allowSoftRejection:softHistory,keys:[]});};
    if(rejected){
      if(!c.robot.followRejection)return {...result,terminal:'closed',reason:'普通拒绝追问未启用'};
      intro();
      const asked=conv.rejectionAsked||ms.some(m=>m.side==='out'&&compact(m.text)===compact(c.robot.rejectionText));
      if(!asked&&c.robot.rejectionText)result.steps.push({kind:'rejection',text:c.robot.rejectionText,allowSoftRejection:true,keys:[]});
      return {...result,terminal:'declined',reason:asked?'已追问一次原因，不重复追问':'普通拒绝：补介绍并礼貌追问一次'};
    }
    intro();
    const firstFile=c.settings.resumeSelection!=='bound';
    const newResumeCard=h.fresh.some(m=>m.resumeRequest);
    const resumeDone=conv.resumeStatus==='sent'||snap.resumeReceipt||((conv.resumeStatus==='waiting'||snap.resumeWaiting)&&!newResumeCard);
    const noResume=ins.some(m=>NO_RESUME.test(normalize(m.text)));
    const cfg={...c,answers:w.answers,settings:{...c.settings,pauseAtReplies:Number.MAX_SAFE_INTEGER}};
    const plan=questionPlan(ms,cfg,{}, {...conv,...h,status:'waiting'}, {handledRejection:true});
    result.keys=plan.keys||[];result.missing=plan.missing||[];result.reason=plan.reason;
    result.ackIds=plan.action==='none'?(plan.ids||[]):[];
    const requestMessages=h.fresh.filter(m=>m.resumeRequest||RESUME.test(normalize(m.text)));
    const requested=plan.action==='resume'||((requestMessages.length||conv.resumeRequested||snap.resumeConsentAvailable)&&!noResume&&!SENSITIVE.test(h.fresh.map(m=>m.text).join('；')));
    if(plan.text)result.steps.push({kind:'reply',text:plan.text,ids:plan.ids,keys:plan.keys,wantsResume:!!requested,allowSoftRejection:softHistory});
    if(plan.action==='hold')result.needsAnswer=true;
    if(requested&&!resumeDone&&c.robot.sendResume){
      const native=ins.some(m=>m.resumeRequest);
      const resumeIds=requestMessages.filter(m=>!matchTopics(m.text).length).map(m=>m.id);
      result.steps.push({kind:firstFile||conv.resumeStatus==='selecting'||snap.resumePickerOpen?'resume':c.robot.allowDefaultResume?(native?'resumeConsent':'resumeOffer'):'resume',resume:w.resume,ids:resumeIds,keys:[],requested:true,allowSoftRejection:softHistory});
    }else if(!policy.onlyPending&&round===2&&!h.fresh.length&&!resumeDone&&!noResume&&c.robot.sendResume&&(h.introExists||conv.introVerified)){
      const after=(conv.roundInbound||[]);const newInbound=ins.some(m=>!after.includes(m.id));
      if(!newInbound)result.steps.push({kind:firstFile?'resume':c.robot.allowDefaultResume?'resumeOffer':'resume',resume:w.resume,keys:[],requested:false,allowSoftRejection:softHistory});
    }
    if(!result.steps.length&&resumeDone)result.reason+='；附件已经发送或等待对方接受';
    return result;
  }
  function dueFollowup(conversation,config,now=Date.now()) {
    if(!['waiting','considering'].includes(conversation.status))return null;
    if(conversation.unhandledInbound || conversation.pending || conversation.resumeStatus==='waiting')return null;
    const i=conversation.followupsSent||0;if(i>=2)return null;
    const f=config.followups[i];if(!f?.enabled||!f.text)return null;
    const base=conversation.lastOutboundAt||0;
    if(!base || now-base<f.hours*3600000)return null;
    return {index:i,text:f.text};
  }
  function sameResume(expected,actual) {
    if(!expected||!actual||compact(expected.name)!==compact(actual.name))return false;
    // If a captured upload timestamp/size changes, fail closed instead of silently switching files.
    if(expected.meta && compact(expected.meta)!==compact(actual.meta))return false;
    return true;
  }
  // Listeners only add work. Only the worker may consume it and operate the page.
  function enqueue(s,key,reason='message',now=Date.now()) {
    const conv=s.conversations[key];if(!conv||['manual','closed'].includes(conv.status))return;
    s.replyQueue ||= [];
    let item=s.replyQueue.find(x=>x.chatKey===key);
    if(!item){item={chatKey:key,reasons:[],revision:0,firstAt:now,dueAt:now};s.replyQueue.push(item);}
    if(!item.reasons.includes(reason))item.reasons.push(reason);
    item.revision++;item.updatedAt=now;
    // Merge short bursts, but a continuously typing person cannot postpone the queue forever.
    if(reason==='message')item.dueAt=Math.min(item.firstAt+2500,now+750);
    return item;
  }
  function ingestActivity(s,activity,now=Date.now()) {
    s.activity ||= {};let changed=0;
    for(const row of (activity?.rows||[]).slice(0,500)){
      if(typeof row.key!=='string'||!row.key||row.key.length>300||['__proto__','constructor','prototype'].includes(row.key)||row.system||typeof row.token!=='string')continue;
      if(s.workflow==='reply'&&s.robot?.continuous&&!s.conversations[row.key]){
        s.conversations[row.key]={key:row.key,status:'waiting',seenInbound:[],answered:[],watchDiscovered:true,
          job:{key:'chat-job:'+hash(row.key),title:str(row.title,160),company:str(row.company,160)},row:{key:row.key,name:str(row.name,100),company:str(row.company,160),title:str(row.title,160)}};
      }
      if(!s.conversations[row.key])continue;
      const old=s.activity[row.key]||{};
      const firstReview=s.robot?.continuous&&s.conversations[row.key].watchQueuedRun!==s.runId;
      if(firstReview){s.conversations[row.key].watchQueuedRun=s.runId;if(enqueue(s,row.key,row.lastSide==='out'?'review':'message',now))changed++;}
      const incomingChange=old.rowToken!==undefined&&old.rowToken!==row.token&&(row.lastSide!=='out'||row.unread===true);
      if(incomingChange||(row.unread===true&&old.unread!==true)){
        if(enqueue(s,row.key,'message',now))changed++;
      }
      s.activity[row.key]={...old,rowToken:row.token,unread:row.unread===true,lastSide:row.lastSide||'',seenAt:now};
    }
    const a=activity?.active;
    if(a?.key&&s.conversations[a.key]&&typeof a.token==='string'){
      const old=s.activity[a.key]||{};
      if(old.activeToken!==a.token&&a.hasInbound){if(enqueue(s,a.key,'message',now))changed++;}
      s.activity[a.key]={...old,activeToken:a.token};
    }
    s.activityAt=now;return changed;
  }
  function nextQueued(s,now=Date.now()) {
    const priority=x=>s.robot?.continuous&&s.activity[x.chatKey]?.unread?-2:s.robot?.continuous&&s.activity[x.chatKey]?.lastSide==='in'?-1:x.reasons.some(r=>['message','resume-request'].includes(r))?0:x.reasons.includes('resume')?1:2;
    return (s.replyQueue||[]).filter(x=>x.dueAt<=now&&s.conversations[x.chatKey]&&!['manual','closed'].includes(s.conversations[x.chatKey].status))
      .sort((a,b)=>priority(a)-priority(b)||a.firstAt-b.firstAt)[0]||null;
  }
  function finishQueued(s,task) {
    // Do not erase a message that arrived while this conversation was being processed.
    s.replyQueue=(s.replyQueue||[]).filter(x=>x.chatKey!==task.chatKey||x.revision!==task.queueRevision);
    s.replyStreak=(s.replyStreak||0)+1;
  }
  function initialState() {return {version:VERSION,status:'idle',reason:'尚未开始',runId:'',epoch:0,mode:'preview',jobTabId:null,chatTabId:null,
    profileIndex:0,task:null,scanTurns:0,monitorIndex:0,nextAt:0,pending:null,stopNew:false,
    replyQueue:[],activity:{},activityAt:0,replyStreak:0,nextTaskAt:0,completedCycles:0,unconfirmedOps:{},idleAutomation:{armed:false},pauseKind:'',
    stats:{contacts:0,introductions:0,resumes:0,replies:0,followups:0,preview:0,skipped:0,retries:0,attention:0},seenJobs:{},conversations:{},previewJobs:{},plans:[],logs:[],liveVerified:0};}
  function newBatch(old,mode) {
    return {...old,status:'running',reason:'开始新批次',runId:Date.now().toString(36)+'-'+hash(Math.random()),epoch:old.epoch+1,mode,task:null,pending:null,recovered:null,lastError:null,
      workflow:'outreach',robot:null,completedCycles:0,unconfirmedOps:old.unconfirmedOps||{},idleAutomation:{armed:false},pauseKind:'',profileIndex:0,scanTurns:0,monitorIndex:0,nextAt:0,nextTaskAt:0,activityAt:0,replyStreak:0,replyQueue:old.replyQueue||[],activity:old.activity||{},stopNew:false,manualMonitor:false,stopReason:'',liveVerified:0,monitorDue:false,previewJobs:{},plans:[],stats:{contacts:0,introductions:0,resumes:0,replies:0,followups:0,preview:0,skipped:0,retries:0,attention:0}};
  }
  // Receipt comparison strips layout-only whitespace/zero-width marks, not visible status words.
  const messageKey=text=>compact(text).replace(/[\u200B-\u200D\u2060\uFEFF]/g,'');
  const outboundToken=ms=>hash(ms.filter(m=>m.side==='out').map(m=>m.id+'|'+messageKey(m.text)).join('\n'));
  const outgoingConfirmed=m=>m.side==='out'&&!['failed','sending'].includes(m.delivery);
  function textReceipt(ms,text,evidence={}){
    const matches=ms.filter(m=>m.side==='out'&&messageKey(m.text)===messageKey(text));
    const good=matches.filter(outgoingConfirmed);
    const beforeIds=evidence.beforeIds;
    const fresh=Array.isArray(beforeIds)&&good.some(m=>m.stableId&&!beforeIds.includes(m.id));
    const grew=Number.isInteger(evidence.beforeCount)&&good.length>evidence.beforeCount;
    if(fresh||grew)return {verified:true,reason:'当前会话中出现对应的我方消息'};
    if(matches.some(m=>m.delivery==='failed'))return {verified:false,definitiveFailure:true,reason:'对应消息显示发送失败，不自动重发'};
    return {verified:false,reason:matches.some(m=>m.delivery==='sending')?'对应消息仍在发送中':'暂未读取到对应的我方消息'};
  }
  function replyPriority(row,conv={}){
    if(conv.hardStop||conv.status==='closed')return {rank:6,reason:'已结束联系'};
    if(row.unread)return {rank:0,reason:'有未读消息，优先打开核验'};
    if(row.needsReply||row.lastSide==='in'||conv.pendingReply)return {rank:1,reason:'对方最后发言或已读未答'};
    if(conv.uncertainWrite)return {rank:4,reason:'待核验发送，只读核对'};
    if(row.lastSide==='out'||conv.lastMessageSide==='out')return {rank:3,reason:'我方最后发言，等待对方'};
    return {rank:2,reason:'发送方未知，打开后判断'};
  }
  const IDLE_REPLY_SECONDS=7200;
  function idleEligible(s,c,now=Date.now()){
    const a=s.idleAutomation;
    return !!a?.armed&&c.settings.idleReplyEnabled!==false&&s.mode==='live'&&s.workflow!=='reply'&&
      (s.status==='running'||s.status==='paused'&&s.pauseKind==='completed')&&
      now-Math.max(a.armedAt||now,a.lastHumanAt||0)>=IDLE_REPLY_SECONDS*1000;
  }
  function aiPrompt() {
    return '请仅用我确认的真实资料整理求职话术，学历、工作、客户、业绩不编造；缺失项留空。不含身份证、银行信息、验证码或内部薪资底线。只返回 JSON。greetings 和 directionAnswers 对应三个求职方向。answers 含18个常用问题及学历、地点、到岗；experience、previousJob、roleUnderstanding、skills 分开。industries 按我确认的行业填写名称、岗位关键词和差异话术，行业未知留空；同题可按行业强调不同真实经历。followups 两条默认关闭，仅用于未回复或尚在考虑；普通拒绝的一次原因追问由回复机器人单独设置。\n'+JSON.stringify({greetings:['','',''],answers:Object.fromEntries(ALL_FAQ.map(q=>[q.id,'【'+q.title+'】'])),directionAnswers:[{},{},{}],industries:[],followups:[{enabled:false,text:'',hours:48},{enabled:false,text:'',hours:72}]},null,2);
  }
  const api={VERSION,rejectionIntent,jobTitleBase,compatibleJobTitle,messageKey,outboundToken,outgoingConfirmed,textReceipt,replyPriority,IDLE_REPLY_SECONDS,idleEligible,FAQ,EXTRA_FAQ,ALL_FAQ,matchTopics,selectJobTab,normalize,compact,hash,defaults,cleanConfig,validate,questionPlan,robotPlan,wording,history,words,dueFollowup,sameResume,enqueue,ingestActivity,nextQueued,finishQueued,initialState,newBatch,aiPrompt,safeUrl,STOP,HARD_STOP,DECLINE,NO_RESUME};
  root.SBLCore=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(globalThis);
