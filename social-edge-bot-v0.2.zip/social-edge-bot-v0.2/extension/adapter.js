/* Visible-DOM adapter. Selectors are provisional until tested on the user's site.
   Never calls private endpoints, extracts cookies, defeats CAPTCHA, or parses PDFs. */
(function(root){
  'use strict';if(root.SBLAdapter)return;
  const C=root.SBLCore, N=C.normalize, T=e=>N(e?.innerText||e?.textContent||'');
  const D={
    directions:['[data-sbl-direction]','.resume-item-hope .item','.resume-expect .item','.expectation-item','.job-want-item','.expect-item'],
    directionName:['[data-sbl-direction-name]','.job-name','.expect-job','.name','.title'],
    directionTabs:['[data-sbl-direction-tab]','.job-search-wrapper .job-tab','.job-expect-wrapper .job-tab','.job-recommend .job-tab','.job-tab','.job-tab-item','.expect-item','.expect-tab','.expect-job-item','[role="tab"]'],
    attachments:['[data-sbl-attachment]','.attachment-item','.resume-file-item','.file-item','.resume-attachment li'],
    attachmentName:['[data-sbl-file-name]','.file-name','.resume-name','.name'],
    jobCards:['[data-sbl-job]','.job-card-wrap','.job-list-item','.job-card-list > li','.job-list-container > li','.job-card-wrapper','.job-list-box > li','.job-card-box','.job-list > li','.job-card','.job-item'],
    jobTitle:['[data-sbl-job-title]','.job-name','.job-title .title','.job-title','.job-info .title','a.job-info','.job-info-title','.name'],
    jobCompany:['[data-sbl-company]','.company-name','.company-title','.company-text','.company-info .name','.company-info .company-name','.boss-info .company-name','.company','.info-company'],
    jobDetail:['[data-sbl-detail]','.job-detail-box','.job-detail-container','.job-detail','.job-detail-wrapper','.job-detail-content','.job-detail-right'],
    detailTitle:['[data-sbl-detail-title]','.job-detail-header .job-detail-info .job-name','.job-detail-header .job-name','.job-name','h1'],
    detailCompany:['[data-sbl-detail-company]','.company-name','.boss-info .company','.company-info .name'],
    conversationRows:['[data-sbl-conversation]','.user-list .geek-item','.geek-list .geek-item','.user-list li','.chat-list .user-item','.user-list-item','.chat-list .geek-item','.friend-list .friend-item'],
    conversationList:['[data-sbl-conversation-list]','.user-list','.geek-list','.chat-list','.friend-list'],
    activeConversation:['[data-sbl-conversation].active','.user-list .geek-item.active','.user-list .geek-item.selected','.user-list .geek-item.current','.user-list li.active','.chat-list .user-item.active','.user-list-item.active','.chat-list .geek-item.active','.friend-list .friend-item.active'],
    chatRoot:['[data-sbl-chat]','.chat-conversation','.chat-container','.chat-room','.chat-box'],
    chatJobTitle:['[data-sbl-chat-job]','.chat-position .job-name','.job-position .job-name','.chat-job-info .job-name','.chat-job-name','.chat-position a','.job-card .job-name','.position-content .job-name','.chat-position .name','.chat-job .job-name'],
    chatCompany:['[data-sbl-chat-company]','.chat-user .company-name','.chat-header .company-name','.chat-info .company-name','.chat-top-info .company-name','.chat-user-info .company-name'],
    editor:['[data-sbl-editor]','#chat-input','.chat-editor [contenteditable="true"]','.chat-input [contenteditable="true"]','[contenteditable="true"][role="textbox"]','textarea.input-area','textarea','[contenteditable="true"]'],
    messageRows:['[data-sbl-message]','.message-item','.chat-message-item','.chat-message','.chat-content .item'],
    incoming:['[data-sbl-side="in"]','.item-friend','.message-received','.message-other','.is-other'],
    outgoing:['[data-sbl-side="out"]','.item-myself','.message-sent','.message-self','.is-self'],
    messageText:['[data-sbl-message-text]','.text','.message-text','.text-content','.message-bubble'],
    resumeRows:['.resume-list > .list-item','[data-sbl-resume-row]','.resume-item','.resume-file-item','.file-item','.attachment-item','li'],
    resumeName:['[data-sbl-file-name]','.resume-name','.file-name','.name'],
    selectedResume:['.resume-list .list-item.selected','.resume-list .list-item.active','.resume-list .list-item.is-selected','.resume-list .list-item.is-checked','[data-sbl-resume-row].selected','.resume-item.active','.resume-item.selected','.file-item.active','.file-item.selected','[aria-selected="true"]','[aria-checked="true"]'],
    modal:['[role="dialog"]','.dialog-wrap','.dialog-container','.dialog-body','.boss-dialog','.dialog','.modal','.greet-boss-dialog'],
    sendButton:['[data-sbl-send]','.btn-send','.send-btn','button[type="submit"]']
  };
  // Actual desktop structures from the user's 0.1.8 failure report.
  D.conversationRows.unshift('.user-list .friend-content');
  D.activeConversation.unshift('.user-list .friend-content.selected');
  D.conversationList.unshift('.user-list-content');
  let overrides={},lastTitleCheck=null,clickedConversation=null,writingInput=null,clickedJob=null;
  const uiTrace=[];
  function ui(event,el,details={}){uiTrace.push({at:Date.now(),event,target:el?shape(el):null,...details});if(uiTrace.length>160)uiTrace.shift();}
  function setSelectors(s){overrides=s||{};}
  function visible(e){if(!e||(!(e instanceof Element)&&e.nodeType!==1)||!e.isConnected)return false;const win=e.ownerDocument?.defaultView;const s=win?win.getComputedStyle(e):getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity)!==0&&e.getClientRects().length>0;}
  function enabled(e){
    if(!e||!visible(e)||e.disabled||e.getAttribute('disabled')!==null||e.getAttribute('aria-disabled')==='true')return false;
    if(/(?:^|[\s_-])(?:disabled|unable|loading)(?:$|[\s_-])/.test(e.className||''))return false;
    const style=e.ownerDocument?.defaultView?.getComputedStyle(e)||getComputedStyle(e);return style.pointerEvents!=='none';
  }
  const scopeCache=new WeakMap();
  function scopes(scope=document){
    const now=root.performance?.now?.()??Date.now(),cached=scopeCache.get(scope);if(cached&&now-cached.at<200)return cached.scopes;
    const out=[scope],seen=new Set(out);
    for(let i=0;i<out.length&&i<24;i++)for(const e of out[i].querySelectorAll('*')){
      const shadow=e.shadowRoot;if(shadow&&!seen.has(shadow)){seen.add(shadow);out.push(shadow);}
      if(e.tagName==='IFRAME'&&visible(e))try{const d=e.contentDocument;if(d&&d.body&&!seen.has(d)){seen.add(d);out.push(d);}}catch{}
    }
    scopeCache.set(scope,{at:now,scopes:out});return out;
  }
  function query(sel,scope=document){try{return [...new Set(scopes(scope).flatMap(s=>[...s.querySelectorAll(sel)]))].filter(visible);}catch{return [];}}
  function all(k,scope=document){for(const sel of overrides[k]?[overrides[k]]:(D[k]||[])){const es=query(sel,scope);if(es.length)return [...new Set(es)];}return [];}
  function one(k,scope=document){const es=all(k,scope);return es.length===1?es[0]:null;}
  function first(k,scope=document){return all(k,scope)[0]||null;}
  function exact(text,scope=document,includeDisabled=false){
    const wanted=C.compact(text), out=[];
    for(const e of query('button,a,[role="button"],.btn,span,div,h1,h2,h3,h4,h5,p',scope)){
      if(C.compact(T(e))!==wanted)continue;
      if([...e.children].some(ch=>visible(ch)&&C.compact(T(ch))===wanted))continue;
      const p=e.closest('button,a,[role="button"],.btn');
      out.push(p&&scope.contains(p)?p:e);
    }
    return [...new Set(out)].filter(includeDisabled?visible:enabled);
  }
  function exactOne(text,scope=document){const es=exact(text,scope);return es.length===1?es[0]:null;}
  function firstText(k,e){const a=first(k,e);return N(a?.getAttribute('title')||T(a));}
  function merged(k,scope=document){const sels=overrides[k]?[overrides[k]]:(D[k]||[]);return [...new Set(sels.flatMap(sel=>query(sel,scope)))];}
  function attr(e,names){for(const k of names){const v=e?.getAttribute(k);if(v)return v;}return '';}
  function fileMeta(s){const date=s.match(/20\d{2}[.\-/]\d{1,2}[.\-/]\d{1,2}(?:\s*\d{1,2}:\d{2})?/),size=s.match(/\d+(?:\.\d+)?\s*(?:KB|MB|GB|字节)/i);return [date?.[0]||'',size?.[0]||''].filter(Boolean).join(' | ');}
  function leafFiles(scope=document){return query('span,div,p,a',scope).filter(e=>/\.(pdf|docx?|rtf)$/i.test(T(e))&&T(e).length<210&&![...e.children].some(ch=>/\.(pdf|docx?|rtf)$/i.test(T(ch))));}
  function fileRows(scope,kind='attachments'){
    const named=all(kind,scope).filter(e=>/\.(pdf|docx?|rtf)/i.test(T(e)));
    if(named.length)return named;
    return leafFiles(scope).map(e=>{let p=e;for(let i=0;i<4&&p.parentElement&&p.parentElement!==scope;i++){const next=p.parentElement;if(leafFiles(next).length!==1||T(next).length>700)break;p=next;}return p;}).filter((e,i,a)=>a.indexOf(e)===i);
  }
  function readFile(e,kind='attachmentName'){
    let name=firstText(kind,e);if(!/\.(pdf|docx?|rtf)$/i.test(name))name=T(leafFiles(e)[0]);
    if(!name)return null;
    const meta=fileMeta(T(e));return {key:'r:'+C.hash(C.compact(name)+'|'+C.compact(meta)),name,meta};
  }
  function attachments(scope=document,kind='attachments') {return fileRows(scope,kind).map(el=>({el,...readFile(el,kind==='resumeRows'?'resumeName':'attachmentName')})).filter(x=>x.name);}
  function directions(){
    const rs=all('directions');let names=rs.filter(e=>!T(e).includes('兼职')).map(e=>firstText('directionName',e)||attr(e,['title','data-name'])||T(e).split(/\n|\s{2,}/)[0]);
    if(!names.length){
      // Prefer full-time expectation section; never import the recommendation tab as a direction.
      const heading=exactOne('全职职位');
      if(heading){let parent=heading.parentElement;for(let i=0;i<3&&parent;i++,parent=parent.parentElement){
        const cand=query('a,span,div',parent).filter(e=>e.children.length===0&&T(e).length<=60&&T(e).length>=2);
        const out=cand.map(T).filter(s=>!/^全职|^兼职|^[\d\sKk薪万元—~.,-]+$|行业不限|长沙|深圳|北京|上海|求职期望|期望职位/.test(s));
        if(out.length&&out.length<=6){names=out;break;}
      }}
    }
    return [...new Set(names.map(N).filter(s=>s && s.length<100 && !['推荐','兼职','全职职位','期望职位'].includes(s)))].slice(0,3);
  }
  function directionTab(label){
    const strip=s=>C.compact(s).replace(/\([^)]*\)$/,'');const name=strip(label);
    const navRoots=[];
    for(const e of exact('推荐')){let p=e.parentElement;for(let i=0;i<4&&p&&p!==document.body;i++,p=p.parentElement){if(exact('兼职',p).length&&T(p).length<400){navRoots.push(p);break;}}}
    const pool=[...new Set([...merged('directionTabs'),...navRoots.flatMap(e=>query('a,button,li,span,div',e).filter(x=>!x.children.length))])];
    const match=e=>strip(attr(e,['title','data-name'])||T(e))===name;
    let candidates=pool.filter(match);
    if(!candidates.length)candidates=exact(label);
    if(!candidates.length)candidates=pool.filter(e=>{const value=strip(attr(e,['title','data-name'])||T(e));const prefix=value.replace(/(?:…|\.{3}).*$/,'');return prefix.length>=3&&/…|\.{3}/.test(value)&&name.startsWith(prefix);});
    // A span nested in the matching tab represents the same control.
    candidates=[...new Set(candidates)].filter(e=>!candidates.some(x=>x!==e&&e.contains(x)));
    return candidates.length===1?candidates[0]:null;
  }
  function jobKey(el,title,company){
    const link=(el.matches('a[href]')?el:null)||query('a[href*="/job_detail/"]',el)[0];
    const url=link?.href||'';const id=attr(el,['data-jobid','data-job-id','data-securityid','data-sbl-job'])||url.match(/\/job_detail\/([^/?#.]+)/)?.[1];
    return {key:id?'job:'+id:'fp:'+C.hash(C.compact(title)+'|'+C.compact(company)),url:C.safeUrl(url)};
  }
  function jobCandidates(){
    const base=merged('jobCards');
    if(overrides.jobCards)return base; // A user calibration is authoritative; never silently ignore it.
    // Read-only fallback for renamed card wrappers, still requiring one title and company.
    const extras=query('[class*="job-card"],[class*="job-item"],li[class*="job"]');
    return [...new Set([...base,...extras])].slice(0,700);
  }
  function fieldText(k,el){
    for(const sel of overrides[k]?[overrides[k]]:D[k]){
      const nodes=query(sel,el);if(!nodes.length)continue;
      const texts=[...new Set(nodes.map(x=>N(x.getAttribute('title')||T(x))).filter(Boolean))];
      if(texts.length===1)return texts[0];
      if(texts.length>1&&['jobTitle','jobCompany'].includes(k))return ''; // Not one job card.
    }return '';
  }
  function parseJob(el){
    // The diagnostic identifies a.job-name inside .job-info, independently of old click calibration.
    const named=query('.job-info a.job-name',el);
    const titleNode=named.length===1?named[0]:null;
    const title=titleNode?readTitleNode(titleNode):cleanTitle(fieldText('jobTitle',el)),company=fieldText('jobCompany',el);
    if(!title||!company||title.length>140||company.length>140||T(el).length>1000)return null;
    return {el,title,company,...jobKey(el,title,company),summary:T(el).slice(0,350)};
  }
  function jobs(){
    const parsed=jobCandidates().map(parseJob).filter(Boolean);
    const innermost=parsed.filter(x=>!parsed.some(y=>x.el!==y.el&&x.key===y.key&&x.el.contains(y.el)));
    return innermost.filter((x,i,a)=>a.findIndex(y=>y.key===x.key)===i);
  }
  function cleanTitle(t){return N(t).replace(/[\u200b-\u200f\u2060\ufeff]/g,'').replace(/\s*\d+(?:\.\d+)?\s*[-~—]\s*\d+(?:\.\d+)?\s*(?:[kK万]|元\s*[/／]\s*[天日月年]).*$/,'').trim();}
  const titleKey=t=>C.compact(cleanTitle(t)).replace(/[\u200b-\u200f\u2060\ufeff]/g,'');
  function titleValues(el){return [...new Set([T(el),el?.getAttribute('title')||''].map(cleanTitle).filter(Boolean))];}
  function readTitleNode(el){
    const [text,tooltip]=titleValues(el);if(!text)return '';
    // Prefer rendered job text; a title attribute may be an unrelated navigation tooltip.
    return tooltip&&titleMatches(tooltip,text,true)?tooltip:text;
  }
  function selectedWithin(el,peers=[]){
    peers=peers.filter(x=>!peers.some(y=>x!==y&&x.contains(y)));
    for(let i=0;i<4&&el&&el!==document.body;i++,el=el.parentElement){
      if(peers.filter(x=>el===x||el.contains(x)).length>1)return false;
      if(/(?:^|[\s_-])(active|selected|current)(?:$|[\s_-])/.test(el.className||'')||el.getAttribute('aria-selected')==='true')return true;
    }return false;
  }
  function titleMatches(full,card,allowTruncated=false){
    const a=titleKey(full),b=titleKey(card);if(a===b)return true;
    const prefix=b.replace(/(?:…|\.{3}).*$/,'');
    return allowTruncated&&prefix.length>=6&&prefix!==b&&a.startsWith(prefix);
  }
  function detail(){
    let candidates=merged('jobDetail').filter(e=>firstText('detailTitle',e));
    const withButton=candidates.filter(e=>exactOne('立即沟通',e)||exactOne('继续沟通',e));
    if(withButton.length)candidates=withButton;
    candidates=candidates.filter(e=>!candidates.some(x=>x!==e&&e.contains(x)));
    const el=candidates.length===1?candidates[0]:null;if(!el)return null;
    const title=readTitleNode(first('detailTitle',el)),company=firstText('detailCompany',el);
    return {el,title,company};
  }
  function checkDetail(expected){
    const cards=jobs(),selected=cards.filter(j=>j.key===expected.key);
    const active=selected.length===1&&selectedWithin(selected[0].el,cards.map(j=>j.el));
    const selectedTitle=selected.length===1?selected[0].title:'';
    const aliases=[expected.title,...(active&&selectedTitle?[selectedTitle]:[])].filter(Boolean);
    const matches=title=>aliases.some(t=>titleMatches(title,t,active)||(active&&C.compatibleJobTitle(cleanTitle(title),cleanTitle(t))));
    let d=detail();
    // Only public job-name fields are included; no chat/body text or account identifiers.
    lastTitleCheck={cardTitle:selectedTitle,expectedTitle:expected.title,detailTitle:d?.title||'',activeCard:active,exactMatch:!!d&&aliases.some(t=>titleKey(t)===titleKey(d.title)),benefitMatch:!!d&&active&&aliases.some(t=>C.compatibleJobTitle(cleanTitle(t),cleanTitle(d.title))),normalizedCard:C.jobTitleBase(selectedTitle),normalizedDetail:C.jobTitleBase(d?.title||''),cardSelector:'.job-info a.job-name',detailSelector:'.job-detail-header .job-detail-info .job-name'};
    if(!d||!matches(d.title)){
      // Resolve renamed detail wrappers from the visible CTA and expected title.
      // A container holding the job list itself can never serve as a detail pane.
      const candidates=[];
      for(const button of [...exact('立即沟通'),...exact('继续沟通')]){
        let el=button.parentElement;
        for(let i=0;i<9&&el&&el!==document.body;i++,el=el.parentElement){
          if(cards.some(j=>el.contains(j.el)))break;
          const title=query('[title],h1,.job-name,.job-title,span',el).find(x=>titleValues(x).some(matches));
          if(title){candidates.push({el,title:titleValues(title).find(matches),company:firstText('detailCompany',el)});break;}
        }
      }
      const unique=candidates.filter((x,i,a)=>a.findIndex(y=>y.el===x.el)===i);
      d=unique.length===1?unique[0]:null;
    }
    if(!d||!matches(d.title))throw Error('未点击：详情标题未匹配所选职位；立即沟通按钮 '+exact('立即沟通').length+' 个，选中卡片 '+(active?'已识别':'未识别'));
    const detailIds=[attr(d.el,['data-job-id','data-jobid','data-sbl-detail-job']),...query('a[href*="/job_detail/"]',d.el).map(e=>e.href.match(/\/job_detail\/([^/?#.]+)/)?.[1]||'')].filter(Boolean).map(x=>x.replace(/^job:/,''));
    if(expected.key?.startsWith('job:')&&detailIds.length&&detailIds.some(x=>'job:'+x!==expected.key))throw Error('未点击：详情岗位 ID 与所选卡片不匹配');
    const companyOK=d.company?C.compact(d.company).includes(C.compact(expected.company)):active;
    if(!companyOK)throw Error(d.company?'未点击：详情公司与所选卡片不匹配':'未点击：详情没有公司字段，选中卡片状态也未识别');return d;
  }
  const rosterTime=s=>/^(?:\d{1,2}:\d{2}|\d{1,2}[/-]\d{1,2}|昨天|前天|星期[一二三四五六日天]|周[一二三四五六日天]|\d+|[·|｜…]+)$/.test(N(s));
  function contactSearch(){return query('input[placeholder],input[aria-label]').find(e=>/搜索.*(?:联系人|聊天记录)/.test(attr(e,['placeholder','aria-label'])));}
  function rosterIdentity(el){
    const leaves=query('span,div,p,a,strong,b',el).filter(e=>!e.children.length&&T(e)&&!rosterTime(T(e))&&!e.closest('button,[role="button"]'));
    if(!leaves.length)return {identityText:'',parts:[]};
    const last=leaves.at(-1);let head=leaves[0];
    // In the screenshot the first line is identity; the last line is a changing preview.
    // Never include the preview, time, unread count, or row position in the key.
    for(let p=head.parentElement;p&&p!==el&&!p.contains(last)&&!query('img,input',p).length&&T(p).length<=180;p=p.parentElement)head=p;
    const parts=leaves.filter(e=>head===e||head.contains(e)).map(T);
    return {identityText:parts.join(' '),parts};
  }
  function rosterSurface(){
    const search=contactSearch();if(!search)return null;
    for(let pane=search.parentElement,depth=0;pane&&pane!==document.body&&depth<8;pane=pane.parentElement,depth++){
      if(query('textarea,[contenteditable="true"]',pane).length)break;
      const candidates=[];
      const avatars=query('img,[class*="avatar"]',pane).filter(e=>!query('img,[class*="avatar"]',e).length&&!e.closest('.label-list,.filter-item,[role="tablist"]')&&!/filter-icon/.test(e.className||''));
      for(const avatar of avatars){
        let card=null;
        for(let p=avatar.parentElement;p&&p!==pane&&!p.contains(search);p=p.parentElement){
          if(avatars.filter(a=>p.contains(a)).length!==1||T(p).length>700)break;
          if(rosterIdentity(p).identityText.length>=2){card=p;break;}
        }
        if(card)candidates.push(card);
      }
      const rows=[...new Set(candidates)];if(rows.length)return {pane,search,rows};
    }
    return null;
  }
  function conversationRow(el,visual=el.matches('.friend-content')){
    const id=attr(el,['data-sbl-conversation','data-id','data-uid','data-boss-id','data-bossid','data-geekid','data-friend-id']);
    const identity=visual?rosterIdentity(el):{identityText:'',parts:[]};
    const name=T(query('[data-sbl-person],.geek-name,.user-name,.name-text,.name',el)[0])||identity.parts[0]||'';
    const company=T(query('[data-sbl-company],.company-name,.geek-company,.company',el)[0])||identity.parts[1]||'';
    const title=T(query('[data-sbl-row-job],.job-name,.position-name,.job-title',el)[0]);
    const key=id?'chat:'+id:(name&&company?'cfp:'+C.hash(C.compact(name)+'|'+C.compact(company)):identity.identityText?'visible:'+C.hash(C.compact(identity.identityText)):'');
    const summary=T(el).slice(0,240);
    const preview=attr(el,['data-last-message'])||T(query('[data-sbl-preview],.last-msg,.last-message,.last-msg-text,.message-preview,.msg-text',el)[0])||summary;
    const badges=query('[data-sbl-unread],.unread-count,.badge-count,.red-dot,.badge,.notice-badge',el);
    const rootUnread=attr(el,['data-unread','data-sbl-unread']);
    const unread=rootUnread==='true'||Number(rootUnread)>0||badges.some(x=>!['0','false'].includes(x.getAttribute('data-sbl-unread'))&&T(x)!=='0');
    const sideHint=attr(el,['data-last-side','data-last-sender','data-sbl-last-side']);
    const lastSide=/^(?:in|incoming|friend|boss)$/.test(sideHint)?'in':/^(?:out|outgoing|self|me)$/.test(sideHint)||/^(?:我|你|我方)\s*[:：]/.test(preview)||query('.last-msg .message-status.status-delivery,.last-msg .message-status.status-read,.last-msg .message-status.status-sending',el).length>0?'out':'';
    const needsReply=el.getAttribute('data-needs-reply')==='true'||query('[data-sbl-needs-reply="true"],.unreply-badge,.un-reply-badge,.pending-reply',el).length>0;
    const system=/^(?:BOSS助手|系统消息|职位推荐|招呼助手|全部|未读|新招呼|更多|AI筛选)$/.test(name)||/发布了新职位/.test(name)||el.getAttribute('data-type')==='system';
    return {el,key,name,company,title,identityText:identity.identityText,source:visual?'contact-search-avatar':'selector',system,summary,unread,lastSide,needsReply,token:C.hash(preview+'|'+badges.map(T).join('|')+'|'+unread)};
  }
  function conversations(){
    // Invalid matches in an earlier candidate family must not hide later valid rows.
    const rows=merged('conversationRows').map(e=>conversationRow(e)).filter(x=>x.key);
    const fallback=(rosterSurface()?.rows||[]).map(e=>conversationRow(e,true));
    for(const row of fallback)if(!rows.some(x=>x.el===row.el||x.el.contains(row.el)||row.el.contains(x.el)))rows.push(row);
    return rows.filter(x=>!rows.some(y=>y!==x&&y.key===x.key&&x.el.contains(y.el)));
  }
  function paneHeader(el){
    // The header must precede history and the editor. A bubble mentioning a name is not identity.
    const head=[...el.children].find(visible);if(!head||query('textarea,[contenteditable="true"]',head).length||T(head).length>260)return '';
    return T(head);
  }
  function headerMatches(el,row){
    const text=C.compact(paneHeader(el)).replace(/[|｜·]/g,'');
    if(!text)return false;
    const identity=C.compact(row.identityText).replace(/[|｜·]/g,'');
    return !!identity&&text.includes(identity)||!!row.name&&!!row.company&&text.includes(C.compact(row.name))&&text.includes(C.compact(row.company));
  }
  function editorPane(rows){
    const editors=merged('editor').filter(e=>['TEXTAREA','INPUT'].includes(e.tagName)||e.isContentEditable);
    if(editors.length!==1)return null;
    let found=null;
    for(let p=editors[0].parentElement;p&&p!==document.body;p=p.parentElement){
      if(rows.some(r=>p.contains(r.el))||contactSearch()&&p.contains(contactSearch()))break;
      // Send is normally disabled until typing. It still locates the composer.
      if(query('button,a,[role="button"],span,div',p).some(e=>T(e)==='发送')&&query('button,a,[role="button"],span,div',p).some(e=>T(e)==='发简历'))found=p;
    }
    return found;
  }
  function currentChat(){
    const rows=conversations();
    let roots=merged('chatRoot').filter(e=>one('editor',e)&&!rows.some(row=>e.contains(row.el)));
    roots=roots.filter(e=>!roots.some(x=>x!==e&&e.contains(x)&&(first('chatJobTitle',x)||query('a[href*="/job_detail/"]',x).length)));
    const known=roots.length===1?roots[0]:null,el=known||editorPane(rows);if(!el||!one('editor',el))return null;
    const selectedRows=rows.filter(r=>selectedWithin(r.el,rows.map(x=>x.el)));
    const matchingHeaders=rows.filter(r=>headerMatches(el,r));
    const row=selectedRows.length===1?selectedRows[0]:rows.find(r=>r.key===clickedConversation?.key&&headerMatches(el,r))||(matchingHeaders.length===1?matchingHeaders[0]:null);
    // Renamed or unmarked panes require a matching visible header after the row click.
    if((!known||row?.source==='contact-search-avatar')&&(!row||!headerMatches(el,row)))return null;
    const title=cleanTitle(firstText('chatJobTitle',el)),company=firstText('chatCompany',el)||row?.company||'';
    const link=query('a[href*="/job_detail/"]',el)[0];
    const jobId=link?.href.match(/\/job_detail\/([^/?#.]+)/)?.[1]||attr(el,['data-job-id']);
    const rowMismatch=!!(row?.title&&title&&!C.compatibleJobTitle(row.title,title))||!!(row?.company&&company&&!C.compact(company).includes(C.compact(row.company))&&!C.compact(row.company).includes(C.compact(company)));
    const fallbackTitle=title||positionTitle(el);
    return {el,key:row?.key||'',title:fallbackTitle,company,identityText:row?.identityText||'',jobKey:jobId?'job:'+jobId:'',rowSummary:row?.summary||'',rowName:row?.name||'',rowMismatch};
  }
  function positionTitle(el){
    const view=exactOne('查看职位',el);if(!view)return '';
    for(let p=view.parentElement;p&&p!==el;p=p.parentElement){
      if(T(p).length>240)break;
      if(/\d+(?:\.\d+)?\s*[-~—]\s*\d+(?:\.\d+)?\s*[kK万]/.test(T(p))){const value=cleanTitle(T(p));if(value&&value!==T(p))return value;}
      const nodes=query('a,span,div',p).filter(e=>!e.children.length&&T(e)&&e!==view&&T(e)!=='查看职位');
      const title=nodes.map(T).find(t=>!/^\d|^[·|｜]$/.test(t)&&!/^发送$/.test(t));if(title)return cleanTitle(title);
    }
    return '';
  }
  function checkChat(expected){
    const chat=currentChat();if(!chat||!chat.key)throw Error('无法确认当前聊天对象的稳定标识');
    if(chat.rowMismatch)throw Error('聊天内容与选中会话尚未一致，请等待加载');
    if(expected.chatKey && chat.key!==expected.chatKey)throw Error('当前聊天对象已改变，禁止发送');
    const sameId=expected.jobKey?.startsWith('job:')&&chat.jobKey&&expected.jobKey===chat.jobKey;
    if(expected.jobKey?.startsWith('job:') && chat.jobKey && expected.jobKey!==chat.jobKey)throw Error('当前聊天岗位 ID 不匹配');
    if(expected.title && !sameId && !C.compatibleJobTitle(chat.title,expected.title))throw Error('当前聊天岗位不匹配，禁止发送');
    if(expected.company && !C.compact(chat.company||chat.rowSummary).includes(C.compact(expected.company)) && !(chat.jobKey&&chat.jobKey===expected.jobKey))throw Error('当前聊天公司无法核对，禁止发送');
    return chat;
  }
  function sideOf(el){
    const direct=attr(el,['data-sbl-side','data-side']);if(['in','out','system'].includes(direct))return direct;
    if(el.querySelector('.card-competition,.competition-card,.message-system')||/^你与该职位竞争者PK情况/.test(T(el)))return 'system';
    const match=(k)=>{const sels=overrides[k]?[overrides[k]]:D[k];return sels.some(s=>{try{return el.matches(s)||!!el.closest(s);}catch{return false;}});};
    if(match('outgoing'))return 'out';if(match('incoming'))return 'in';
    const cls=typeof el.className==='string'?el.className:'';
    if(/system|notice|tip|time|card-competition/.test(cls))return 'system';
    if(/myself|is-self|from-me|message-sent/.test(cls))return 'out';
    if(/friend|is-other|from-other|message-received/.test(cls))return 'in';
    return 'unknown'; // Never infer incoming/outgoing from bubble color or screen coordinates.
  }
  function messageElements(scope){
    const candidates=[...new Set([...merged('messageRows',scope),...query('[class*="message-item"],[class*="messageItem"],[class*="message_item"],[class*="chat-message-item"]',scope)])];
    return candidates.filter(e=>!candidates.some(x=>x!==e&&e.contains(x)));
  }
  const MESSAGE_META='.read-status,.message-status,.send-status,.message-read,.read-receipt,.time,.message-time,[data-sbl-message-meta]';
  function bubbleText(el){
    // A message can contain several .text spans/paragraphs. Read all body fragments,
    // excluding separate read/sending/time controls. Never strip words from the body.
    let nodes=all('messageText',el);
    nodes=nodes.filter(e=>!e.matches(MESSAGE_META));
    if(!nodes.length)nodes=[el];
    nodes=nodes.filter(e=>!nodes.some(x=>x!==e&&x.contains(e)));
    return N(nodes.map(e=>{
      if(!e.cloneNode)return T(e); // Small dependency-free DOM test harness.
      const clone=e.cloneNode(true);
      clone.querySelectorAll(MESSAGE_META).forEach(x=>x.remove());
      clone.querySelectorAll('img[alt]').forEach(x=>x.replaceWith(x.getAttribute('alt')||''));
      return clone.textContent||'';
    }).join(' '));
  }
  function deliveryOf(el){
    const hint=attr(el,['data-sbl-delivery','data-message-status','data-send-status','data-status']);
    if(/^(?:failed|fail|error)$/.test(hint)||el.matches('.send-fail,.send-failed,.message-failed,.send-error')||query('.send-fail,.send-failed,.message-failed,.send-error,[title="发送失败"],[aria-label="发送失败"]',el).length)return 'failed';
    if(/^(?:sending|pending|loading)$/.test(hint)||el.matches('.send-loading,.message-sending')||query('.send-loading,.message-sending,.sending-icon',el).length)return 'sending';
    // Appearance in the outgoing history is confirmation of a page effect, NOT HR read status.
    return 'observed';
  }
  function messages(scope){
    const counts={};return messageElements(scope).map(el=>{
      const side=sideOf(el);let text=bubbleText(el);
      const request=/我想要.{0,12}(?:附件)?简历|请求.{0,12}(?:附件)?简历/.test(text)&&!!exactOne('同意',el);
      if(request)text=text.replace(/(?:拒绝\s*同意|同意\s*拒绝)\s*$/,'').trim();
      const stamp=attr(el,['data-time','data-timestamp'])||T(query('time,.time,.message-time',el)[0]);
      const base=side+'|'+C.messageKey(text)+'|'+stamp;counts[base]=(counts[base]||0)+1;
      const stableId=attr(el,['data-message-id','data-mid','data-id','id']);
      const id=stableId||'m:'+C.hash(base+'|'+counts[base]);
      return {id,stableId:!!stableId,side,text:text.slice(0,6000),resumeRequest:request,delivery:side==='out'?deliveryOf(el):'observed'};
    });
  }
  function resumePicker(){
    const seeds=[...query('.resume-list'),...exact('请选择要发送的简历',document,true)];
    const matches=[];
    for(const seed of seeds){
      for(let el=seed,n=0;el&&el!==document.body&&el!==document.documentElement&&n<9;el=el.parentElement,n++){
        if(query('[data-sbl-chat],.chat-conversation,.job-list-container,.user-list',el).length)break;
        if(!C.compact(T(el)).includes('请选择要发送的简历'))continue;
        if(exact('发送',el,true).length===1||exact('确认发送',el,true).length===1){matches.push(el);break;}
      }
    }
    const unique=[...new Set(matches)];return unique.length===1?unique[0]:null;
  }
  function modalContaining(phrase){
    if(phrase==='请选择要发送的简历'){const picker=resumePicker();if(picker)return picker;}
    const allmod=merged('modal').filter(e=>C.compact(T(e)).includes(C.compact(phrase)));
    if(phrase==='已向BOSS发送消息'){
      const controls=allmod.filter(e=>exactOne('继续沟通',e));
      if(controls.length)return controls.sort((a,b)=>T(a).length-T(b).length)[0];
    }
    if(allmod.length)return allmod.sort((a,b)=>T(a).length-T(b).length)[0];
    const h=exactOne(phrase);if(h){let p=h;for(let i=0;i<6&&p?.parentElement;i++){p=p.parentElement;if(exact('发送',p).length||exact('继续沟通',p).length)return p;}}
    return null;
  }
  function blocker(){
    const sel='[class*="captcha"],iframe[src*="captcha"],[class*="verify-wrap"],[class*="security-check"]';
    if(query(sel).length)return '出现验证页面，需用户处理';
    const contexts=[...all('modal'),...query('[role="alert"],.toast,.toast-content,.dialog-tip')];
    if(/\/web\/user\/|\/login|\/safe\/|\/security-check/.test(location.pathname))contexts.push(document.body);
    for(const e of contexts){const txt=T(e);if(/操作频繁|访问频繁|今日.{0,8}(?:上限|用完)|沟通.{0,8}(?:上限|用完)|账号异常|账号.{0,8}封|安全验证|完成验证|请先登录|登录已过期/.test(txt))return '平台验证、登录或额度限制：请到网站处理';}
    return '';
  }
  function shape(e){return {tag:e.tagName.toLowerCase(),classes:[...e.classList].filter(s=>/^[a-zA-Z_-][a-zA-Z0-9_-]{0,55}$/.test(s)&&!/\d{5}/.test(s)).slice(0,7)};}
  function ancestors(e){const a=[];for(let i=0;i<5&&e&&e!==document.body;i++,e=e.parentElement)a.push(shape(e));return a;}
  function safePath(value){try{const u=new URL(value,location.href);return u.protocol==='https:'?u.origin+u.pathname:u.protocol==='about:'?'about:blank':'other';}catch{return '';}}
  function inboxEntry(){
    const explicit=query('[data-sbl-inbox]');if(explicit.length===1)return explicit[0];
    const links=query('a[href]').filter(e=>/^(?:消息|沟通)(?:\s*\d+|\s*\(\d+\))?$/.test(T(e))&&C.safeUrl(e.href));
    const badgeLinks=query('.nav-chat-num').map(e=>e.closest('a')).filter(e=>e&&C.safeUrl(e.href));
    const candidates=[...new Set([...links,...badgeLinks])];if(candidates.length===1)return candidates[0];
    return exactOne('消息')||exactOne('沟通');
  }
  function route(){return /\/chat(?:[/?#]|$)/.test(location.pathname)||conversations().length||currentChat()?.key?'chat':/\/resume/.test(location.pathname)?'resume':/\/job/.test(location.pathname)?'jobs':'other';}
  function surfaceEvidence(){
    const allNodes=query('[class],input,textarea,[contenteditable],[role],iframe');
    const chatNodes=allNodes.filter(e=>/chat|message|conversation|session|editor|textbox|im-module/i.test(e.className||'')||['textbox','listbox'].includes(e.getAttribute('role'))||e.getAttribute('contenteditable')==='true');
    const fields=e=>({...shape(e),id:/^[a-zA-Z][\w-]{0,60}$/.test(e.id||'')&&!/\d{5}/.test(e.id)?e.id:'',attributes:[...(e.attributes||[])].map(a=>a.name).filter(n=>/^(?:data-|aria-|contenteditable|role)/.test(n)),role:e.getAttribute('role')||'',editable:e.getAttribute('contenteditable')||'',ancestors:ancestors(e)});
    return {path:safePath(location.href),readyState:document.readyState||'',inboxEntry:inboxEntry()?ancestors(inboxEntry()):[],
      frames:query('iframe').slice(0,12).map(e=>{let accessible=false;try{accessible=!!e.contentDocument?.body;}catch{}return {...shape(e),src:safePath(e.getAttribute('src')||''),accessible};}),
      openShadowRoots:scopes().filter(x=>x.host).length,chatCandidates:chatNodes.slice(0,180).map(fields),
      editorCandidates:query('textarea,input,[contenteditable="true"],[role="textbox"]').slice(0,16).map(fields),
      rawConversationCandidates:merged('conversationRows').slice(0,16).map(e=>({...fields(e),hasStableKey:!!conversationRow(e).key})),
      framesNote:'仅采集可访问的可见结构；跨域框架只记录地址路径，不读取正文'};
  }
  function inspect(){
    const counts=Object.fromEntries(Object.keys(D).map(k=>[k,all(k).length]));
    const hints={};for(const k of ['jobCards','jobDetail','conversationRows','conversationList','activeConversation','chatRoot','editor','messageRows','directions','attachments'])hints[k]=all(k).slice(0,3).map(e=>({tag:e.tagName.toLowerCase(),classes:[...e.classList].filter(s=>/^[a-zA-Z_-][a-zA-Z0-9_-]{0,55}$/.test(s)).slice(0,7)}));
    const knownControls={};for(const label of ['消息','沟通','立即沟通','继续沟通','发简历','发送','请选择要发送的简历','期望职位','全职职位','附件管理'])knownControls[label]=exact(label).slice(0,2).map(ancestors);
    const structures=query('[class]').slice(0,450).map(shape).filter((x,i,a)=>a.findIndex(y=>y.tag===x.tag&&y.classes.join(' ')===x.classes.join(' '))===i).slice(0,150);
    return {knownControls,structures,surface:surfaceEvidence(),path:safePath(location.href),fileCandidateShapes:leafFiles().slice(0,3).map(ancestors),route:route(),
      blocker:blocker(),loggedIn:!blocker()&&(/\/web\/geek\//.test(location.pathname)||!!exactOne('简历')),
      counts,hints,parsedJobsCount:jobs().length,jobCandidatesCount:jobCandidates().length,jobFieldChecks:jobCandidates().slice(0,8).map(e=>({shape:shape(e),hasTitle:!!fieldText('jobTitle',e),hasCompany:!!fieldText('jobCompany',e)})),canReadJobs:jobs().length>0,canIdentifyChat:!!currentChat()?.key,
      resolved:{leftRows:conversations().length,searchAnchor:!!contactSearch(),rightPane:!!currentChat(),editor:!!(currentChat()&&one('editor',currentChat().el)),messages:currentChat()?messages(currentChat().el).length:0},
      resumePicker:pickerInspection(),titleComparison:lastTitleCheck,uiTrace:[...uiTrace],chatRows:conversations().slice(0,12).map(x=>({key:x.key,name:x.name,company:x.company,title:x.title,source:x.source,unread:x.unread,system:x.system,shape:shape(x.el)})),activeChat:currentChat()?{key:currentChat().key,title:currentChat().title,company:currentChat().company}:null,messageSides:messages(currentChat()?.el||document).reduce((a,m)=>(a[m.side]=(a[m.side]||0)+1,a),{}),version:C.VERSION};
  }
  function pickerInspection(){
    const mod=modalContaining('请选择要发送的简历');if(!mod)return {open:false};
    const rows=attachments(mod,'resumeRows');return {open:true,shape:shape(mod),ancestors:ancestors(mod),rows:rows.map(x=>({shape:shape(x.el),selected:resumeSelected(x.el,mod),hasFilename:!!x.name})),sendControls:exact('发送',mod,true).map(e=>({shape:shape(e),enabled:enabled(e)})),closeControls:resumeCloseButtons(mod).map(shape)};
  }
  function snapshot(){
    const c=currentChat();return {url:location.href,route:route(),blocker:blocker(),readiness:{list:conversations().length>0,opened:!!c?.key,editor:!!(c&&one('editor',c.el)),clickedKey:clickedConversation?.key||''},jobs:jobs().map(({el,...x})=>x),chat:c?{key:c.key,title:c.title,company:c.company,identityText:c.identityText,jobKey:c.jobKey,name:c.rowName}:null,
      messages:c?messages(c.el):[],conversations:conversations().map(({el,summary,...x})=>x),resumePickerOpen:!!modalContaining('请选择要发送的简历'),resumeConsentAvailable:!!(c&&resumeConsentButton(c.el)),resumeReceipt:c?/您的附件简历[\s\S]{0,130}(?:已发送给|已发送至)/.test(T(c.el)):false,resumeWaiting:c?/简历.{0,16}(?:请求已发送|等待.{0,6}同意)|请求发送.{0,12}简历/.test(T(c.el)):false,activity:activity(),
      chatLoading:!!(c&&(c.rowMismatch||query('.chat-loading,.message-loading,[data-sbl-loading]',c.el).length)),historyMore:!!(c&&historyButton(c.el)),emptyInbox:!!query('[data-sbl-empty-inbox],.user-list .empty-state,.chat-list .empty-state').length};
  }
  function resumeConsentButton(root){
    const isRequest=e=>/我想要.{0,18}(?:附件)?简历|(?:请求|索要|希望获取).{0,18}(?:附件)?简历/.test(N(T(e)))&&!/交换.{0,6}(?:微信|电话)|(?:手机号|验证码|付款)/.test(N(T(e)));
    const cards=messageElements(root).filter(e=>sideOf(e)==='in'&&isRequest(e));
    for(const card of cards.reverse()){const b=exactOne('同意',card);if(b)return b;}
    // No global "同意": only the resume-specific sticky strip in the current conversation.
    for(const strip of query('.message-tip-bar,[data-sbl-resume-request-bar]',root))if(isRequest(strip)){
      const b=exactOne('同意',strip);if(b)return b;
    }
    return null;
  }
  function activity(){
    const c=currentChat(),ms=c?messages(c.el).filter(m=>m.side==='in'||m.side==='system').slice(-40):[];
    return {blocker:blocker(),rows:conversations().map(x=>({key:x.key,token:x.token,unread:x.unread,system:x.system,lastSide:x.lastSide||'',needsReply:!!x.needsReply,name:x.name||'',title:x.title||'',company:x.company||''})),
      active:c?{key:c.key,hasInbound:ms.length>0,token:C.hash(ms.map(m=>m.id+'|'+m.text).join('\n'))}:null};
  }
  function chatTarget(p){
    if(currentChat()?.key&&/\/chat/.test(location.pathname))return {already:true};
    const d=checkDetail(p),button=exactOne('继续沟通',modalContaining('已向BOSS发送消息')||d.el);
    const link=button?.closest('a[href]');
    const url=C.safeUrl(link?.href);
    // Only use an actual public UI destination. Never synthesize a private chat/session URL.
    return {url:url&&/\/web\/geek\/chat(?:[/?#]|$)/.test(url)&&(new URL(url).search||new URL(url).hash)?url:''};
  }
  function outgoingChat(p){
    const c=checkChat(p), ms=messages(c.el);
    if(ms.some(m=>m.side==='unknown'))throw Error('消息发出方未能识别，禁止自动发送');
    if(ms.some(m=>m.side==='in'&&C.HARD_STOP.test(m.text)))throw Error('对方明确要求停止联系，禁止发送');
    if(ms.some(m=>m.side==='in'&&(p.robot?C.rejectionIntent(m.text).kind==='soft':C.STOP.test(m.text)))&&!(p.robot&&p.allowSoftRejection))throw Error('对方已拒绝或要求停止联系，禁止继续发送');
    return c;
  }
  let calibrationCancel=null;
  function calibrate(){
    if(calibrationCancel)calibrationCancel();
    return new Promise((resolve,reject)=>{
      const banner=document.createElement('div');banner.setAttribute('data-sbl-calibration','');
      Object.assign(banner.style,{position:'fixed',top:'12px',left:'50%',transform:'translateX(-50%)',zIndex:'2147483647',background:'#172421',color:'white',padding:'16px 22px',borderRadius:'10px',font:'15px/1.5 sans-serif',boxShadow:'0 4px 20px #0005',pointerEvents:'none'});
      banner.textContent='校准 1/2：点左侧一张岗位卡片的【岗位名称】（不会打开或发送）。Esc 取消。';document.documentElement.append(banner);
      let titleNode=null,timer;
      const finish=(error,result)=>{clearTimeout(timer);document.removeEventListener('click',click,true);document.removeEventListener('pointerdown',suppress,true);document.removeEventListener('keydown',key,true);banner.remove();calibrationCancel=null;error?reject(Error(error)):resolve(result);};
      calibrationCancel=()=>finish('已取消校准');
      const key=e=>{if(e.key==='Escape'){e.preventDefault();finish('已取消校准');}};
      const suppress=e=>{e.preventDefault();e.stopImmediatePropagation();};
      const stable=e=>{
        const classes=[...e.classList].filter(c=>/^[a-zA-Z_][a-zA-Z0-9_-]{0,60}$/.test(c)&&!/(?:^|-)(?:active|selected|current|hover|focus)(?:$|-)/.test(c)&&!/[0-9]{6}/.test(c));
        return e.tagName.toLowerCase()+classes.slice(0,3).map(c=>'.'+CSS.escape(c)).join('');
      };
      const relative=(e,root)=>{const path=[];while(e&&e!==root){let part=stable(e);const siblings=[...e.parentElement.children].filter(x=>x.tagName===e.tagName);if(siblings.length>1)part+=':nth-of-type('+(siblings.indexOf(e)+1)+')';path.unshift(part);e=e.parentElement;}return path.join(' > ');};
      const click=e=>{
        e.preventDefault();e.stopImmediatePropagation();let node=e.target;
        if(!(node instanceof Element)||node===banner||!T(node)||T(node).length>180){banner.textContent='请点具体文字，不要点空白、整页或按钮。Esc 取消。';return;}
        if(!titleNode){titleNode=node;banner.textContent='校准 2/2：点【同一张卡片】底部的公司名称（不是右侧详情）。Esc 取消。';return;}
        const companyNode=node;let card=titleNode.parentElement;while(card&&!card.contains(companyNode))card=card.parentElement;
        if(!card||[document.body,document.documentElement].includes(card)||card===titleNode||card===companyNode||T(card).length>800){finish('两处文字不在同一张小卡片内，请重新校准');return;}
        let cardSel=stable(card);
        if(!cardSel.includes('.')){const parent=card.parentElement;if(!parent||!stable(parent).includes('.')){finish('卡片没有可复用的结构；请导出诊断');return;}cardSel=stable(parent)+' > '+cardSel;}
        const selectors={jobCards:cardSel,jobTitle:relative(titleNode,card),jobCompany:relative(companyNode,card)};
        if(!selectors.jobTitle||!selectors.jobCompany){finish('字段无法单独定位，请导出诊断');return;}
        const old=overrides;overrides={...overrides,...selectors};const parsed=jobs();overrides=old;
        if(!parsed.length||parsed.length>300||!parsed.some(j=>j.el===card)){finish('校准结果不能可靠识别这张卡片，请导出诊断');return;}
        finish(null,{selectors,count:parsed.length});
      };
      document.addEventListener('pointerdown',suppress,true);document.addEventListener('click',click,true);document.addEventListener('keydown',key,true);
      timer=setTimeout(()=>finish('校准超时，可重新点击校准按钮'),90000);
    });
  }
  async function waitFor(fn,ms=4500){const end=Date.now()+ms;while(Date.now()<end){const x=fn();if(x)return x;await new Promise(r=>setTimeout(r,180));}return null;}
  async function clickSafe(el,guard,checkpoint){
    const check=()=>{if(!enabled(el)){const error=Error('目标按钮尚未启用，尚未点击');error.beforeClick=true;throw error;}};
    check();await guard();check();if(checkpoint){await checkpoint();await guard();}check();el.click();
  }
  function resumeCloseButtons(mod){
    const found=query('.dialog-close,.el-dialog__headerbtn,.boss-layer__close,.boss-dialog__close,.icon-close,.ui-icon-close,[aria-label="关闭"],[title="关闭"],[data-sbl-close]',mod);
    const candidates=[...found,...exact('取消',mod),...exact('×',mod),...exact('✕',mod)];
    const mapped=candidates.map(e=>e.closest('button,[role="button"],.dialog-close,.boss-layer__close')||e).filter(e=>mod.contains(e)&&enabled(e));
    return [...new Set(mapped)].filter(e=>!mapped.some(x=>x!==e&&e.contains(x)));
  }
  async function closeResumePicker(){
    const mod=modalContaining('请选择要发送的简历')||resumeConfirmation({})?.mod;if(!mod)return;
    const cancel=exactOne('取消',mod),close=resumeCloseButtons(mod),button=cancel||(close.length===1?close[0]:null);
    if(!button)throw Error('附件弹窗未关闭，请手动关闭后继续');
    button.click();ui('resume_picker_closed',button);
    if(!await waitFor(()=>!visible(mod),2500))throw Error('附件弹窗未关闭，请手动关闭后继续');
  }
  function resumeSelected(el,mod){
    if(!el||!visible(el))return false;
    const viaClass=/(?:^|[\s_-])(?:active|selected|checked|current|chosen)(?:$|[\s_-])/.test(el.className||'');
    return viaClass||el.getAttribute('aria-selected')==='true'||el.getAttribute('aria-checked')==='true'||
      !!el.querySelector('input:checked,[aria-checked="true"],[aria-selected="true"]')||
      all('selectedResume',mod).some(x=>x===el||x.contains(el)||el.contains(x));
  }
  function historyButton(scope){return exactOne('查看更多历史消息',scope)||exactOne('加载更多消息',scope)||exactOne('查看更多消息',scope);}
  function listScroller(){
    let e=conversations()[0]?.el.parentElement||one('conversationList');
    while(e&&e!==document.body){if(e.scrollHeight>e.clientHeight+10&&/auto|scroll/.test(getComputedStyle(e).overflowY))return e;e=e.parentElement;}
    return one('conversationList');
  }
  async function navigate(type,p={}){
    const b=blocker();if(b)throw Error(b);
    if(type==='inbox'){
      if(route()==='chat')return {ok:true,already:true};
      const entry=inboxEntry();if(!entry)throw Error('网页上没有识别到消息／沟通入口，尚未打开消息页');
      entry.click();ui('inbox_clicked',entry);return {ok:true,navigating:true};
    }
    if(type==='direction'){
      const e=directionTab(p.label);if(!e)throw Error('找不到唯一方向标签：'+p.label+'。请确认已在职位页，并检查标签名称');
      const changed=!selectedWithin(e,merged('directionTabs'));if(changed)e.click();return {ok:true,changed};
    }
    if(type==='job'){
      const cards=jobs(),es=cards.filter(j=>j.key===p.key);if(es.length!==1)throw Error('岗位卡片不可唯一识别');
      let ready=false;try{ready=!!checkDetail(es[0]);}catch{}
      if(p.force||!ready){
        // Click the card surface. a.job-name can be a separate external detail link.
        // The inner card bubbles to wrapper listeners too; clicking the wrapper alone misses child listeners.
        const card=es[0].el,inner=card.closest('.job-card-box');
        const target=inner&&cards.filter(j=>inner.contains(j.el)).length===1?inner:card;
        clickedJob={key:p.key,at:Date.now()};target.click();ui('job_clicked',target,{jobKey:p.key});
      }return {ok:true};
    }
    if(type==='continue'){
      if(currentChat()?.key&&/\/chat/.test(location.pathname))return {ok:true,already:true};
      const button=await waitFor(()=>{
        const mod=modalContaining('已向BOSS发送消息');
        return exactOne('继续沟通',mod||detail()?.el||document);
      },10000);
      if(!button)throw Error('未找到「继续沟通」入口');
      // The worker persisted await_chat before this request, so a navigation-unload reply is optional.
      if(blocker())throw Error(blocker());button.click();ui('continue_clicked',button);
      return {ok:true,navigating:true};
    }
    if(type==='return_list'){
      const mod=modalContaining('已向BOSS发送消息');
      if(mod){
        const stay=exactOne('留在此页',mod)||exactOne('取消',mod),closes=query('.dialog-close,.el-dialog__headerbtn,[aria-label="关闭"]',mod);
        const button=stay||(closes.length===1?closes[0]:null);
        if(!button)throw Error('沟通弹窗未关闭，请关闭后继续');button.click();
        if(!await waitFor(()=>!modalContaining('已向BOSS发送消息'),1200))throw Error('沟通弹窗未关闭，请关闭后继续');
      }
      return {ok:true};
    }
    if(type==='conversation'){
      // Clicking a list row is valid before any right-hand chat or editor exists.
      const rows=conversations().filter(c=>c.key===p.chatKey&&!c.system);if(rows.length!==1)throw Error('左侧联系人未加载或重名，尚未点击');
      rows[0].el.scrollIntoView?.({block:'nearest'});rows[0].el.click();clickedConversation={key:p.chatKey,at:Date.now()};ui('conversation_clicked',rows[0].el,{chatKey:p.chatKey});return {ok:true,clicked:true};
    }
    if(type==='reply_cleanup'){await closeResumePicker();return {ok:true};}
    if(type==='conversations_top'||type==='conversations_more'){
      const el=listScroller();if(!el)return {ok:false,end:true};const before=el.scrollTop||0;
      el.scrollTop=type==='conversations_top'?0:before+Math.max(300,(el.clientHeight||500)*0.8);
      el.dispatchEvent(new Event('scroll',{bubbles:true}));return {ok:true,end:el.scrollTop===before,before,after:el.scrollTop};
    }
    if(type==='history_more'){
      const c=currentChat(),button=c&&historyButton(c.el);if(button)button.click();return {ok:!!button,end:!button};
    }
    if(type==='more'){
      const card=jobs().at(-1)?.el;if(!card)return {ok:false,end:true};
      let scroll=card.parentElement;while(scroll&&scroll!==document.body){const css=getComputedStyle(scroll);if(scroll.scrollHeight>scroll.clientHeight+30&&/auto|scroll/.test(css.overflowY))break;scroll=scroll.parentElement;}
      const target=scroll&&scroll!==document.body?scroll:document.scrollingElement;
      const before=target.scrollTop;target.scrollTop+=Math.max(400,target.clientHeight*.8);
      if(target.scrollTop===before){const next=exactOne('下一页');if(next){next.click();return {ok:true};}return {ok:false,end:true};}return {ok:true};
    }
    throw Error('不支持的导航动作');
  }
  async function observe(type,p,evidence={}){
    const b=blocker();if(b)throw Error(b);
    if(type==='initiate'){
      if(!evidence.title)return {verified:false,reason:'旧动作未保存点击前的职位记录'};
      try{const c=checkChat({...p,title:evidence.title});if(c)return {verified:true,title:evidence.title};}catch{}
      try{const d=checkDetail({...p,title:evidence.title});return {verified:!!(modalContaining('已向BOSS发送消息')||exactOne('继续沟通',d.el)),title:d.title};}catch{return {verified:false};}
    }
    const c=checkChat(p);
    if(['intro','reply','followup','rejection'].includes(type)){
      if(!Number.isInteger(evidence.beforeCount)&&!Array.isArray(evidence.beforeIds))return {verified:false,reason:'旧动作缺少发送前的消息证据，未重发'};
      return C.textReceipt(messages(c.el),p.text,evidence);
    }
    if(['resume','resumeConsent','resumeOffer'].includes(type)){
      const text=T(c.el);if(/您的附件简历[\s\S]{0,130}(?:已发送给|已发送至)/.test(text))return {verified:true,resumeStatus:'sent'};
      const picker=modalContaining('请选择要发送的简历');if((type!=='resume'||evidence.resumeStage==='opening-picker')&&picker){const rows=attachments(picker,'resumeRows');return {verified:true,resumeStatus:'selecting',candidate:(p.resumeSelection==='first'?rows.length>0:rows.length===1)?(({el,...x})=>x)(rows[0]):null};}
      if(/简历.{0,16}(?:请求已发送|等待.{0,6}同意)|请求发送.{0,12}简历/.test(text))return {verified:true,resumeStatus:'waiting'};
    }
    return {verified:false};
  }
  function putText(e,text){
    const doc=e.ownerDocument||document,win=doc.defaultView;writingInput=e;
    try{
      if(['TEXTAREA','INPUT'].includes(e.tagName)){const proto=e.tagName==='TEXTAREA'?(win?.HTMLTextAreaElement||HTMLTextAreaElement).prototype:(win?.HTMLInputElement||HTMLInputElement).prototype;Object.getOwnPropertyDescriptor(proto,'value').set.call(e,text);}
      else if(e.isContentEditable){
        // Use the browser's editing path where available, with plain-text fallback.
        // execCommand events can be synchronous: only this exact edit is excluded from HUMAN_INPUT.
        let inserted=false;
        if(doc.execCommand&&doc.createRange){try{const selection=win?.getSelection?.()||doc.getSelection?.(),range=doc.createRange();if(selection){range.selectNodeContents(e);selection.removeAllRanges();selection.addRange(range);inserted=doc.execCommand('insertText',false,text)&&N(e.innerText)===N(text);}}catch{}}
        if(!inserted)e.textContent=text;
      }else throw Error('输入框类型未适配');
      e.dispatchEvent(new (win?.InputEvent||InputEvent)('input',{bubbles:true,composed:true,inputType:'insertText',data:text}));
      e.dispatchEvent(new (win?.Event||Event)('change',{bubbles:true,composed:true}));
      // Some editor implementations update sendability on keyup rather than input.
      // Never use Enter here: only the enabled send button is allowed to submit.
      const Keyboard=win?.KeyboardEvent||root.KeyboardEvent;
      if(e.isContentEditable&&Keyboard)e.dispatchEvent(new Keyboard('keyup',{bubbles:true,composed:true,key:'Unidentified',code:'',keyCode:0,which:0}));
    }finally{writingInput=null;}
  }
  function resumeConfirmation(p){
    const choices=merged('modal').filter(m=>/简历/.test(T(m))&&!/请选择要发送的简历/.test(T(m))).map(mod=>({mod,button:exactOne('确认投递',mod)||exactOne('确认发送',mod)||exactOne('确认',mod)||exactOne('确定',mod)})).filter(x=>x.button);
    const distinct=choices.filter((x,i,a)=>a.findIndex(y=>y.button===x.button)===i);if(distinct.length!==1)return null;
    const choice=distinct[0],names=leafFiles(choice.mod).map(T);
    if(p.resume&&names.some(name=>C.compact(name)!==C.compact(p.resume.name)))throw Error('简历确认框显示了其他文件，未确认投递');
    return choice;
  }
  async function settleResume(p,guard,checkpoint,allowPicker){
    const confirmed=new Set();
    for(let n=0;n<3;n++){
      const result=await waitFor(()=>{
        const cur=checkChat(p),text=T(cur.el);
        if(/您的附件简历[\s\S]{0,130}(?:已发送给|已发送至)/.test(text))return {verified:true,resumeStatus:'sent'};
        if(/简历.{0,16}(?:请求已发送|等待.{0,6}同意)|请求发送.{0,12}简历/.test(text))return {verified:true,resumeStatus:'waiting'};
        const picker=allowPicker&&modalContaining('请选择要发送的简历');
        if(picker){const rows=attachments(picker,'resumeRows');return {verified:true,resumeStatus:'selecting',candidate:(p.resumeSelection==='first'?rows.length>0:rows.length===1)?(({el,...x})=>x)(rows[0]):null};}
        const confirm=resumeConfirmation(p);return confirm?{confirm}:null;
      });
      if(!result)return {verified:false,reason:'已点击附件步骤，但尚未出现投递或申请回执'};
      if(!result.confirm){ui('resume_result',null,{chatKey:p.chatKey,status:result.resumeStatus});return result;}
      const {mod,button}=result.confirm,signature=C.hash(T(mod));
      if(confirmed.has(signature))return {verified:false,reason:'确认投递已点击，弹窗尚未结束，不重复提交'};
      await clickSafe(button,guard,()=>checkpoint({resumeStage:'confirm',resumeConfirmKey:signature}));confirmed.add(signature);ui('resume_confirm_clicked',button,{chatKey:p.chatKey});
    }
    return {verified:false,reason:'附件确认步骤未结束，未切换联系人'};
  }
  async function action(type,p,guard,checkpoint=async()=>{}){
    const b=blocker();if(b)throw Error(b);
    if(type==='initiate'){
      let detailError,lastSignature='',stableSince=0;
      const d=await waitFor(()=>{
        try{
          const found=checkDetail(p),signature=C.hash(found.title+'|'+found.company+'|'+T(found.el));
          if(signature!==lastSignature){lastSignature=signature;stableSince=Date.now();return null;}
          if(Date.now()-stableSince<700||clickedJob?.key===p.key&&Date.now()-clickedJob.at<1000)return null;
          if(query('[aria-busy="true"],.loading,.job-detail-loading',found.el).length)return null;
          return found;
        }catch(e){detailError=e;lastSignature='';return null;}
      },9000);
      if(!d)throw detailError||Error('岗位详情尚未加载');
      if(modalContaining('已向BOSS发送消息'))return {verified:true,already:true,title:d.title};
      const old=exactOne('继续沟通',d.el);if(old)return {verified:false,existing:true};
      const button=exactOne('立即沟通',d.el);if(!button)throw Error('未找到唯一「立即沟通」按钮');
      await clickSafe(button,async()=>{await guard();checkDetail(p);},()=>checkpoint({title:d.title}));
      ui('initiate_clicked',button,{jobKey:p.key});
      const ok=await waitFor(()=>{
        try{if(checkChat({...p,title:d.title}))return true;}catch{}
        return modalContaining('已向BOSS发送消息')||exactOne('继续沟通',detail()?.el||document);
      },6500);
      return {verified:!!ok,title:d.title,reason:ok?'平台确认已发起沟通':'未检测到明确发送成功反馈'};
    }
    if(type==='continue'){
      const mod=modalContaining('已向BOSS发送消息');const button=exactOne('继续沟通',mod||detail()?.el||document);
      if(!button)throw Error('未找到唯一「继续沟通」入口');await clickSafe(button,guard);return {verified:true};
    }
    if(type==='intro'||type==='reply'||type==='followup'||type==='rejection'){
      const c=outgoingChat(p);const e=one('editor',c.el);if(!e)throw Error('未找到唯一聊天输入框');
      if(!p.text||p.text.length>3000)throw Error('消息为空或过长');
      const existing=N('value' in e?e.value:e.innerText);if(existing&&existing!==N(p.text))throw Error('输入框已有不同草稿，已停止，避免覆盖手工内容');
      const prior=messages(c.el).filter(m=>m.side==='out'&&C.messageKey(m.text)===C.messageKey(p.text));
      const before=prior.length,beforeIds=prior.filter(m=>m.stableId).map(m=>m.id);
      if(prior.some(C.outgoingConfirmed))return {verified:true,already:true,reason:'历史中已有相同话术，不重复发送'};
      if(before)throw Error('已有对应的发送中或失败消息，未再次点击发送');
      const inboundBefore=messages(c.el).filter(m=>m.side==='in').map(m=>m.id+'|'+m.text).join('\n');
      if(p.outboundToken&&C.outboundToken(messages(c.el))!==p.outboundToken)throw Error('新消息已变化：我方已有其他回复，重新合并');
      if(p.inboundToken&&C.hash(inboundBefore)!==p.inboundToken)throw Error('新消息已变化，重新合并后再回复');
      let dispatched=false;
      try{
        await guard();outgoingChat(p);e.click();e.focus();ui('editor_clicked',e,{chatKey:p.chatKey});
        putText(e,p.text);ui(existing?'draft_reused':'text_entered',e,{chatKey:p.chatKey,chars:p.text.length,textHash:C.hash(p.text)});
        const button=await waitFor(()=>{outgoingChat(p);const bs=all('sendButton',c.el).filter(x=>C.compact(T(x))==='发送'&&enabled(x));return bs.length===1?bs[0]:exactOne('发送',c.el);},6000);
        ui(button?'send_ready':'send_wait_timeout',button,{chatKey:p.chatKey});
        await clickSafe(button,async()=>{
          await guard();const cur=outgoingChat(p);
          if(type!=='intro'&&messages(cur.el).filter(m=>m.side==='in').map(m=>m.id+'|'+m.text).join('\n')!==inboundBefore)throw Error('新消息已变化，重新合并后再回复');
          if(p.outboundToken&&C.outboundToken(messages(cur.el))!==p.outboundToken)throw Error('新消息已变化：我方已有其他回复，重新合并');
          if(C.compact('value' in e?e.value:e.innerText)!==C.compact(p.text))throw Error('输入框内容已变化，禁止发送');
        },async()=>{await checkpoint({beforeCount:before,beforeIds,textHash:C.hash(C.messageKey(p.text))});dispatched=true;});
        ui('send_clicked',button,{chatKey:p.chatKey});
        const receipt=await waitFor(()=>{const cur=checkChat(p),r=C.textReceipt(messages(cur.el),p.text,{beforeCount:before,beforeIds});return r.verified||r.definitiveFailure?r:null;},6500);
        if(receipt?.verified)ui('outgoing_seen',null,{chatKey:p.chatKey,textHash:C.hash(p.text)});
        return {...receipt,verified:!!receipt?.verified,uiActions:['editor_clicked','text_entered','send_clicked',...(receipt?.verified?['outgoing_seen']:[])],reason:receipt?.reason||'暂未读到对应消息，自动读取回执'};
      }catch(error){
        // Remove only this operation's untouched draft when no send was submitted.
        if((!dispatched||error.beforeClick)&&!existing&&e.isConnected&&N('value' in e?e.value:e.innerText)===N(p.text))putText(e,'');
        throw error;
      }
    }
    if(type==='resumeConsent'||type==='resumeOffer'){
      if(!p.robot||!p.allowDefaultResume)throw Error('未启用网站默认附件入口');
      const c=outgoingChat(p);
      if(/您的附件简历[\s\S]{0,130}(?:已发送给|已发送至)/.test(T(c.el)))return {verified:true,already:true,resumeStatus:'sent'};
      if(type==='resumeOffer'&&/简历.{0,16}(?:请求已发送|等待.{0,6}同意)|请求发送.{0,12}简历/.test(T(c.el)))return {verified:true,already:true,resumeStatus:'waiting'};
      let button;
      if(type==='resumeConsent'){
        button=resumeConsentButton(c.el);
      }else button=exactOne('发简历',c.el);
      if(!button)throw Error(type==='resumeConsent'?'未找到当前简历请求卡片中的同意按钮':'未找到主动发简历入口');
      const guardCurrent=async()=>{await guard();const cur=outgoingChat(p);if(p.inboundToken&&C.hash(messages(cur.el).filter(m=>m.side==='in').map(m=>m.id+'|'+m.text).join('\n'))!==p.inboundToken)throw Error('新消息已变化，重新合并后再回复');};
      await clickSafe(button,guardCurrent,()=>checkpoint({}));
      ui(type==='resumeConsent'?'resume_agree_clicked':'resume_toolbar_clicked',button,{chatKey:p.chatKey});
      return await settleResume(p,guardCurrent,checkpoint,true);
    }
    if(type==='resume'){
      const c=outgoingChat(p),firstFile=p.resumeSelection==='first';
      let submitted=false,chosen=null,entryClicked=false,sawPicker=!!modalContaining('请选择要发送的简历');
      const originalMessages=messages(c.el),requestIds=new Set(originalMessages.filter(m=>m.side==='in'&&m.resumeRequest).map(m=>m.id));
      const nonRequestToken=ms=>C.hash(ms.filter(m=>m.side==='in'&&!requestIds.has(m.id)).map(m=>m.id+'|'+m.text).join('\n'));
      const originalNonRequest=nonRequestToken(originalMessages);
      const resumeGuard=async()=>{
        await guard();const cur=outgoingChat(p);
        if(p.inboundToken&&(entryClicked ? nonRequestToken(messages(cur.el))!==originalNonRequest : C.hash(messages(cur.el).filter(m=>m.side==='in').map(m=>m.id+'|'+m.text).join('\n'))!==p.inboundToken))throw Error('新消息已变化，重新合并后再回复');
        if(p.outboundToken&&C.outboundToken(messages(cur.el))!==p.outboundToken)throw Error('新消息已变化：我方已有其他回复，重新合并');
        if(messages(cur.el).some(m=>m.side==='in'&&C.NO_RESUME.test(m.text)))throw Error('对方表示不需要简历，未发送附件');
      };
      try{
        if(!firstFile&&!p.resume)throw Error('缺少已绑定附件');
        await resumeGuard();
        if(/您的附件简历[\s\S]{0,130}(?:已发送给|已发送至)/.test(T(c.el)))return {verified:true,already:true,resumeStatus:'sent'};
        let mod=modalContaining('请选择要发送的简历');
        if(!mod){
          if(!firstFile&&p.robot&&!p.allowDefaultResume)throw Error('仅允许绑定附件，但网站未显示文件选择框；未点击可能直接发送默认附件的入口');
          // On an explicit resume request, click its own Agree first; never phone/WeChat Agree.
          const agree=firstFile&&p.requested?resumeConsentButton(c.el):null;
          const toolbar=agree||await waitFor(()=>exactOne('发简历',outgoingChat(p).el),5000);
          if(!toolbar)throw Error('未找到「发简历」入口；没有点击其他同意或交换联系方式按钮');
          // Toolbar can have an external effect on some layouts; journal it before clicking.
          await clickSafe(toolbar,resumeGuard,()=>checkpoint({resumeStage:'opening-picker',resumeSelection:firstFile?'first':'bound'}));
          entryClicked=true;
          ui(agree?'resume_agree_clicked':'resume_toolbar_clicked',toolbar,{chatKey:p.chatKey});
          const entryResult=await waitFor(()=>modalContaining('请选择要发送的简历')||/您的附件简历[\s\S]{0,130}(?:已发送给|已发送至)|简历.{0,16}(?:请求已发送|等待.{0,6}同意)/.test(T(checkChat(p).el)),6000);
          mod=modalContaining('请选择要发送的简历');
          if(!mod&&entryResult){const receipt=await observe('resume',p,{});if(receipt.verified)return {...receipt,resumeSelection:'website-default'};}
        }
        if(!mod)return {verified:false,reason:'附件选择框未出现；入口已点击，等待只读核验，不重复申请'};
        sawPicker=true;
        // File names/order must settle before choosing index 0. Display order, NOT imported array order.
        let signature='',since=0;
        const rows=await waitFor(()=>{
          const current=attachments(mod,'resumeRows'),key=C.hash(current.map(x=>x.key).join('|'));
          if(!current.length)return null;
          if(key!==signature){signature=key;since=Date.now();return null;}
          return Date.now()-since>=400?current:null;
        },4500);
        if(!rows)throw Error('选择框没有可识别的简历文件，未点击发送');
        const match=firstFile?[rows[0]]:rows.filter(r=>C.sameResume(p.resume,r));
        if(match.length!==1)throw Error('指定附件缺失、更新或同名冲突，请重新导入绑定');
        chosen=match[0];
        if(!resumeSelected(chosen.el,mod))await clickSafe(chosen.el,resumeGuard);
        ui('resume_file_clicked',chosen.el,{chatKey:p.chatKey,file:chosen.name,selection:firstFile?'first':'bound',index:firstFile?0:rows.indexOf(chosen)});
        if(!await waitFor(()=>resumeSelected(chosen.el,mod),3500))throw Error('无法确认目标附件已选中，禁止点击发送');
        const send=await waitFor(()=>exactOne('发送',mod)||exactOne('确认发送',mod)||exactOne('确认投递',mod),4000);
        await clickSafe(send,async()=>{
          await resumeGuard();
          if(!resumeSelected(chosen.el,mod)||!C.sameResume(chosen,readFile(chosen.el,'resumeName')))throw Error('附件选择或信息发生变化，未发送');
          const current=attachments(mod,'resumeRows');
          if(firstFile&&(!current.length||!C.sameResume(chosen,current[0])))throw Error('简历列表第一份已发生变化，未发送');
          if(current.some(x=>x.el!==chosen.el&&resumeSelected(x.el,mod)))throw Error('识别到多份附件同时选中，未发送');
        },async()=>{await checkpoint({resumeStage:'submit',resumeName:chosen.name,resumeKey:chosen.key});submitted=true;});
        ui('resume_submit_clicked',send,{chatKey:p.chatKey,file:chosen.name});
        const result=await settleResume({...p,resume:chosen},async()=>{await guard();outgoingChat(p);},checkpoint,false);
        // A chooser is intermediate, never a delivered attachment. Do not close it merely to "succeed".
        if(result.verified)await closeResumePicker();
        return {...result,resumeName:chosen.name,resumeSelection:firstFile?'first':'bound'};
      }catch(error){
        // Preserve the actual failure instead of masking it with "modal not closed".
        if(sawPicker&&!submitted)error.beforeClick=true;
        try{await closeResumePicker();}catch(cleanup){error.message+='；'+cleanup.message;}
        ui('resume_error',null,{chatKey:p.chatKey,submitted,reason:error.message.slice(0,160)});
        throw error;
      }
    }
    throw Error('不支持的动作');
  }
  const api={calibrate,setSelectors,visible,all,exact,inspect,snapshot,activity,chatTarget,directions,attachments:()=>attachments().map(({el,...r})=>r),jobs:()=>jobs().map(({el,...r})=>r),currentChat,checkChat,messages,navigate,action,observe,blocker,fileMeta,titleMatches,selectedWithin};
  api.isWritingInput=e=>writingInput===e;
  root.SBLAdapter=api;
})(globalThis);
