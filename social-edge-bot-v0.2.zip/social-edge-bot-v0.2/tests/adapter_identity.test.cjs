const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const body={},context=vm.createContext({document:{body}});
vm.runInContext(fs.readFileSync(__dirname+'/../extension/core.js','utf8'),context);
vm.runInContext(fs.readFileSync(__dirname+'/../extension/adapter.js','utf8'),context);
const A=context.SBLAdapter;
function node(className='',parent=body){return {className,parentElement:parent,getAttribute:()=>null,contains(other){for(let p=other;p&&p!==body;p=p.parentElement)if(p===this)return true;return false;}};}
test('adapter identity: selection on a card wrapper is recognized',()=>{
 const wrap=node('job-card-wrap active'),card=node('job-card-box',wrap),other=node('job-card-box');
 assert.equal(A.selectedWithin(card,[card,other]),true);
});
test('adapter identity: selection on a whole list cannot identify one card',()=>{
 const list=node('active'),first=node('',list),second=node('',list);
 assert.equal(A.selectedWithin(first,[first,second]),false);
});
test('adapter identity: a nested active direction label is recognized',()=>{
 const tab=node('job-tab selected'),label=node('',tab);
 assert.equal(A.selectedWithin(label,[tab,node('job-tab')]),true);
});
test('adapter identity: overlapping selectors for the same tab do not cause a second click',()=>{
 const tab=node('job-tab selected'),label=node('expect-item',tab);
 assert.equal(A.selectedWithin(label,[tab,label,node('job-tab')]),true);
});
test('adapter identity: fullwidth punctuation is normalized',()=>assert.equal(A.titleMatches('AI设计师（高奖金）','AI设计师(高奖金)'),true));
test('adapter identity: a truncated title requires independently selected card',()=>{
 assert.equal(A.titleMatches('AI设计师(高奖金+完善晋升制度)','AI设计师(高奖金...',true),true);
 assert.equal(A.titleMatches('AI设计师(高奖金+完善晋升制度)','AI设计师(高奖金...',false),false);
});
test('adapter identity: short or different truncated titles are rejected',()=>{
 assert.equal(A.titleMatches('AI设计师','AI...',true),false);
 assert.equal(A.titleMatches('平面设计师(高奖金)','AI设计师(高奖金...',true),false);
 assert.equal(A.titleMatches('AI设计师(高奖金)','AI设计师(双休)',true),false);
});
