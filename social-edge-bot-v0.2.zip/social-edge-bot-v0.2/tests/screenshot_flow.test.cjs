// Behavioral reconstruction of the supplied screenshots, NOT captured BOSS HTML.
// No data-sbl hooks, no chat-row selectors from the old adapter, no right pane before click.
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {harness}=require('./dom-harness.cjs');
function screenshotFixture(h,count=3){
  const {el,document}=h,events=[],sent=[];
  h.context.location.pathname='/web/geek/chat';h.context.location.href='https://www.zhipin.com/web/geek/chat';
  const search=el('input',{placeholder:'搜索30天内的联系人'}),list=el('div',{class:'entries-Q'});
  list.scrollHeight=1200;list.clientHeight=500;list.scrollTop=0;list.style.overflowY='auto';
  const left=el('aside',{class:'left-Q'}).append(search,el('div',{},'全部 未读 新招呼 更多'),list);
  const right=el('main',{class:'right-Q'},'与您进行过沟通的 Boss 都会在左侧列表中显示');
  document.body.append(el('div',{class:'chat-container'}).append(left,right));
  const contacts=Array.from({length:count},(_,i)=>({name:['甲女士','乙女士','丙先生'][i]||'招聘者'+i,company:'示例公司'+i,title:i===0?'AI创作':'行业研究',messages:i===0?[]:[{side:'in',text:'请问有什么经验？'}]}));
  let active=null,editor=null,send=null,history=null;
  function bubble(m){return el('div',{class:'message-item-module__row__Q '+(m.side==='out'?'item-myself':'item-friend')}).append(el('div',{class:'text'},m.text));}
  contacts.forEach((person,index)=>{
    const head=el('div',{class:'caption-Q'}).append(el('span',{},person.name),el('span',{},person.company),el('span',{},'HR'));
    const preview=el('p',{class:'preview-Q'},person.messages.at(-1)?.text||'网站预设招呼');
    const row=el('div',{class:'entry-Q'}).append(el('img',{src:'avatar'+index+'.png'}),el('div',{class:'copy-Q'}).append(head,el('span',{},'23:03'),preview));
    person.row=row;person.preview=preview;list.append(row);
    row.onclick=()=>{
      events.push('row:'+index);active=person;
      for(const p of contacts)p.row.className='entry-Q';row.className='entry-Q selected';
      editor=el('textarea',{class:'typing-Q'});send=el('button',{class:'submit-Q'},'发送');send.disabled=true;
      history=el('section',{class:'history-Q'});person.messages.forEach(m=>history.append(bubble(m)));
      right.replaceChildren(el('header').append(el('span',{},person.name),el('span',{},person.company),el('span',{},'HR')),
        el('section',{class:'position-Q'}).append(el('span',{},person.title),el('span',{},'8-12K'),el('a',{},'查看职位')),
        history,el('footer').append(el('button',{},'发简历'),editor,send));
      let inputState='';editor.onclick=()=>events.push('editor:'+index);
      editor.addEventListener('input',event=>{assert.equal(event.target,editor);inputState=editor.value;send.disabled=!inputState;events.push('type:'+index);});
      send.onclick=()=>{
        assert.ok(editor.clicks>0,'Input must actually be clicked before send');assert.equal(document.activeElement,editor);assert.equal(inputState,editor.value);
        events.push('send:'+index);sent.push({name:person.name,text:inputState});const m={side:'out',text:inputState};person.messages.push(m);history.append(bubble(m));preview.textContent=inputState;editor.value='';inputState='';send.disabled=true;
        // Real inbox lists reorder after a send. The runner must retain recipient identity.
        list.replaceChildren(row,...contacts.filter(p=>p!==person).map(p=>p.row));
      };
    };
  });
  return {contacts,list,left,right,events,sent,get active(){return active;},get editor(){return editor;},get send(){return send;}};
}
test('screenshot: left avatar rows are found while right side is empty; click creates a disabled composer',async()=>{
  const h=harness(),f=screenshotFixture(h);const snap=h.A.snapshot();assert.equal(snap.chat,null);assert.equal(snap.conversations.length,3);assert.equal(snap.readiness.editor,false);
  assert.equal(f.right.querySelector('textarea'),null);await h.A.navigate('conversation',{chatKey:snap.conversations[0].key});
  const opened=h.A.snapshot();assert.equal(opened.chat.key,snap.conversations[0].key);assert.equal(opened.chat.title,'AI创作');assert.equal(opened.readiness.editor,true);assert.equal(f.send.disabled,true);
  const result=await h.A.action('intro',{chatKey:opened.chat.key,company:opened.chat.company,title:opened.chat.title,text:'测试自我介绍',robot:true},async()=>{});
  assert.equal(result.verified,true);assert.deepEqual(f.events,['row:0','editor:0','type:0','send:0']);assert.equal(f.sent.length,1);
  assert.deepEqual(Array.from(result.uiActions),['editor_clicked','text_entered','send_clicked','outgoing_seen']);
});
test('screenshot: already-selected row with empty right pane still gets clicked',async()=>{
  const h=harness(),f=screenshotFixture(h);f.contacts[0].row.className+=' selected';const snap=h.A.snapshot();assert.equal(snap.chat,null);
  await h.A.navigate('conversation',{chatKey:snap.conversations[0].key});assert.equal(f.contacts[0].row.clicks,1);assert.ok(h.A.snapshot().chat);
});
test('screenshot: time, unread count, preview and list reordering never change recipient keys',async()=>{
  const h=harness(),f=screenshotFixture(h);const before=Array.from(h.A.snapshot().conversations,x=>x.key);
  f.contacts[1].preview.textContent='[草稿]不要当作姓名或公司';f.contacts[1].row.append(h.el('span',{},'88'));f.list.replaceChildren(...f.contacts.slice().reverse().map(x=>x.row));
  const after=Array.from(h.A.snapshot().conversations,x=>x.key);assert.deepEqual(after,before.slice().reverse());
});
test('screenshot: stale right-side header cannot authorize sending to the newly selected row',async()=>{
  const h=harness(),f=screenshotFixture(h),rows=h.A.snapshot().conversations;await h.A.navigate('conversation',{chatKey:rows[0].key});
  f.contacts[0].row.className='entry-Q';f.contacts[1].row.className='entry-Q selected';f.contacts[1].row.onclick=()=>{};
  await h.A.navigate('conversation',{chatKey:rows[1].key});assert.equal(h.A.snapshot().chat,null);
  await assert.rejects(h.A.action('intro',{chatKey:rows[1].key,text:'不会误发'},async()=>{}),/稳定标识/);assert.equal(f.sent.length,0);
});
test('screenshot: actual robot + adapter click every row, answer by industry, and survive inbox reordering',async()=>{
  const h=harness(),f=screenshotFixture(h);h.context.structuredClone=structuredClone;vm.runInContext(fs.readFileSync(__dirname+'/../extension/robot.js','utf8'),h.context);
  const C=h.context.SBLCore,R=h.context.SBLRobot,c=C.defaults();c.robot.limit=3;c.robot.keepListening=false;c.robot.sendResume=false;c.robot.greeting='测试通用介绍';c.settings.intervalSeconds=0;
  c.industries=[{name:'创作',keywords:['AI创作'],greeting:'测试创作介绍',answers:{experience:'测试创作经历'}},{name:'研究',keywords:['行业研究'],greeting:'测试研究介绍',answers:{experience:'测试研究经历'}}];
  const s=R.start(C.initialState(),c,false);s.status='running';s.chatTabId=1;
  const io={page:async(id,type,p={})=>type==='SNAPSHOT'?h.A.snapshot():type==='NAV'?h.A.navigate(p.kind,p.payload):type==='ACTIVITY'?h.A.activity():null,
    persistRun:async(id,fn)=>fn(s),halt:async reason=>{s.status='paused';s.reason=reason;},connectInbox:async()=>{assert.equal(h.A.snapshot().conversations.length,3);s.task={phase:'robot_scan'};},
    action:async(state,id,kind,payload,apply)=>apply(s,await h.A.action(kind,payload,async()=>{}))};
  for(let i=0;i<150&&s.status==='running';i++)await R.tick(s,c,io);
  assert.equal(s.status,'paused');assert.equal(s.robot.summary.processed,3);assert.equal(s.robot.summary.introductions,3);assert.equal(s.robot.summary.replies,2);
  assert.deepEqual(f.sent,[{name:'甲女士',text:'测试创作介绍'},{name:'乙女士',text:'测试研究介绍'},{name:'乙女士',text:'测试研究经历'},{name:'丙先生',text:'测试研究介绍'},{name:'丙先生',text:'测试研究经历'}]);
  assert.deepEqual(f.events.filter(x=>x.startsWith('row:')).slice(0,3),['row:0','row:1','row:2']);
  assert.equal(new Set(s.robot.order).size,3);assert.equal(s.robot.summary.skipped,0);
});
test('screenshot: even one contact clicks the row with the listener, not the outer list',async()=>{
  const h=harness(),f=screenshotFixture(h,1),rows=h.A.snapshot().conversations;assert.equal(rows.length,1);
  await h.A.navigate('conversation',{chatKey:rows[0].key});assert.equal(f.contacts[0].row.clicks,1);assert.equal(f.list.clicks,0);assert.ok(h.A.snapshot().chat);
});
module.exports={screenshotFixture};
