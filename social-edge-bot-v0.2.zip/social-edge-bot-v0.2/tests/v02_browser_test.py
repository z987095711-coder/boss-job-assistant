"""Current v0.2 DOM and panel tests in Chromium, with mocked chrome API, no account/network."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,re,base64
ROOT=Path(__file__).resolve().parents[1]
ns={'__file__':str(ROOT/'tests/v011_browser_test.py')}
exec((ROOT/'tests/v011_browser_test.py').read_text().split('with sync_playwright() as pw:')[0],ns)
RESUME,PAY,CHROME=ns['RESUME'],ns['PAY'],ns['CHROME']
results=[]
def ok(name,value):
    if not value:raise AssertionError(name)
    results.append({'name':name,'passed':True});print('PASS',name,flush=True)
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1200,'height':900});errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)));page.route('https://**/*',lambda r:r.abort())
    def load(html=RESUME):
        page.goto('about:blank');page.set_content(html)
        for f in ['core.js','adapter.js']:page.add_script_tag(content=(ROOT/'extension'/f).read_text())
    def payload():
        return page.evaluate("p=>{const ms=SBLAdapter.snapshot().messages;return {...p,requested:true,inboundToken:SBLCore.hash(ms.filter(m=>m.side==='in').map(m=>m.id+'|'+m.text).join('\\n')),outboundToken:SBLCore.outboundToken(ms)}}",PAY)
    def act(p=None):
        return page.evaluate("p=>SBLAdapter.action('resume',p,async()=>{}).catch(e=>({error:e.message}))",p or payload())
    load();ok('Explicit incoming native resume card is recognized as actionable',page.evaluate('SBLAdapter.snapshot().resumeConsentAvailable'))
    r=act();ok('Requested first-file delivery clicks Agree, then file zero, then Send',r.get('resumeStatus')=='sent' and page.evaluate("JSON.stringify(actions)==JSON.stringify(['agree','file:0','submit'])"))
    r=act();ok('Second call observes existing receipt and never resubmits file',r.get('already') and page.evaluate('sentFiles.length===1'))
    load();page.evaluate("""()=>{document.querySelector('.card-btn').onclick=()=>{actions.push('agree');document.querySelector('[data-mid=request]').innerHTML='<span>已同意发送附件简历</span>';document.querySelector('#picker').style.display='block'};}""")
    r=act();ok('Request card changes after Agree do not falsely invalidate the continuation',r.get('resumeStatus')=='sent' and page.evaluate('sentFiles.length===1'))
    load();page.evaluate("""()=>{const strip=document.createElement('div');strip.className='message-tip-bar';strip.innerHTML='我想要一份您的附件简历，您是否同意 <button>同意</button>';strip.querySelector('button').onclick=()=>actions.push('wrong-duplicate');document.querySelector('[data-sbl-chat]').append(strip);const phone=document.createElement('div');phone.dataset.sblMessage='';phone.dataset.sblSide='in';phone.dataset.mid='phone';phone.innerHTML='我想与您交换电话 <button>同意</button>';phone.querySelector('button').onclick=()=>actions.push('wrong-phone');document.querySelector('#msgs').append(phone);}""")
    r=act();ok('Duplicate sticky Agree and phone-exchange Agree are not clicked',r.get('resumeStatus')=='sent' and page.evaluate("!actions.includes('wrong-phone')&&!actions.includes('wrong-duplicate')&&actions.filter(x=>x==='agree').length===1"))
    load();page.evaluate("""()=>{document.querySelector('[data-mid=request]').remove();const strip=document.createElement('div');strip.className='message-tip-bar';strip.innerHTML='我想要一份您的附件简历，您是否同意 <button>同意</button>';strip.querySelector('button').onclick=()=>{actions.push('sticky-agree');document.querySelector('#picker').style.display='block'};document.querySelector('[data-sbl-chat]').append(strip);}""")
    ok('Current-conversation sticky request alone is recognized',page.evaluate('SBLAdapter.snapshot().resumeConsentAvailable'));r=act();ok('Sticky-only resume request follows Agree/first-file/Send chain',r.get('resumeStatus')=='sent' and page.evaluate("actions[0]==='sticky-agree'&&sentFiles[0]==='第一份.pdf'"))
    load();page.evaluate("""()=>{document.querySelector('[data-mid=request]').innerHTML='我想与您交换微信，是否同意 <span class=card-btn>同意</span>';document.querySelector('.card-btn').onclick=()=>actions.push('wrong-wechat');document.querySelector('.toolbar-btn').remove();}""")
    ok('Phone/WeChat request is not mislabeled as resume consent',not page.evaluate('SBLAdapter.snapshot().resumeConsentAvailable'));r=act();ok('No toolbar or resume card does not fall back to a generic Agree',bool(r.get('error')) and page.evaluate('actions.length===0'))
    load();p=payload();page.evaluate("""()=>{const old=document.querySelector('.card-btn').onclick;document.querySelector('.card-btn').onclick=()=>{old();const m=document.createElement('div');m.dataset.sblMessage='';m.dataset.sblSide='in';m.dataset.mid='new-question';m.textContent='期望薪资多少？';document.querySelector('#msgs').append(m)};}""");r=act(p)
    ok('A genuinely new HR question after Agree blocks stale submission',bool(r.get('error')) and '变化' in r['error'] and page.evaluate('sentFiles.length===0'))
    load();p=payload();page.evaluate("""()=>{const old=document.querySelector('.card-btn').onclick;document.querySelector('.card-btn').onclick=()=>{old();const m=document.createElement('div');m.dataset.sblMessage='';m.dataset.sblSide='in';m.dataset.mid='stop';m.textContent='不要再联系我';document.querySelector('#msgs').append(m)};}""");r=act(p)
    ok('Do-not-contact received during attachment sequence prevents sending',bool(r.get('error')) and page.evaluate('sentFiles.length===0'))
    load();page.evaluate("""()=>{document.querySelector('.card-btn').onclick=()=>{actions.push('agree-native-send');selectedFile='网站当前默认.pdf';sentFiles.push(selectedFile);receipt()};}""");r=act()
    ok('Website direct-send variant is recorded as website-default without opening/sending twice',r.get('resumeStatus')=='sent' and r.get('resumeSelection')=='website-default' and page.evaluate('actions.length===1&&sentFiles.length===1'))
    # Actual worker authorization + actual content.js + actual adapter, only chrome is mocked.
    load();p=payload();page.evaluate(CHROME);page.add_script_tag(content=(ROOT/'extension/robot.js').read_text());page.add_script_tag(content=re.sub(r'^import .*?;\s*','',(ROOT/'extension/background.mjs').read_text(),flags=re.M));page.add_script_tag(content=(ROOT/'extension/content.js').read_text())
    page.evaluate("()=>{db.config=SBLCore.defaults();db.state={...SBLCore.initialState(),status:'running',mode:'live',runId:'browser-fixture',epoch:1,workflow:'outreach',jobTabId:1,chatTabId:1,task:{phase:'monitor_read',chatKey:'chat:hr-test'}};ticking=true;}")
    r=page.evaluate("async p=>{await action(structuredClone(db.state),1,'resume',p,(s,r)=>{s.result=r;s.status='paused'});return {result:db.state.result,pending:db.state.pending,journal,actions,sentFiles}}",p)
    ok('Production worker/content journal authorizes request Agree then first-file submit once',r.get('result',{}).get('resumeStatus')=='sent' and r['pending'] is None and [x['resumeStage'] for x in r['journal']]==['opening-picker','submit'] and r['actions']==['agree','file:0','submit'])
    # Panel's real JS in a narrow rendered page, with only chrome runtime replaced.
    page.goto('about:blank');html=re.sub(r'<script[^>]*>.*?</script>|<link[^>]*>','',(ROOT/'extension/panel.html').read_text(),flags=re.S);page.set_content(html)
    page.add_style_tag(content=(ROOT/'extension/panel.css').read_text());page.add_script_tag(content=(ROOT/'extension/core.js').read_text());page.add_script_tag(content=(ROOT/'extension/robot.js').read_text())
    page.locator('#brandIcon').evaluate('(e,x)=>e.src=x','data:image/png;base64,'+base64.b64encode((ROOT/'extension/icons/128.png').read_bytes()).decode())
    page.evaluate("""()=>{window.calls=[];window.testDB={config:SBLCore.cleanConfig({profiles:[{name:'测试方向',greeting:'已确认测试介绍',overrides:{}}]}),state:SBLCore.initialState()};window.testTabs=[];window.chrome={runtime:{getURL:p=>'file:///fixture/'+p,sendMessage:async m=>{calls.push(structuredClone(m));const d=testDB;let data={};if(m.type==='GET')data=structuredClone(d);if(m.type==='SAVE'){d.config=SBLCore.cleanConfig(m.config);data={config:d.config}}if(m.type==='TABS')data=testTabs;if(m.type==='OPEN_JOBS'){testTabs=[{id:7,url:'https://www.zhipin.com/web/geek/jobs?ka=header-jobs',active:true,windowId:1}];data=testTabs[0]}if(m.type==='INSPECT')data={canReadJobs:true,counts:{jobCards:15},parsedJobsCount:15,loggedIn:true,blocker:''};if(m.type==='START_REPLY'){d.config=SBLCore.cleanConfig(m.config);d.state=SBLRobot.start(d.state,d.config,false,{continuous:m.continuous,onlyPending:m.continuous});d.state.chatTabId=9;data={tabId:9}}return {ok:true,data}}}};}""")
    page.add_script_tag(content=(ROOT/'extension/panel.js').read_text());page.wait_for_selector('#answer-status',state='attached');page.set_viewport_size({'width':390,'height':844});page.locator('#steps button').nth(2).click();page.locator('#openBindJobs').click();page.wait_for_timeout(800)
    ok('One-click job page opening automatically binds parsed source without sending',page.evaluate("testDB.config.profiles[0].sourceUrl.includes('/jobs?ka=header-jobs')&&calls.some(x=>x.type==='INSPECT')&&!calls.some(x=>x.type==='START')") and '15' in page.locator('#sourceResult').inner_text())
    page.screenshot(path=str(ROOT/'docs/v02-step3-fixture.png'),full_page=True)
    ok('Step three fits 390px and retains the original product icon',page.evaluate('document.documentElement.scrollWidth<=innerWidth') and page.locator('#brandIcon').evaluate('e=>e.naturalWidth>0'))
    page.locator('#steps button').nth(4).click();ok('Automatic handoff and system sleep prevention are checked by default',page.locator('#autoReplyAfterBatch').is_checked() and page.locator('#keepAwake').is_checked())
    page.locator('#steps button').nth(5).click();page.locator('#startReply').click();page.wait_for_timeout(1400)
    ok('One live start authorizes entire-inbox continuous pending-only mode',page.evaluate("testDB.state.robot.continuous&&testDB.state.robot.onlyPending&&calls.filter(x=>x.type==='START_REPLY').length===1"))
    page.evaluate("()=>{testDB.state.robot.watch.lastCheckAt=Date.now();testDB.state.task={phase:'robot_watch'};testDB.state.reason='值守中 · 暂无新消息';}");page.wait_for_timeout(1400)
    ok('Live status distinguishes monitoring, last check and absence of new messages', '消息值守已开启' in page.locator('#watchHealth').inner_text() and '最近检查' in page.locator('#watchHealth').inner_text())
    page.evaluate('window.scrollTo(0,0)');page.screenshot(path=str(ROOT/'docs/v02-step6-fixture.png'),full_page=True)
    ok('Step six fits 390px without horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    for width in [340,360,480]:
        page.set_viewport_size({'width':width,'height':844});ok(f'Continuous panel fits {width}px without horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    ok('No uncaught JavaScript errors in actual rendered DOM and panel',not errors)
    browser.close()
report={'version':'0.2.0','environment':'Actual Chromium / synthetic DOM / mocked chrome API. Not native MV3 or live BOSS.','passed':len(results),'total':len(results),'tests':results}
(ROOT/'tests/v02-browser-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'passed':len(results),'total':len(results)}),flush=True)
