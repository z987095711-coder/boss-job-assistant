const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),{webcrypto}=require('node:crypto');
function harness(options={}){
  const powerEvents=[];const data={},events={},counts={contact:0,text:0,resume:0},tabs=new Map([[1,{id:1,url:'https://www.zhipin.com/web/geek/job'}]]),messages=[{id:'i0',side:'in',text:'你好'}];let nextId=2,clock=0,idleState=options.idleState||'active';
  class ClockDate extends Date{static now(){return Date.now()+clock;}}
  const jobs=Array.from({length:options.jobCount||1},(_,i)=>({key:'job:j'+(i+1),title:'AI 创作 '+(i+1),company:'测试公司 '+(i+1),summary:'AI 创作 测试公司',url:''}));let job=jobs[0];const effects=[],inboxes=new Map(jobs.map(j=>[j.key,[{id:'hello',side:'in',text:'你好'}]])),contacted=new Set(),attempts=new Map(),resumeStates=new Map();
  function rowsFor(tab){const order=options.reorder?jobs.slice().sort((a,b)=>inboxes.get(b.key).length-inboxes.get(a.key).length):jobs;return order.slice(tab.listOffset||0,(tab.listOffset||0)+(options.pageSize||jobs.length)).map(j=>({key:j.key.replace('job:','chat:'),name:'测试招聘者',company:j.company,title:j.title,system:options.systemJob===j.key,...(options.rowProperties?.[j.key]||{})}));}
  const event=k=>({addListener:f=>{events[k]=f;}});
  function activityFor(tab){
    if(!tab.url.includes('/chat'))return {rows:[],active:null};
    const active=jobs.find(j=>j.key===tab.jobKey)||job;
    const ms=inboxes.get(active.key);
    const rows=options.realActivity?rowsFor(tab).map(row=>{const ms=inboxes.get(row.key.replace('chat:','job:'))||[];return {...row,token:JSON.stringify(ms),lastSide:row.lastSide||ms.filter(m=>['in','out'].includes(m.side)).at(-1)?.side||'',unread:row.unread===true};}):jobs.map(j=>({key:j.key.replace('job:','chat:'),token:JSON.stringify(inboxes.get(j.key)),unread:false}));
    return {rows,active:{key:active.key.replace('job:','chat:'),token:JSON.stringify(ms.filter(x=>x.side==='in')),hasInbound:ms.some(x=>x.side==='in')}};
  }
  const chrome={
    storage:{local:{get:async keys=>{const out={};for(const k of Array.isArray(keys)?keys:[keys])if(k in data)out[k]=structuredClone(data[k]);return out;},set:async obj=>{Object.assign(data,structuredClone(obj));},setAccessLevel:async()=>{},clear:async()=>Object.keys(data).forEach(k=>delete data[k])}},
    runtime:{id:'test',getURL:p=>'chrome-extension://test/'+p,onInstalled:event('installed'),onStartup:event('startup'),onMessage:event('message')},
    idle:{queryState:async()=>idleState,setDetectionInterval:()=>{},onStateChanged:event('idle')},
    sidePanel:{setPanelBehavior:async()=>{}},power:{releaseKeepAwake:()=>{powerEvents.push('release')},requestKeepAwake:v=>{powerEvents.push(v)}},
    action:{setBadgeText:async()=>{},setBadgeBackgroundColor:async()=>{}},alarms:{get:async()=>null,create:async()=>{},onAlarm:event('alarm')},scripting:{executeScript:async()=>{}},
    tabs:{onCreated:event('created'),get:async id=>{if(!tabs.has(id))throw Error('closed');return tabs.get(id);},query:async()=>[...tabs.values()],
      create:async opt=>{const tab={id:nextId++,url:opt.url,jobKey:job.key};tabs.set(tab.id,tab);return tab;},update:async(id,opt)=>{Object.assign(tabs.get(id),opt);if(opt.active){tabs.get(id).frozen=false;tabs.get(id).discarded=false;}if(opt.url?.includes('/chat?'))tabs.get(id).jobKey=job.key;effects.push({kind:'return',id,url:tabs.get(id).url,hard:!!opt.url});return tabs.get(id);},remove:async id=>tabs.delete(id),goBack:async id=>{effects.push({kind:'return',id,method:'history'});if(options.noHistory)throw Error('No history');tabs.get(id).url='https://www.zhipin.com/web/geek/job';},
      sendMessage:async(id,m)=>{
        const tab=tabs.get(id),chat=tab.url.includes('/chat')||tab.embeddedChat;const active=jobs.find(j=>j.key===tab.jobKey)||job;const messages=inboxes.get(active.key);
        if(m.type==='INSPECT')return {ok:true,data:{path:tab.url.split('?')[0],route:chat?'chat':'jobs',counts:{conversationRows:chat&&!options.noRows?jobs.length:0},canReadJobs:!chat,blocker:options.blocker||'',loggedIn:options.loggedIn!==false}};
        if(m.type==='CHAT_TARGET'){effects.push({kind:'probe'});if(options.probeFails)throw Error('title probe failed');return {ok:true,data:{url:options.publicChatUrl?'https://www.zhipin.com/web/geek/chat?public='+job.key:''}};}
        if(m.type==='ACTIVITY'){effects.push({kind:'listen',id});return {ok:true,data:activityFor(tab)};}
        if(m.type==='NAV'){
          if(m.kind==='inbox'){
            effects.push({kind:'inbox',id});if(options.noInbox)return {ok:false,error:'网页上没有识别到消息／沟通入口，尚未打开消息页'};
            if(options.inboxNewTab){const child={id:nextId++,url:'https://www.zhipin.com/web/geek/chat',jobKey:job.key,openerTabId:id};tabs.set(child.id,child);events.created(child);}
            else tab.url='https://www.zhipin.com/web/geek/chat';
            if(options.lostInboxReply)throw Error('The message port closed before a response was received.');
          }
          if(m.kind==='job'){job=jobs.find(j=>j.key===m.payload.key);tab.jobKey=job.key;}
          if(m.kind==='conversation'){if(!options.openFails){tab.jobKey=m.payload.chatKey.replace('chat:','job:');tab.rowOpened=true;}effects.push({kind:'openChat',job:tab.jobKey});}
          if(m.kind==='conversations_top'||m.kind==='conversations_more'){tab.listOffset=m.kind==='conversations_top'?0:Math.min(Math.max(0,jobs.length-(options.pageSize||jobs.length)),(tab.listOffset||0)+(options.pageSize||jobs.length));effects.push({kind:m.kind,offset:tab.listOffset});return {ok:true,data:{end:tab.listOffset>=jobs.length-(options.pageSize||jobs.length)}};}
          if(m.kind==='continue'){
            tab.rowOpened=false;
            effects.push({kind:'continue',job:job.key});
            if(options.newTab){const child={id:nextId++,url:'https://www.zhipin.com/web/geek/chat',jobKey:job.key,openerTabId:id};tabs.set(child.id,child);events.created(child);}
            else if(options.embeddedChat)tab.embeddedChat=true;else tab.url='https://www.zhipin.com/web/geek/chat';
            if(options.lostNavReply)throw Error('The message port closed before a response was received.');
          }
          if(m.kind==='more')return {ok:true,data:{end:true}};
          return {ok:true,data:{ok:true}};
        }
        if(m.type==='SNAPSHOT'){if(options.beforeSnapshot)await options.beforeSnapshot({messages,jobKey:active.key});return {ok:true,data:{url:tab.url,route:chat?'chat':'jobs',blocker:'',jobs:chat?[]:jobs,chat:chat&&(!options.blankUntilRowClick||tab.rowOpened)?{key:active.key.replace('job:','chat:'),title:active.title,company:active.company,jobKey:active.key}:null,messages:chat?messages:[],conversations:chat&&!options.noRows?rowsFor(tab):[],resumeReceipt:resumeStates.get(active.key)==='sent',activity:activityFor(tab)}};}
        if(m.type==='RECOVER'){
          effects.push({kind:'observe',job:active.key});
          if(m.kind==='initiate')return {ok:true,data:{verified:contacted.has(m.payload.key),title:active.title}};
          if(['resume','resumeConsent','resumeOffer'].includes(m.kind))return {ok:true,data:{verified:!!resumeStates.get(active.key),resumeStatus:resumeStates.get(active.key),candidate:options.nativeChooser?{name:'研究简历.pdf',meta:''}:null}};
          return {ok:true,data:{verified:messages.filter(x=>x.side==='out'&&x.text===m.payload.text).length>m.evidence.beforeCount}};
        }
        if(m.type==='ACTION'){
          // Exercise the real runtime authorization check before changing mocked external state.
          const auth=await new Promise(resolve=>events.message({sbl:true,type:'ALLOW',runId:m.runId,epoch:m.epoch,opId:m.opId},{id:'test',url:tab.url,tab:{id}},resolve));
          if(!auth.data?.allowed)return {ok:false,error:'no authorization'};
          if(options.beforeAction)await options.beforeAction({kind:m.kind,jobKey:active.key,payload:m.payload});
          if(m.kind==='intro'&&options.textPreclickFailures&&(!options.textFailJob||options.textFailJob===active.key)){
            const key='text:'+active.key;attempts.set(key,(attempts.get(key)||0)+1);
            if(attempts.get(key)<=options.textPreclickFailures)return {ok:false,error:'目标按钮尚未启用，尚未点击',beforeClick:true};
          }
          if(m.kind==='initiate'){
            attempts.set(job.key,(attempts.get(job.key)||0)+1);
            if(options.blockedBefore)return {ok:false,error:'平台验证、登录或额度限制：请到网站处理',blocker:true};
            if((!options.failJob||options.failJob===job.key)&&(attempts.get(job.key)<=Number(options.preclickFailures||0)))return {ok:false,error:'未点击：详情标题未匹配'};
          }
          const beforeCount=messages.filter(x=>x.side==='out'&&x.text===m.payload.text).length;
          const stage=await new Promise(resolve=>events.message({sbl:true,type:'ACTION_STAGE',runId:m.runId,epoch:m.epoch,opId:m.opId,evidence:{beforeCount,title:job.title}},{id:'test',url:tab.url,tab:{id}},resolve));
          if(!stage.data?.allowed)return {ok:false,error:stage.error};
          if(m.kind==='initiate'){counts.contact++;contacted.add(job.key);effects.push({kind:'contact',job:job.key});if(options.lostInitiateReply)throw Error('The message port closed before a response was received.');}
          if(m.kind==='continue')tab.url='https://www.zhipin.com/web/geek/chat';
          if(['intro','reply','followup','rejection'].includes(m.kind)){counts.text++;effects.push({kind:m.kind,job:active.key,text:m.payload.text,at:ClockDate.now()});if(!options.noTextReceipt&&options.noTextReceiptJob!==active.key)messages.push({id:'out'+counts.text,side:'out',text:m.payload.text});if(options.explicitFailJob===active.key)return {ok:true,data:{verified:false,definitiveFailure:true,reason:'发送失败'}};if(options.afterWrite)await options.afterWrite({kind:m.kind,jobKey:active.key});if(options.lostSendReply||options.lostSendKind===m.kind||options.noTextReceipt||options.noTextReceiptJob===active.key)throw Error('The message port closed before a response was received.');}
          if(['resume','resumeConsent','resumeOffer'].includes(m.kind)){
            const status=options.nativeChooser&&m.kind!=='resume'?'selecting':options.resumeWaiting?'waiting':'sent';resumeStates.set(active.key,status);if(status==='sent')counts.resume++;
            effects.push({kind:m.kind,job:active.key,filename:m.payload.resume?.name||'website-default'});
            if(options.lostSendKind===m.kind)throw Error('The message port closed before a response was received.');
            return {ok:true,data:{verified:true,resumeStatus:status,candidate:status==='selecting'?{name:'研究简历.pdf',meta:''}:null}};
          }
          return {ok:true,data:{verified:true}};
        }
        throw Error('unhandled page request '+m.type);
      }
    }
  };
  const context=vm.createContext({chrome,console,structuredClone,crypto:webcrypto,URL,Date:ClockDate,Math,setTimeout,clearTimeout});
  vm.runInContext(fs.readFileSync(__dirname+'/../extension/core.js','utf8'),context);
  vm.runInContext(fs.readFileSync(__dirname+'/../extension/robot.js','utf8'),context);
  vm.runInContext(fs.readFileSync(__dirname+'/../extension/background.mjs','utf8').replace(/^import .*;$/gm,''),context);
  const req=(type,rest={},sender={id:'test',url:'chrome-extension://test/panel.html'})=>new Promise((resolve,reject)=>events.message({sbl:true,type,...rest},sender,r=>r.ok?resolve(r.data):reject(Error(r.error))));
  async function initialize(){
    await vm.runInContext('setup()',context);
    const c=context.SBLCore.defaults();c.settings.autoReplyAfterBatch=false;c.settings.resumeSelection='bound';c.attachments=[{key:'r1',name:'研究简历.pdf',meta:''}];c.profiles=[{name:'创作方向',sourceUrl:'https://www.zhipin.com/web/geek/job',sourceLabel:'创作方向',resumeKey:'r1',greeting:'真实项目介绍',enabled:true,overrides:{}}];c.settings.batchLimit=1;await req('SAVE',{config:c});
  }
  async function pulse(){clock+=1000;data.state.nextAt=0;await vm.runInContext('tick()',context);await new Promise(r=>setTimeout(r,0));}
  async function notify(){const id=data.state.chatTabId;return req('CHAT_ACTIVITY',{activity:activityFor(tabs.get(id)),version:context.SBLCore.VERSION},{id:'test',url:tabs.get(id).url,tab:{id}});}
  return {data,counts,powerEvents,tabs,req,initialize,pulse,context,effects,inboxes,jobs,resumeStates,notify,events,advance:ms=>{clock+=ms;},setIdle:v=>{idleState=v;},idleCheck:async()=>{await vm.runInContext('checkIdleAutomation(true)',context);await vm.runInContext('tick()',context);},now:()=>ClockDate.now()};
}
async function finishRobot(h,max=450){for(let i=0;i<max&&h.data.state.status==='running';i++)await h.pulse();assert.notEqual(h.data.state.status,'running','reply robot failed to finish: '+JSON.stringify(h.data.state.task));assert.equal(h.data.state.status,'paused',h.data.state.reason);}
async function beginRobot(h,configure=()=>{},dryRun=false){await h.initialize();h.data.config.robot.keepListening=false;configure(h.data.config);await h.req('START_REPLY',{dryRun,consent:!dryRun});}
test('v9: outreach creates jobs automatically without a manually selected or bound page',async()=>{
 const h=harness();await h.initialize();h.tabs.get(1).url='https://www.zhipin.com/web/geek/resume';h.data.config.profiles[0].sourceUrl='';
 const r=await h.req('START',{mode:'live',consent:true});assert.notEqual(r.tabId,1);assert.equal(h.tabs.get(r.tabId).url,'https://www.zhipin.com/web/geek/jobs?ka=header-jobs');
 for(let i=0;i<80&&h.data.state.status==='running';i++)await h.pulse();assert.equal(h.data.state.liveVerified,1);assert.equal(h.data.state.status,'paused');assert.match(h.tabs.get(1).url,/resume$/);
});
test('v9: existing chat is reused without navigating an unrelated selected page',async()=>{
 const h=harness();await h.initialize();h.tabs.get(1).url='https://www.zhipin.com/web/geek/chat';h.data.config.robot.keepListening=false;h.data.config.robot.sendResume=false;
 const r=await h.req('START_REPLY',{consent:true});assert.equal(r.tabId,1);await finishRobot(h);assert.equal(h.tabs.size,1);assert.equal(h.counts.text,1);
});
test('v9: jobs loading delays clicks and resumes automatically when cards load',async()=>{
 const h=harness();await h.initialize();h.tabs.get(1).status='loading';await h.req('START',{mode:'live',consent:true});for(let i=0;i<4;i++)await h.pulse();assert.equal(h.counts.contact,0);assert.equal(h.data.state.task.phase,'jobs_entry');
 h.tabs.get(1).status='complete';for(let i=0;i<80&&h.data.state.status==='running';i++)await h.pulse();assert.equal(h.data.state.liveVerified,1);assert.equal(h.data.state.status,'paused');
});
test('v9: a new batch resets full-loop completion while retaining historical job deduplication',async()=>{
 const h=harness();await h.initialize();h.data.state.liveVerified=10;h.data.state.manualMonitor=true;h.data.state.seenJobs['job:historical']={status:'complete'};
 await h.req('START',{mode:'live',consent:true});assert.equal(h.data.state.liveVerified,0);assert.equal(h.data.state.manualMonitor,false);assert.equal(h.data.state.seenJobs['job:historical'].status,'complete');await h.req('PAUSE');
});
test('v9: insufficient unseen jobs reports an incomplete batch instead of silently listening',async()=>{
 const h=harness({jobCount:2});await h.initialize();h.data.config.settings.batchLimit=10;await h.req('START',{mode:'live',consent:true});
 for(let i=0;i<120&&h.data.state.status==='running';i++)await h.pulse();assert.equal(h.data.state.liveVerified,2);assert.equal(h.counts.text,2);assert.equal(h.data.state.status,'paused');assert.match(h.data.state.reason,/2 \/ 10.*未达目标/);
});
test('v9: known pre-send failures retry without abandoning the current introduction',async()=>{
 const h=harness({jobCount:2,textPreclickFailures:2});await h.initialize();h.data.config.settings.batchLimit=2;await h.req('START',{mode:'live',consent:true});
 for(let i=0;i<160&&h.data.state.status==='running';i++)await h.pulse();assert.equal(h.counts.contact,2);assert.equal(h.counts.text,2);assert.equal(h.data.state.liveVerified,2);assert.equal(h.data.state.stats.retries,4);assert.equal(h.data.state.stats.attention,0);
});
for(const newTab of [false,true])test('fixed ten-job loop: Continue opens blank inbox, click row, introduce, return; newTab='+newTab,async()=>{
 const h=harness({jobCount:12,newTab,blankUntilRowClick:true});await h.initialize();h.data.config.settings.batchLimit=10;h.data.config.settings.sendResume=false;
 await h.req('START',{tabId:1,mode:'live',consent:true});for(let i=0;i<400&&h.data.state.status==='running';i++)await h.pulse();
 assert.equal(h.data.state.liveVerified,10,JSON.stringify({task:h.data.state.task,reason:h.data.state.reason}));assert.equal(h.counts.contact,10);assert.equal(h.counts.text,10);
 for(const job of h.jobs.slice(0,10)){const contact=h.effects.findIndex(x=>x.kind==='contact'&&x.job===job.key),next=h.effects.findIndex(x=>x.kind==='continue'&&x.job===job.key),open=h.effects.findIndex(x=>x.kind==='openChat'&&x.job===job.key),intro=h.effects.findIndex(x=>x.kind==='intro'&&x.job===job.key);assert.ok(contact<next&&next<open&&open<intro,job.key+' requires click order');const returned=h.effects.findIndex((x,i)=>i>intro&&x.kind==='return');assert.ok(returned>intro);const nextContact=h.effects.findIndex((x,i)=>i>intro&&x.kind==='contact');if(nextContact>=0)assert.ok(returned<nextContact);}
 assert.ok(h.tabs.size<=2);assert.equal(h.data.state.status,'paused');assert.match(h.data.state.reason,/10 \/ 10/);for(let i=0;i<12;i++)await h.pulse();assert.equal(h.counts.text,10);assert.equal(h.counts.contact,10);
});
test('v9: reply start automatically opens chat before scanning messages',async()=>{
 const h=harness();await beginRobot(h,c=>{c.robot.sendResume=false;});await finishRobot(h);assert.equal(h.effects.filter(x=>x.kind==='inbox').length,0);assert.equal(h.data.state.robot.summary.introductions,1);assert.ok(h.data.state.robot.trace.some(x=>x.event==='inbox_ready'));
});
test('v9: reply start avoids the old inbox menu navigation channel',async()=>{
 const h=harness({lostInboxReply:true});await beginRobot(h,c=>{c.robot.sendResume=false;});await finishRobot(h);assert.equal(h.effects.filter(x=>x.kind==='inbox').length,0);assert.equal(h.counts.text,1);
});
test('v9: automatically created inbox is bound before typing',async()=>{
 const h=harness({inboxNewTab:true});await beginRobot(h,c=>{c.robot.sendResume=false;});await finishRobot(h);assert.notEqual(h.data.state.chatTabId,1);assert.equal(h.counts.text,1);assert.equal(h.effects.filter(x=>x.kind==='inbox').length,0);
});
test('v7: unknown chat DOM automatically captures actual failing chat page',async()=>{
 const h=harness({noRows:true});await beginRobot(h);for(let i=0;i<90&&h.data.state.status==='running';i++)await h.pulse();assert.equal(h.data.state.status,'blocked');assert.match(h.data.state.reason,/已到消息页/);assert.ok(h.data.state.lastError.pages.some(x=>x.inspection?.route==='chat'));assert.equal(h.counts.text,0);
});
test('v7: diagnostics prefer robot work tab even when dropdown still points at jobs',async()=>{
 const h=harness({inboxNewTab:true});await beginRobot(h,c=>{c.robot.sendResume=false;});await finishRobot(h);const r=await h.req('DIAGNOSTIC',{tabId:1});assert.equal(r.inspection.route,'chat');assert.equal(r.workingTabId,h.data.state.chatTabId);assert.equal(r.selectedTabId,1);assert.ok(r.pages.some(x=>x.tabId===1&&x.inspection.route==='jobs'));assert.ok(r.reply.events.some(x=>x.event==='opened'));
});
test('v9: missing website message menu does not prevent direct chat startup',async()=>{
 const h=harness({noInbox:true});await beginRobot(h,c=>{c.robot.sendResume=false;});await finishRobot(h);assert.equal(h.counts.text,1);assert.equal(h.effects.filter(x=>x.kind==='inbox').length,0);
});
test('v7: chat embedded in original job route can be discovered after Continue',async()=>{
 const h=harness({embeddedChat:true});await h.initialize();h.data.config.settings.sendResume=false;await h.req('START',{tabId:1,mode:'live',consent:true});for(let i=0;i<60&&!h.counts.text;i++)await h.pulse();assert.equal(h.counts.contact,1);assert.equal(h.counts.text,1,h.data.state.reason);await h.req('PAUSE');
});
test('reply robot: standalone opens existing unmanaged chats, introduces each, then offers resume',async()=>{
 const h=harness({jobCount:3});await beginRobot(h,c=>{c.profiles=[];c.attachments=[];c.robot.limit=3;});await finishRobot(h);
 assert.equal(h.counts.contact,0);assert.equal(h.counts.text,3);assert.equal(h.counts.resume,3);assert.equal(h.data.state.robot.summary.processed,3);
 const sends=h.effects.filter(x=>['intro','resumeOffer'].includes(x.kind));assert.deepEqual(sends.map(x=>x.kind),['intro','intro','intro','resumeOffer','resumeOffer','resumeOffer']);
 assert.equal(new Set(sends.filter(x=>x.kind==='intro').map(x=>x.job)).size,3);assert.ok(h.effects.some(x=>x.kind==='openChat'));
 assert.ok(h.data.state.robot.trace.some(e=>e.event==='dispatched'));assert.ok(h.data.state.robot.trace.some(e=>e.event==='confirmed'));
 assert.ok(!h.effects.some(x=>x.kind==='return'&&x.hard),'No page refresh for reply traversal');
});
test('reply robot: paginated existing list is traversed by stable ID, including second-round lookup',async()=>{
 const h=harness({jobCount:6,pageSize:2});await beginRobot(h,c=>{c.robot.limit=5;});await finishRobot(h);
 assert.equal(h.data.state.robot.order.length,5);assert.equal(h.data.state.robot.summary.introductions,5);assert.equal(h.data.state.robot.summary.resumes,5);
 assert.ok(h.effects.some(e=>e.kind==='conversations_more'));assert.ok(h.effects.some(e=>e.kind==='conversations_top'));
});
test('reply robot: list reorder after sending cannot cause repeat or wrong row selection',async()=>{
 const h=harness({jobCount:4,reorder:true});await beginRobot(h,c=>{c.robot.limit=4;});await finishRobot(h);
 const intros=h.effects.filter(e=>e.kind==='intro');assert.equal(intros.length,4);assert.equal(new Set(intros.map(e=>e.job)).size,4);
});
test('reply robot: recruitment system/promotion rows are excluded',async()=>{
 const h=harness({jobCount:3,systemJob:'job:j2'});await beginRobot(h);await finishRobot(h);
 assert.equal(h.data.state.robot.summary.processed,2);assert.ok(!h.effects.some(e=>['intro','resumeOffer'].includes(e.kind)&&e.job==='job:j2'));
});
test('reply robot: keyword question selects the matching industry answer in a real worker run',async()=>{
 const h=harness();h.inboxes.set('job:j1',[{id:'q',side:'in',text:'会哪些软件？'}]);
 await beginRobot(h,c=>{c.answers.skills='通用已确认工具';c.industries=[{name:'创作行业',keywords:['创作'],answers:{skills:'本行业已确认的工具'}}];c.robot.sendResume=false;});await finishRobot(h);
 assert.equal(h.effects.filter(e=>e.kind==='reply').length,1);assert.equal(h.effects.find(e=>e.kind==='reply').text,'本行业已确认的工具');
 assert.equal(h.data.state.robot.summary.replies,1);
});
test('reply robot: actual resume consent then chooser selection uses separate effects',async()=>{
 const h=harness({nativeChooser:true});h.inboxes.set('job:j1',[{id:'r',side:'in',text:'我想要一份你的附件简历',resumeRequest:true}]);await beginRobot(h);await finishRobot(h);
 assert.deepEqual(h.effects.filter(e=>['intro','resumeConsent','resume'].includes(e.kind)).map(e=>e.kind),['intro','resumeConsent','resume']);
 assert.equal(h.effects.find(e=>e.kind==='resume').filename,'研究简历.pdf');assert.equal(h.counts.resume,1);assert.equal(h.data.state.robot.summary.resumes,1);
});
test('reply robot: permission request awaiting recipient is not counted as a delivered resume',async()=>{
 const h=harness({resumeWaiting:true});await beginRobot(h);await finishRobot(h);assert.equal(h.data.state.robot.summary.resumes,0);assert.equal(h.data.state.robot.summary.requests,1);assert.equal(h.counts.resume,0);
});
test('reply robot: ordinary refusal gets one question; explicit no-contact gets nothing',async()=>{
 const h=harness({jobCount:2});h.inboxes.set('job:j1',[{id:'reject',side:'in',text:'很抱歉，与我们岗位不太匹配。'}]);h.inboxes.set('job:j2',[{id:'stop',side:'in',text:'不要再联系我了'}]);await beginRobot(h);await finishRobot(h);
 assert.deepEqual(h.effects.filter(e=>['intro','rejection'].includes(e.kind)).map(e=>[e.kind,e.job]),[['intro','job:j1'],['rejection','job:j1']]);assert.equal(h.counts.resume,0);assert.equal(h.data.state.conversations['chat:j2'].hardStop,true);
 const count=h.counts.text;await h.req('START_REPLY',{consent:true});await finishRobot(h);assert.equal(h.counts.text,count,'Restart must not repeat intro or rejection question');
});
test('reply robot: disabling ordinary refusal question does not permanently mark hard stop',async()=>{
 const h=harness();h.inboxes.set('job:j1',[{id:'reject',side:'in',text:'不合适'}]);await beginRobot(h,c=>{c.robot.followRejection=false;});await finishRobot(h);assert.equal(h.data.state.conversations['chat:j1'].hardStop,false);assert.equal(h.counts.text,0);
 h.data.config.robot.followRejection=true;await h.req('START_REPLY',{consent:true});await finishRobot(h);assert.equal(h.data.state.robot.summary.rejections,1);
});
test('reply robot: manual answer already in page history is not answered again',async()=>{
 const h=harness();h.inboxes.set('job:j1',[{id:'q',side:'in',text:'会哪些软件？'},{id:'manual',side:'out',text:'手动填写的真实软件说明'}]);await beginRobot(h,c=>{c.answers.skills='另外一份已确认工具话术';c.robot.sendResume=false;});await finishRobot(h);assert.equal(h.effects.filter(e=>e.kind==='reply').length,0);assert.equal(h.data.state.robot.summary.introductions,1);
});
test('reply robot: second complete run preserves successful intro/reply/resume dedup',async()=>{
 const h=harness();await beginRobot(h);await finishRobot(h);const before=structuredClone(h.counts);await h.req('START_REPLY',{consent:true});await finishRobot(h);assert.deepEqual(h.counts,before);assert.equal(h.data.state.robot.summary.introductions,0);assert.equal(h.data.state.robot.summary.resumes,0);
});
test('reply robot: lost send response recovers exact message and records success instead of skip',async()=>{
 const h=harness({lostSendKind:'intro'});await beginRobot(h,c=>{c.robot.sendResume=false;});await finishRobot(h);assert.equal(h.counts.text,1);assert.equal(h.data.state.robot.summary.introductions,1);assert.equal(h.data.state.robot.summary.uncertain,0);assert.equal(h.data.state.robot.summary.skipped,0);assert.ok(h.effects.some(e=>e.kind==='observe'));
});
test('reply robot: unconfirmed click is never replayed during same or later batch',async()=>{
 const h=harness({noTextReceipt:true});await beginRobot(h);await finishRobot(h);assert.equal(h.counts.text,1);assert.equal(h.data.state.robot.summary.uncertain,1);assert.equal(h.data.state.robot.summary.introductions,0);assert.equal(h.data.state.conversations['chat:j1'].uncertainWrite,true);
 await h.req('START_REPLY',{consent:true});await finishRobot(h);assert.equal(h.counts.text,1);
});
test('reply robot: read-only traversal has shadow history and never sends or suppresses later live sends',async()=>{
 const h=harness({jobCount:2});await beginRobot(h,()=>{},true);await finishRobot(h);assert.deepEqual(h.counts,{contact:0,text:0,resume:0});assert.deepEqual(h.data.state.conversations,{});assert.equal(h.data.state.robot.summary.introductions,2);assert.ok(h.effects.some(e=>e.kind==='openChat'));
 const report=await h.req('REPLY_REPORT');assert.match(report.mode,/只读回测/);assert.ok(!report.events.some(e=>'text' in e));
 await h.req('START_REPLY',{consent:true});await finishRobot(h);assert.equal(h.counts.text,2);assert.equal(h.counts.resume,2);
});
test('reply robot: new inbound after introduction replans before answering and keeps one intro',async()=>{
 let h;h=harness({afterWrite:({kind,jobKey})=>{if(kind==='intro')h.inboxes.get(jobKey).push({id:'new-question',side:'in',text:'会哪些软件？'});}});
 await beginRobot(h,c=>{c.robot.sendResume=false;c.answers.skills='确认的工具';});await finishRobot(h);assert.equal(h.effects.filter(e=>e.kind==='intro').length,1);assert.equal(h.effects.filter(e=>e.kind==='reply').length,1);assert.ok(h.data.state.robot.trace.some(e=>e.event==='replan'));
});
test('reply robot: wrong active chat after clicking never sends to the wrong recipient',async()=>{
 const h=harness({jobCount:2,openFails:true});await beginRobot(h,c=>{c.robot.sendResume=false;});await finishRobot(h);assert.equal(h.data.state.robot.summary.introductions,1);assert.ok(!h.effects.some(e=>e.kind==='intro'&&e.job==='job:j2'));assert.ok(h.data.state.robot.trace.some(e=>e.event==='skipped'));
});
test('reply robot: empty answer remains manual, introduction still sent, diagnostic shows missing key',async()=>{
 const h=harness();h.inboxes.set('job:j1',[{id:'salary',side:'in',text:'期望薪资多少？'}]);await beginRobot(h);await finishRobot(h);assert.equal(h.counts.text,1);assert.equal(h.counts.resume,0);assert.equal(h.data.state.conversations['chat:j1'].status,'manual');const d=await h.req('REPLY_REPORT');assert.ok(d.events.some(e=>e.missing?.includes('salary')));assert.ok(!JSON.stringify(d).includes('期望薪资多少'));
});
test('reply robot: stays listening to selected conversations after both rounds',async()=>{
 const h=harness();await beginRobot(h,c=>{c.robot.keepListening=true;c.robot.sendResume=false;c.answers.skills='确认的工具';});
 for(let i=0;i<120&&h.data.state.task?.phase!=='robot_watch';i++)await h.pulse();assert.equal(h.data.state.status,'running');
 h.inboxes.get('job:j1').push({id:'late',side:'in',text:'会哪些软件？'});await h.notify();for(let i=0;i<80&&!h.data.state.robot.summary.replies;i++)await h.pulse();
 assert.equal(h.data.state.robot.summary.replies,1);assert.equal(h.data.state.robot.summary.introductions,1);await h.req('PAUSE');
});
test('reply robot: starting while outreach is active switches one worker without new contact',async()=>{
 const h=harness();await h.initialize();await h.req('START',{tabId:1,mode:'live',consent:true});h.data.config.robot.keepListening=false;await h.req('START_REPLY',{consent:true});await finishRobot(h);assert.equal(h.data.state.workflow,'reply');assert.equal(h.counts.contact,0);
});
test('reply robot: continuously changing history is bounded and eventually moves on',async()=>{
 const h=harness({beforeSnapshot:({messages})=>messages.push({id:'q'+messages.length,side:'in',text:'你好'})});await beginRobot(h);await finishRobot(h);assert.equal(h.counts.text,0);assert.match(Object.values(h.data.state.robot.failed)[0],/消息持续变化/);
});
test('worker: preview cannot send',async()=>{const h=harness();await h.initialize();await h.req('START',{tabId:1,mode:'preview'});for(let i=0;i<5;i++)await h.pulse();assert.equal(h.data.state.stats.preview,1,JSON.stringify(h.data.state));assert.deepEqual(h.counts,{contact:0,text:0,resume:0});});
test('worker: optional continuing listener preserves binding and sends configured resume',async()=>{const h=harness();await h.initialize();h.data.config.settings.keepListeningAfterBatch=true;await h.req('START',{tabId:1,mode:'live',consent:true});for(let i=0;i<35&&(!h.data.state.liveVerified||!h.counts.resume);i++)await h.pulse();assert.equal(h.data.state.status,'running',h.data.state.reason);assert.equal(h.data.state.liveVerified,1);assert.equal(h.counts.contact,1);assert.equal(h.counts.resume,1);assert.equal(h.counts.text,1);const conv=Object.values(h.data.state.conversations)[0];assert.equal(conv.profile.name,'创作方向');assert.equal(conv.resume.name,'研究简历.pdf');});
test('worker: real send requires explicit consent',async()=>{const h=harness();await h.initialize();await assert.rejects(h.req('START',{tabId:1,mode:'live',consent:false}),/授权/);assert.equal(h.counts.contact,0);});
for(const limit of [10,50,100,237,300])test('worker: first batch accepts '+limit,async()=>{const h=harness();await h.initialize();h.data.config.settings.batchLimit=limit;await h.req('START',{tabId:1,mode:'live',consent:true});assert.equal(h.data.state.status,'running');await h.req('PAUSE');});
test('worker: content cannot start or read private config',async()=>{const h=harness();await h.initialize();const sender={id:'test',url:'https://www.zhipin.com/',tab:{id:1}};await assert.rejects(h.req('GET',{},sender),/仅扩展/);await assert.rejects(h.req('START',{mode:'live',consent:true},sender),/仅扩展/);});
test('worker: stale operation token is denied',async()=>{const h=harness();await h.initialize();const a=await h.req('ALLOW',{runId:'invalid',epoch:1,opId:'invalid'},{id:'test',url:'https://www.zhipin.com/',tab:{id:1}});assert.equal(a.allowed,false);});
test('worker: Pause prevents further queued side effects',async()=>{const h=harness();await h.initialize();await h.req('START',{tabId:1,mode:'live',consent:true});await h.req('PAUSE');for(let i=0;i<5;i++)await h.pulse();assert.equal(h.data.state.status,'paused');assert.equal(h.counts.contact,0);});
test('worker: legacy pending result is observed then marked uncertain automatically',async()=>{const h=harness();await h.initialize();h.data.state.status='running';h.data.state.mode='live';h.data.state.jobTabId=1;h.data.state.pending={id:'unknown',tabId:1,kind:'initiate',payload:{key:'job:old'}};h.data.state.task={phase:'initiate',profileId:h.data.config.profiles[0].id,job:{key:'job:old',title:'旧岗位',company:'旧公司'}};for(let i=0;i<4;i++)await h.pulse();assert.equal(h.data.state.status,'running',h.data.state.reason);assert.equal(h.data.state.pending,null);assert.equal(h.counts.contact,0);assert.equal(h.data.state.seenJobs['job:old'].status,'needs-attention');assert.equal(h.data.state.stats.skipped,0);await h.req('PAUSE');});
test('worker: abandoning uncertain effect retains dedup',async()=>{const h=harness();await h.initialize();h.data.state.pending={id:'unknown'};h.data.state.task={job:{key:'job:uncertain'},profileId:'p1'};await h.req('ABANDON_PENDING');assert.equal(h.data.state.seenJobs['job:uncertain'].status,'uncertain-do-not-retry');assert.equal(h.data.state.pending,null);});
test('worker: changing config during execution denied',async()=>{const h=harness();await h.initialize();h.data.state.status='running';await assert.rejects(h.req('SAVE',{config:{}}),/暂停/);});

for(const newTab of [false,true])test('worker: five jobs return before attachment; newTab='+newTab,async()=>{
 const h=harness({jobCount:5,newTab});await h.initialize();h.data.config.settings.batchLimit=5;
 await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<160&&h.data.state.liveVerified<5;i++)await h.pulse();
 assert.equal(h.data.state.status,'running',h.data.state.reason);
 assert.equal(h.data.state.liveVerified,5,JSON.stringify(h.data.state.task));
 assert.equal(h.counts.contact,5);assert.equal(h.counts.text,5);
 assert.equal(h.data.state.stats.introductions,5);
 assert.equal(new Set(h.effects.filter(e=>e.kind==='contact').map(e=>e.job)).size,5);
 assert.ok(h.tabs.get(1).url.includes('/job'));assert.ok(h.tabs.size<=2,'Only one monitoring tab should remain');
 for(const e of h.effects.filter(e=>e.kind==='intro')){
  const index=h.effects.indexOf(e),tail=h.effects.slice(index+1);
  assert.ok(tail.findIndex(x=>x.kind==='return')>=0);
  const attachment=tail.findIndex(x=>x.kind==='resume'&&x.job===e.job);
  if(attachment>=0)assert.ok(tail.findIndex(x=>x.kind==='return')<attachment);
 }
 await h.req('PAUSE');
});
async function seedManaged(h,count=1){
 await h.initialize();const s=h.data.state,c=h.data.config,p=c.profiles[0];
 Object.assign(s,{status:'running',mode:'live',runId:'queue-test',epoch:5,jobTabId:1,chatTabId:2,monitorTabId:2,openedTabs:[2]});
 h.tabs.set(2,{id:2,url:'https://www.zhipin.com/web/geek/chat',jobKey:h.jobs[0].key});
 c.settings.sendResume=false;c.settings.pauseAtReplies=20;c.answers.skills='会使用已确认的软件。';c.answers.status='目前正在找工作。';
 for(const j of h.jobs.slice(0,count)){
  const key=j.key.replace('job:','chat:');s.seenJobs[j.key]={status:'complete'};
  s.conversations[key]={key,job:j,profileId:p.id,profile:structuredClone(p),resume:structuredClone(c.attachments[0]),status:'waiting',seenInbound:['hello'],answered:[],lastOutboundAt:h.now(),resumeStatus:'none',introVerified:true};
 }
 await h.notify();h.data.state.replyQueue=[];
}
test('worker queue: three reply conversations then one complete first-contact task',async()=>{
 const h=harness({jobCount:5});await seedManaged(h,4);
 for(const j of h.jobs.slice(0,4)){
  h.inboxes.get(j.key).push({id:'q-'+j.key,side:'in',text:'会哪些软件？'});
  h.context.SBLCore.enqueue(h.data.state,j.key.replace('job:','chat:'),'message',h.now()-10000);
 }
 for(let i=0;i<65&&!h.effects.some(e=>e.kind==='intro');i++)await h.pulse();
 const sent=h.effects.filter(e=>['reply','contact','intro'].includes(e.kind));
 assert.deepEqual(sent.map(x=>x.kind),['reply','reply','reply','contact','intro']);
 assert.equal(sent.at(-1).job,'job:j5');await h.req('PAUSE');
});
test('worker queue: observer only enqueues while another recipient is being introduced',async()=>{
 let h;const options={jobCount:2,beforeAction:async({kind,jobKey})=>{
  if(kind!=='intro')return;
  h.inboxes.get('job:j1').push({id:'new-question',side:'in',text:'会哪些软件？'});
  const before=h.data.state.task.chatKey;await h.notify();
  assert.equal(h.data.state.task.chatKey,before);assert.equal(jobKey,'job:j2');
  assert.equal(h.effects.filter(e=>e.kind==='reply').length,0);
 }};
 h=harness(options);await seedManaged(h,1);h.data.config.settings.keepListeningAfterBatch=true;
 for(let i=0;i<60&&!h.effects.some(e=>e.kind==='reply');i++)await h.pulse();
 const sent=h.effects.filter(e=>['intro','reply'].includes(e.kind));
 assert.deepEqual(sent.map(x=>[x.kind,x.job]),[['intro','job:j2'],['reply','job:j1']]);await h.req('PAUSE');
});
test('worker queue: consecutive questions produce one merged approved reply',async()=>{
 const h=harness();await seedManaged(h);h.data.state.stopNew=true;
 h.inboxes.get('job:j1').push({id:'skills',side:'in',text:'会哪些软件？'});await h.notify();
 h.inboxes.get('job:j1').push({id:'status',side:'in',text:'还在找工作吗？'});await h.notify();
 assert.equal(h.data.state.replyQueue.length,1);assert.equal(h.counts.text,0);
 for(let i=0;i<20&&!h.data.state.stats.replies;i++)await h.pulse();
 const reply=h.effects.find(e=>e.kind==='reply');assert.ok(reply);assert.match(reply.text,/已确认的软件/);assert.match(reply.text,/正在找工作/);
 assert.equal(h.data.state.stats.replies,1);await h.req('PAUSE');
});
test('worker queue: unchanged managed conversations are not repeatedly opened',async()=>{
 const h=harness({jobCount:3});await seedManaged(h,3);h.data.state.stopNew=true;
 for(let i=0;i<20;i++)await h.pulse();
 const before=h.effects.filter(e=>e.kind==='openChat').length;
 for(let i=0;i<30;i++)await h.pulse();
 assert.equal(h.effects.filter(e=>e.kind==='openChat').length,before);assert.equal(h.counts.text,0);assert.equal(h.data.state.status,'running');await h.req('PAUSE');
});
test('worker queue: messages after a confirmed but lost reply response are not answered twice',async()=>{
 let h,once=false;h=harness({lostSendKind:'reply',afterWrite:async({kind})=>{
  if(kind==='reply'&&!once){once=true;h.inboxes.get('job:j1').push({id:'status-new',side:'in',text:'还在找工作吗？'});await h.notify();}
 }});
 await seedManaged(h);h.data.state.stopNew=true;h.inboxes.get('job:j1').push({id:'skills',side:'in',text:'会哪些软件？'});await h.notify();
 for(let i=0;i<45&&h.data.state.stats.replies<2;i++)await h.pulse();
 const replies=h.effects.filter(e=>e.kind==='reply');assert.equal(replies.length,2,JSON.stringify(h.data.state));
 assert.equal(replies[0].text,h.data.config.answers.skills);assert.equal(replies[1].text,h.data.config.answers.status);assert.equal(h.data.state.stats.replies,2);await h.req('PAUSE');
});
test('worker queue: Stop New finishes the active task then keeps replies running',async()=>{
 const h=harness({jobCount:3});await h.initialize();h.data.config.settings.batchLimit=3;h.data.config.settings.sendResume=false;
 await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<10&&!h.data.state.task?.job;i++)await h.pulse();await h.req('STOP_NEW');
 for(let i=0;i<40;i++)await h.pulse();
 assert.equal(h.counts.contact,1);assert.equal(h.counts.text,1);assert.equal(h.data.state.status,'running');assert.equal(h.data.state.stopNew,true);await h.req('PAUSE');
});
test('worker queue: events from unbound tabs or obsolete scripts cannot enqueue',async()=>{
 const h=harness();await seedManaged(h);const m={activity:{rows:[{key:'chat:j1',token:'new',unread:true}]},version:'0.1.5'};
 const r=await h.req('CHAT_ACTIVITY',m,{id:'test',url:'https://www.zhipin.com/web/geek/chat',tab:{id:99}});assert.equal(r.accepted,false);
 const old=await h.req('CHAT_ACTIVITY',{...m,version:'0.1.4'},{id:'test',url:h.tabs.get(2).url,tab:{id:2}});assert.equal(old.accepted,false);
 assert.equal(h.data.state.replyQueue.length,0);await h.req('PAUSE');
});
test('worker: restore 1.4 direct Continue, even when optional link probe would fail',async()=>{
 const h=harness({jobCount:2,publicChatUrl:true,probeFails:true});await h.initialize();h.data.config.settings.batchLimit=2;
 await h.req('START',{tabId:1,mode:'live',consent:true});for(let i=0;i<70&&h.data.state.liveVerified<2;i++)await h.pulse();
 assert.equal(h.data.state.liveVerified,2,h.data.state.reason);assert.equal(h.tabs.size,2);
 assert.equal(h.effects.filter(e=>e.kind==='probe').length,0);assert.equal(h.effects.filter(e=>e.kind==='continue').length,2);assert.match(h.tabs.get(1).url,/\/jobs(?:\?|$)/);await h.req('PAUSE');
});
test('worker queue: unavailable history alone triggers the explicit jobs URL fallback',async()=>{
 const h=harness({noHistory:true});await h.initialize();await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<35&&!h.data.state.liveVerified;i++)await h.pulse();
 assert.equal(h.data.state.liveVerified,1);assert.equal(h.effects.filter(e=>e.id===1&&e.hard).length,1);await h.req('PAUSE');
});
test('worker queue: introduction does not wait for an HR question to have a prepared answer',async()=>{
 const h=harness();await h.initialize();h.data.config.settings.keepListeningAfterBatch=true;h.inboxes.set('job:j1',[{id:'unknown',side:'in',text:'请解释一个尚未准备的专业问题？'}]);
 await h.req('START',{tabId:1,mode:'live',consent:true});for(let i=0;i<35;i++)await h.pulse();
 assert.equal(h.data.state.stats.introductions,1);assert.equal(h.data.state.stats.replies,0);assert.equal(h.data.state.conversations['chat:j1'].status,'manual');await h.req('PAUSE');
});
test('worker queue: a failed attachment cannot erase the confirmed introduction',async()=>{
 const h=harness();await h.initialize();await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<25&&!h.data.state.liveVerified;i++)await h.pulse();
 h.data.state.task={phase:'monitor_read',job:h.jobs[0],chatKey:'chat:j1',profileId:h.data.config.profiles[0].id};
 await vm.runInContext("(async()=>skipTask((await read()).state,'附件未能定位'))()",h.context);
 assert.equal(h.data.state.seenJobs['job:j1'].status,'complete');assert.equal(h.data.state.stats.introductions,1);assert.equal(h.data.state.stats.skipped,0);await h.req('PAUSE');
});
test('worker queue: waiting for resume acceptance releases the writer and never repeats the request',async()=>{
 const h=harness({jobCount:2,resumeWaiting:true});await h.initialize();h.data.config.settings.batchLimit=2;
 await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<80&&h.data.state.liveVerified<2;i++)await h.pulse();
 assert.equal(h.data.state.liveVerified,2,h.data.state.reason);assert.equal(h.data.state.conversations['chat:j1'].resumeStatus,'waiting');
 const before=h.effects.filter(x=>x.kind==='resume'&&x.job==='job:j1').length;
 h.inboxes.get('job:j1').push({id:'ask-again',side:'in',text:'请发一份简历'});await h.notify();
 for(let i=0;i<20;i++)await h.pulse();
 assert.equal(h.effects.filter(x=>x.kind==='resume'&&x.job==='job:j1').length,before);assert.equal(h.data.state.stats.resumes,0);await h.req('PAUSE');
});
test('worker queue: a read-only check has no extra two-second send cooldown',async()=>{
 const h=harness();await seedManaged(h);h.data.state.stopNew=true;h.context.SBLCore.enqueue(h.data.state,'chat:j1','check',h.now());
 for(let i=0;i<12&&(h.data.state.replyQueue.length||h.data.state.task);i++)await h.pulse();
 assert.equal(h.data.state.task,null);assert.equal(h.data.state.nextTaskAt,0);assert.equal(h.counts.text,0);await h.req('PAUSE');
});
test('worker queue: pause between preparation and checkpoint prevents text submission',async()=>{
 let h;h=harness({beforeAction:async({kind})=>{if(kind==='intro')await h.req('PAUSE');}});await h.initialize();
 await h.req('START',{tabId:1,mode:'live',consent:true});for(let i=0;i<20&&h.data.state.status==='running';i++)await h.pulse();
 assert.equal(h.data.state.status,'paused');assert.equal(h.counts.contact,1);assert.equal(h.counts.text,0);
});
test('worker queue: frozen background pages report a blocker instead of silently stalling',async()=>{
 const h=harness();await seedManaged(h);h.data.state.stopNew=true;h.data.state.activityAt=0;h.tabs.get(2).frozen=true;
 await h.pulse();assert.equal(h.data.state.status,'blocked');assert.match(h.data.state.reason,/浏览器休眠/);assert.equal(h.counts.text,0);
});
test('worker queue: continuous inbound bursts release the writer for other work',async()=>{
 const h=harness({jobCount:2});await seedManaged(h,2);h.data.state.stopNew=true;
 h.data.state.task={phase:'monitor_read',chatKey:'chat:j1',job:h.jobs[0],profileId:h.data.config.profiles[0].id,queueRevision:1,inboundToken:'old',settleStarted:h.now()-4000};
 h.context.SBLCore.enqueue(h.data.state,'chat:j1','message',h.now()-4000);
 h.inboxes.get('job:j1').push({id:'still-typing',side:'in',text:'会哪些软件？'});
 await h.pulse();assert.equal(h.data.state.task,null);assert.equal(h.counts.text,0);assert.ok(h.data.state.replyQueue.some(x=>x.chatKey==='chat:j1'));await h.req('PAUSE');
});
test('worker: Continue unload does not block or cause a repeated click',async()=>{
 const h=harness({lostNavReply:true});await h.initialize();await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<30&&!h.data.state.liveVerified;i++)await h.pulse();
 assert.equal(h.data.state.liveVerified,1,h.data.state.reason);assert.equal(h.effects.filter(e=>e.kind==='continue').length,1);await h.req('PAUSE');
});
test('worker: a lost text-send response never resends the message',async()=>{
 const h=harness({lostSendReply:true});await h.initialize();await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<25;i++)await h.pulse();
 assert.equal(h.counts.text,1);assert.equal(h.data.state.status,'paused',h.data.state.reason);assert.equal(h.data.state.pending,null);assert.equal(h.data.state.liveVerified,1);await h.req('PAUSE');
});

test('worker: two failures before clicking recover automatically',async()=>{
 const h=harness({preclickFailures:2});await h.initialize();await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<55&&!h.data.state.liveVerified;i++)await h.pulse();
 assert.equal(h.data.state.liveVerified,1,h.data.state.reason);assert.equal(h.counts.contact,1);assert.equal(h.counts.text,1);assert.equal(h.data.state.stats.retries,2);assert.equal(h.data.state.pending,null);await h.req('PAUSE');
});
test('worker: one unadapted job is skipped without stopping the following job',async()=>{
 const h=harness({jobCount:2,preclickFailures:100,failJob:'job:j1'});await h.initialize();h.data.config.settings.batchLimit=2;await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<60&&!h.data.state.liveVerified;i++)await h.pulse();
 assert.equal(h.data.state.liveVerified,1,h.data.state.reason);assert.equal(h.counts.contact,1);assert.equal(h.data.state.seenJobs['job:j1'].status,'skipped');assert.equal(h.data.state.stats.skipped,1);assert.equal(h.data.state.stats.introductions,1);await h.req('PAUSE');
});
test('worker: lost contact response is recovered without double clicking',async()=>{
 const h=harness({lostInitiateReply:true});await h.initialize();await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<45&&!h.data.state.liveVerified;i++)await h.pulse();
 assert.equal(h.data.state.liveVerified,1,h.data.state.reason);assert.equal(h.counts.contact,1);assert.equal(h.data.state.stats.contacts,1);assert.equal(h.counts.text,1);await h.req('PAUSE');
});
test('worker: missing receipt preserves contact and marks attention, never successful introduction',async()=>{
 const h=harness({noTextReceipt:true});await h.initialize();await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<40;i++)await h.pulse();
 assert.equal(h.data.state.status,'paused',h.data.state.reason);assert.equal(h.data.state.pauseKind,'completed');assert.equal(h.counts.text,1);assert.equal(h.data.state.stats.introductions,0);assert.equal(h.data.state.stats.contacts,1);assert.equal(h.data.state.liveVerified,0);assert.equal(h.data.state.completedCycles,1);assert.equal(h.data.state.stats.skipped,0);assert.equal(h.data.state.stats.attention,1);assert.equal(h.data.state.pending,null);assert.match(h.tabs.get(1).url,/\/jobs(?:\?|$)/);assert.ok(h.effects.some(x=>x.kind==='return'&&x.method==='history'));assert.equal(h.data.state.conversations['chat:j1'].uncertainWrite,true);await h.req('PAUSE');
});
test('worker: platform verification stops without retrying clicks',async()=>{
 const h=harness({blockedBefore:true});await h.initialize();await h.req('START',{tabId:1,mode:'live',consent:true});
 for(let i=0;i<15;i++)await h.pulse();
 assert.equal(h.data.state.status,'blocked');assert.match(h.data.state.reason,/平台验证/);assert.equal(h.data.state.pending,null);assert.equal(h.counts.contact,0);assert.equal(h.data.state.stats.retries,0);
});
test('worker: old pending does not require manual confirmation before a new batch',async()=>{
 const h=harness();await h.initialize();h.data.state.status='blocked';h.data.state.pending={id:'legacy'};h.data.state.task={job:{key:'job:old'},profileId:'old'};
 await h.req('SAVE',{config:h.data.config});await h.req('START',{tabId:1,mode:'live',consent:true});
 assert.equal(h.data.state.status,'running');assert.equal(h.data.state.seenJobs['job:old'].status,'interrupted-do-not-retry');await h.req('PAUSE');
});
test('worker: checkpoint refuses stale or duplicate operation tokens',async()=>{
 const h=harness();await h.initialize();h.data.state.status='running';h.data.state.mode='live';h.data.state.runId='r';h.data.state.epoch=3;h.data.state.pending={id:'op',tabId:1,stage:'preparing'};
 const sender={id:'test',url:'https://www.zhipin.com/',tab:{id:1}},m={runId:'r',epoch:3,opId:'op'};
 await assert.rejects(h.req('ACTION_STAGE',{...m,epoch:2},sender),/暂停|授权/);
 await h.req('ACTION_STAGE',m,sender);assert.equal(h.data.state.pending.stage,'dispatched');
 await assert.rejects(h.req('ACTION_STAGE',m,sender),/重复/);await h.req('PAUSE');
});
test('worker: upgrade retries only known unsent title failures and preserves sent/unknown jobs',async()=>{
 const h=harness();await h.initialize();const s=h.data.state;s.version='0.1.3';
 const failure={status:'skipped',reason:'未点击发送；重试两次仍失败：未点击：详情标题未匹配所选职位'};
 s.seenJobs={'job:unsent':{...failure},'job:with-conversation':{...failure},'job:unknown':{status:'skipped',reason:'回执未确认'},'job:sent':{status:'complete'}};
 s.conversations.known={job:{key:'job:with-conversation'}};
 await vm.runInContext('setup()',h.context);
 assert.equal(h.data.state.seenJobs['job:unsent'],undefined);
 for(const key of ['job:with-conversation','job:unknown','job:sent'])assert.ok(h.data.state.seenJobs[key]);
 assert.equal(h.data.state.version,h.context.SBLCore.VERSION);
});

// v0.1.10: simulated clocks + Chrome API/DOM doubles. No real account traffic.
async function endOutreach(h,max=240){for(let i=0;i<max&&h.data.state.status==='running';i++)await h.pulse();assert.equal(h.data.state.status,'paused',h.data.state.reason);}
test('v10: an unknown intro receipt returns to jobs and the next job sends exactly once',async()=>{
 const h=harness({jobCount:3,noTextReceiptJob:'job:j1'});await h.initialize();h.data.config.settings.batchLimit=3;await h.req('START',{mode:'live',consent:true});await endOutreach(h);
 assert.equal(h.counts.contact,3);assert.equal(h.counts.text,3);assert.equal(h.data.state.completedCycles,3);assert.equal(h.data.state.liveVerified,2);assert.equal(h.data.state.pending,null);assert.equal(Object.keys(h.data.state.unconfirmedOps).length,1);assert.equal(h.data.state.conversations['chat:j1'].uncertainWrite,true);assert.match(h.tabs.get(1).url,/\/jobs(?:\?|$)/);
 const a=h.effects.findIndex(x=>x.kind==='intro'&&x.job==='job:j1'),b=h.effects.findIndex(x=>x.kind==='contact'&&x.job==='job:j2');assert.ok(h.effects.slice(a+1,b).some(x=>x.kind==='return'));
});
test('v10: all receipts unknown still stop at the requested cycle count, not extra applications',async()=>{
 const h=harness({jobCount:10,noTextReceipt:true});await h.initialize();h.data.config.settings.batchLimit=2;await h.req('START',{mode:'live',consent:true});await endOutreach(h);
 assert.equal(h.counts.text,2);assert.equal(h.counts.contact,2);assert.equal(h.data.state.completedCycles,2);assert.equal(h.data.state.liveVerified,0);assert.equal(h.data.state.stats.attention,2);
 for(let i=0;i<12;i++)await h.pulse();assert.equal(h.counts.contact,2);
});
test('v10: an intro that cannot be clicked after bounded retries skips to the next job',async()=>{
 const h=harness({jobCount:2,textPreclickFailures:100,textFailJob:'job:j1'});await h.initialize();h.data.config.settings.batchLimit=2;await h.req('START',{mode:'live',consent:true});await endOutreach(h);
 assert.equal(h.counts.contact,2);assert.equal(h.counts.text,1);assert.equal(h.data.state.completedCycles,2);assert.equal(h.data.state.liveVerified,1);assert.equal(h.data.state.stats.retries,2);
});
test('v10: explicit single-message failure does not halt the entire batch or resend',async()=>{
 const h=harness({jobCount:2,explicitFailJob:'job:j1'});await h.initialize();h.data.config.settings.batchLimit=2;await h.req('START',{mode:'live',consent:true});await endOutreach(h);
 assert.equal(h.counts.text,2);assert.equal(h.data.state.completedCycles,2);assert.equal(h.data.state.liveVerified,1);assert.equal(h.data.state.stats.attention,1);
});
test('v10: late receipts only reconcile the original operation; no navigation or duplicate counts',async()=>{
 const h=harness({jobCount:2,noTextReceiptJob:'job:j1'});await h.initialize();h.data.config.settings.batchLimit=2;await h.req('START',{mode:'live',consent:true});
 for(let i=0;i<90&&h.data.state.completedCycles<1;i++)await h.pulse();assert.equal(h.data.state.completedCycles,1);
 const op=Object.values(h.data.state.unconfirmedOps)[0],before=JSON.stringify(h.data.state.task),effects=h.effects.length;
 const sender={id:'test',url:h.tabs.get(op.tabId).url,tab:{id:op.tabId}},m={opId:op.id,runId:op.runId,kind:op.kind,result:{verified:true}};
 assert.equal((await h.req('ACTION_RESULT',{...m,runId:'wrong'},sender)).accepted,false);
 assert.equal((await h.req('ACTION_RESULT',m,sender)).accepted,true);assert.equal((await h.req('ACTION_RESULT',m,sender)).accepted,false);
 assert.equal(JSON.stringify(h.data.state.task),before);assert.equal(h.effects.length,effects);assert.equal(h.data.state.seenJobs['job:j1'].introVerified,true);assert.equal(h.data.state.conversations['chat:j1'].uncertainWrite,false);assert.equal(h.data.state.liveVerified,1);assert.equal(h.counts.text,1);
 await endOutreach(h);assert.equal(h.data.state.liveVerified,2);assert.equal(h.counts.text,2);
});
test('v10: Resume of an older blocked intro uses observation and completes the return path',async()=>{
 const h=harness({noTextReceipt:true});await h.initialize();await h.req('START',{mode:'live',consent:true});
 for(let i=0;i<60&&!h.data.state.pending;i++)await h.pulse();
 // Advance to a dispatched introduction rather than an initiation.
 for(let i=0;i<60&&h.data.state.pending?.kind!=='intro';i++)await h.pulse();assert.equal(h.data.state.pending.kind,'intro');
 await h.req('PAUSE');h.data.state.status='blocked';h.data.state.version='0.1.9';h.data.state.reason='自我介绍尚未确认发出';
 await h.req('RESUME',{consent:true});await endOutreach(h);assert.equal(h.counts.text,1);assert.equal(h.data.state.completedCycles,1);assert.equal(h.data.state.pending,null);assert.match(h.tabs.get(1).url,/\/jobs(?:\?|$)/);
});
test('v10: fifth-step journal is rechecked read-only when the sixth step opens that chat',async()=>{
 const h=harness({noTextReceipt:true});await h.initialize();await h.req('START',{mode:'live',consent:true});await endOutreach(h);
 h.inboxes.get('job:j1').push({id:'late-native-id',stableId:true,side:'out',text:'真实项目介绍'});h.data.config.robot.keepListening=false;h.data.config.robot.sendResume=false;
 await h.req('START_REPLY',{consent:true});await finishRobot(h);assert.equal(h.counts.text,1);assert.equal(h.data.state.conversations['chat:j1'].uncertainWrite,false);assert.equal(Object.values(h.data.state.unconfirmedOps)[0].status,'verified-late');
});
test('v10 idle: merely leaving the bot running for two hours is insufficient when the computer is active',async()=>{
 const h=harness();await h.initialize();await h.req('START',{mode:'live',consent:true});await endOutreach(h);h.advance(7200001);await h.idleCheck();assert.notEqual(h.data.state.workflow,'reply');assert.equal(h.data.state.idleAutomation.requestedAt,0);
});
test('v10 idle: completed outreach remains authorized and hands over after two hours idle',async()=>{
 const h=harness();await h.initialize();await h.req('START',{mode:'live',consent:true});await endOutreach(h);const runId=h.data.state.runId;
 assert.equal(h.data.state.pauseKind,'completed');assert.equal(h.data.state.idleAutomation.armed,true);h.advance(7200001);h.setIdle('idle');await h.idleCheck();
 assert.equal(h.data.state.workflow,'reply');assert.equal(h.data.state.robot.onlyPending,true);assert.equal(h.data.state.robot.source,'idle');assert.equal(h.data.state.outreachCheckpoint.runId,runId);assert.equal(h.data.state.outreachCheckpoint.completedCycles,1);assert.equal(h.data.state.idleAutomation.armed,false);assert.equal(h.data.state.jobTabId,1);await h.req('PAUSE');
});
test('v10 idle: arm duration less than two hours never triggers, even if native idle reports idle',async()=>{
 const h=harness();await h.initialize();await h.req('START',{mode:'live',consent:true});await endOutreach(h);h.data.state.idleAutomation.lastHumanAt=h.now();h.advance(7198000);h.setIdle('idle');await h.idleCheck();assert.notEqual(h.data.state.workflow,'reply');
 h.advance(3000);await h.idleCheck();assert.equal(h.data.state.workflow,'reply');await h.req('PAUSE');
});
test('v10 idle: an in-flight introduction finishes observation and return before switching',async()=>{
 const h=harness({jobCount:3,noTextReceiptJob:'job:j1'});await h.initialize();h.data.config.settings.batchLimit=3;await h.req('START',{mode:'live',consent:true});
 for(let i=0;i<70&&h.data.state.pending?.kind!=='intro';i++)await h.pulse();assert.equal(h.data.state.pending.kind,'intro');h.advance(7200001);h.setIdle('idle');await h.idleCheck();assert.notEqual(h.data.state.workflow,'reply');assert.ok(h.data.state.idleAutomation.requestedAt);
 for(let i=0;i<80&&h.data.state.workflow!=='reply';i++)await h.pulse();assert.equal(h.data.state.workflow,'reply');assert.equal(h.data.state.outreachCheckpoint.completedCycles,1);assert.equal(h.counts.contact,1);assert.equal(h.data.state.pending,null);assert.match(h.tabs.get(1).url,/\/jobs(?:\?|$)/);await h.req('PAUSE');
});
for(const mode of ['pause','preview','disabled','blocker'])test('v10 idle: no surprise auto-restart after '+mode,async()=>{
 const h=harness({blockedBefore:mode==='blocker'});await h.initialize();if(mode==='disabled')h.data.config.settings.idleReplyEnabled=false;await h.req('START',{mode:mode==='preview'?'preview':'live',consent:true});
 if(mode==='pause')await h.req('PAUSE');else for(let i=0;i<90&&h.data.state.status==='running';i++)await h.pulse();h.advance(8000000);h.setIdle('idle');await h.idleCheck();assert.notEqual(h.data.state.workflow,'reply');assert.equal(h.data.state.idleAutomation.armed,false);
});
test('v10 idle: immediate screen lock is not two hours idle, sustained lock eventually qualifies',async()=>{
 const h=harness();await h.initialize();await h.req('START',{mode:'live',consent:true});await endOutreach(h);h.advance(7300000);h.setIdle('locked');await h.idleCheck();assert.notEqual(h.data.state.workflow,'reply');h.advance(7200001);await h.idleCheck();assert.equal(h.data.state.workflow,'reply');await h.req('PAUSE');
});
test('v10 idle: activity and pause signals differ; state GET and heartbeat do not reset the timer',async()=>{
 const h=harness();await h.initialize();await h.req('START',{mode:'live',consent:true});await endOutreach(h);const at=h.data.state.idleAutomation.lastHumanAt;h.advance(10000);await h.req('GET');await h.req('HEARTBEAT',{}, {id:'test',url:h.tabs.get(1).url,tab:{id:1}});assert.equal(h.data.state.idleAutomation.lastHumanAt,at);
 await h.req('HUMAN_ACTIVITY');assert.ok(h.data.state.idleAutomation.lastHumanAt>at);assert.equal(h.data.state.idleAutomation.armed,true);await h.req('PAUSE');assert.equal(h.data.state.idleAutomation.armed,false);
});
test('v10 idle: persisted clock survives normal service-worker re-instantiation',async()=>{
 const h=harness();await h.initialize();await h.req('START',{mode:'live',consent:true});await endOutreach(h);h.advance(7200001);h.setIdle('idle');const a=structuredClone(h.data.state.idleAutomation);
 const fresh=vm.createContext({chrome:h.context.chrome,console,structuredClone,crypto:webcrypto,URL,Date:h.context.Date,Math,setTimeout,clearTimeout});
 for(const name of ['core.js','robot.js','background.mjs'])vm.runInContext(fs.readFileSync(__dirname+'/../extension/'+name,'utf8').replace(/^import .*;$/gm,''),fresh);
 assert.deepEqual(h.data.state.idleAutomation,a);await vm.runInContext('checkIdleAutomation(true)',fresh);await vm.runInContext('tick()',fresh);assert.equal(h.data.state.workflow,'reply');await h.req('PAUSE');
});
test('v10 priority: scan later pages before picking an unread conversation, even with limit one',async()=>{
 const h=harness({jobCount:3,pageSize:1,rowProperties:{'job:j1':{lastSide:'out'},'job:j3':{unread:true}}});await beginRobot(h,c=>{c.robot.limit=1;c.robot.sendResume=false;},true);await finishRobot(h);
 assert.deepEqual(h.data.state.robot.order,['chat:j3']);assert.ok(h.data.state.robot.discoveryPages>=3);assert.equal(h.counts.text,0);
});
test('v10 priority: read-but-unanswered wins over already-replied conversations without an unread dot',async()=>{
 const h=harness({jobCount:3,pageSize:1,rowProperties:{'job:j1':{lastSide:'out'},'job:j2':{needsReply:true},'job:j3':{lastSide:'out'}}});await beginRobot(h,c=>{c.robot.limit=1;c.robot.sendResume=false;},true);await finishRobot(h);assert.deepEqual(h.data.state.robot.order,['chat:j2']);
});
test('v10 automatic reply: own-last-message conversations do not receive a new intro or proactive resume request',async()=>{
 const h=harness();await h.initialize();h.inboxes.get('job:j1').push({id:'manual-answer',side:'out',text:'我已经手动回复过了'});h.data.config.robot.keepListening=false;
 await h.req('START',{mode:'live',consent:true});await endOutreach(h);const before={...h.counts};h.advance(7200001);h.setIdle('idle');await h.idleCheck();await finishRobot(h);assert.equal(h.counts.text,before.text);assert.equal(h.counts.resume,before.resume);
});

test('v10 idle: saving the idle setting off explicitly disarms an already completed standby batch',async()=>{
 const h=harness();await h.initialize();await h.req('START',{mode:'live',consent:true});await endOutreach(h);assert.equal(h.data.state.idleAutomation.armed,true);const c=structuredClone(h.data.config);c.settings.idleReplyEnabled=false;await h.req('SAVE',{config:c});assert.equal(h.data.state.idleAutomation.armed,false);h.advance(7300000);h.setIdle('idle');await h.idleCheck();assert.notEqual(h.data.state.workflow,'reply');
});

for(const newTab of [false,true])test('v11 report: second job skipped after first success does not delete live monitor; ten bounded cycles, newTab='+newTab,async()=>{
 const h=harness({jobCount:12,newTab,preclickFailures:9,failJob:'job:j2'});await h.initialize();h.data.config.settings.batchLimit=10;h.data.config.settings.sendResume=false;h.data.config.settings.autoReply=false;
 await h.req('START',{mode:'live',consent:true});for(let i=0;i<500&&h.data.state.status==='running';i++)await h.pulse();
 assert.equal(h.data.state.status,'paused',h.data.state.reason);assert.equal(h.data.state.completedCycles,10);assert.equal(h.data.state.liveVerified,9);
 assert.equal(h.counts.contact,9);assert.equal(h.counts.text,9);assert.equal(h.data.state.seenJobs['job:j2'].status,'skipped');assert.equal(h.data.state.seenJobs['job:j11'],undefined);
 if(h.data.state.chatTabId)assert.ok(h.tabs.has(h.data.state.chatTabId));if(h.data.state.monitorTabId)assert.ok(h.tabs.has(h.data.state.monitorTabId));assert.ok(h.tabs.size<=2);
});
test('v11 report: stale optional chat binding is repaired at safe boundary without stopping outreach',async()=>{
 const h=harness({jobCount:5});await h.initialize();h.data.config.settings.batchLimit=4;h.data.config.settings.sendResume=false;
 await h.req('START',{mode:'live',consent:true});for(let i=0;i<100;i++){await h.pulse();if(h.data.state.completedCycles===1&&!h.data.state.task)break;}
 const dead=h.data.state.chatTabId;assert.ok(dead);h.tabs.delete(dead);
 for(let i=0;i<250&&h.data.state.status==='running';i++)await h.pulse();
 assert.equal(h.data.state.status,'paused',h.data.state.reason);assert.equal(h.data.state.liveVerified,4);assert.equal(h.counts.contact,4);assert.notEqual(h.data.state.chatTabId,dead);
});
test('v11 first-file policy: no imported or direction-bound resume is needed for requested resume execution',async()=>{
 const h=harness({jobCount:2});await h.initialize();h.data.config.settings.resumeSelection='first';h.data.config.attachments=[];h.data.config.profiles[0].resumeKey='';h.data.config.robot.keepListening=false;h.data.config.robot.limit=2;
 h.inboxes.set('job:j1',[{id:'req',side:'in',text:'我想要一份您的附件简历',resumeRequest:true}]);
 await h.req('START_REPLY',{consent:true});await finishRobot(h);
 assert.equal(h.counts.resume,2);assert.equal(h.data.state.robot.summary.resumes,2);assert.equal(h.effects.filter(e=>e.kind==='resumeConsent'||e.kind==='resumeOffer').length,0);
 assert.equal(h.effects.filter(e=>e.kind==='resume').length,2);
});
test('v11: resume substage survives journal persistence so opening is not confused with submit',async()=>{
 const h=harness();await h.initialize();await h.req('START',{mode:'live',consent:true});
 // Set a synthetic in-flight operation at the same authorization boundary as content.js.
 h.data.state.task={phase:'intro',chatKey:'chat:j1'};h.data.state.pending={id:'op-test',kind:'resume',tabId:1,stage:'preparing'};
 const s=h.data.state;
 const r=await h.req('ACTION_STAGE',{runId:s.runId,epoch:s.epoch,opId:'op-test',evidence:{resumeStage:'opening-picker',resumeSelection:'first'}},{id:'test',url:'https://www.zhipin.com/web/geek/chat',tab:{id:1}});
 assert.equal(r.allowed,true);assert.equal(h.data.state.pending.evidence.resumeStage,'opening-picker');assert.equal(h.data.state.pending.evidence.resumeSelection,'first');
 await h.req('ACTION_STAGE',{runId:s.runId,epoch:s.epoch,opId:'op-test',evidence:{resumeStage:'submit',resumeName:'第一份.pdf',resumeKey:'r:first'}},{id:'test',url:'https://www.zhipin.com/web/geek/chat',tab:{id:1}});
 assert.equal(h.data.state.pending.evidence.resumeStage,'submit');assert.equal(h.data.state.pending.evidence.resumeName,'第一份.pdf');
 await assert.rejects(h.req('ACTION_STAGE',{runId:s.runId,epoch:s.epoch,opId:'op-test',evidence:{resumeStage:'submit'}},{id:'test',url:'https://www.zhipin.com/web/geek/chat',tab:{id:1}}),/禁止重复点击/);
 await h.req('ACTION_STAGE',{runId:s.runId,epoch:s.epoch,opId:'op-test',evidence:{resumeStage:'confirm',resumeConfirmKey:'unique-confirm'}},{id:'test',url:'https://www.zhipin.com/web/geek/chat',tab:{id:1}});
 await assert.rejects(h.req('ACTION_STAGE',{runId:s.runId,epoch:s.epoch,opId:'op-test',evidence:{resumeStage:'confirm',resumeConfirmKey:'unique-confirm'}},{id:'test',url:'https://www.zhipin.com/web/geek/chat',tab:{id:1}}),/禁止重复点击/);
});

for(const stage of [null,'preparing'])test('v11 upgrade: unsubmitted stale resume plan is rebuilt using first-file policy, pending='+stage,async()=>{
 const h=harness();await h.initialize();delete h.data.config.settings.resumeSelection;
 Object.assign(h.data.state,{version:'0.1.10',workflow:'reply',status:'blocked',reason:'附件弹窗未关闭，请手动关闭后继续',task:{phase:'robot_execute',chatKey:'chat:j1',effectPayload:{kind:'resume',resume:undefined},effectCompleted:false},pending:stage?{id:'old-op',kind:'resume',stage}:null});
 h.data.state.conversations['chat:j1']={introSent:true,introVerified:true,resumeStatus:'selecting'};
 await vm.runInContext('setup()',h.context);
 assert.equal(h.data.config.settings.resumeSelection,'first');assert.equal(h.data.state.task.phase,'robot_read');assert.equal(h.data.state.task.effectPayload,null);assert.equal(h.data.state.pending,null);
 assert.equal(h.data.state.conversations['chat:j1'].introVerified,true);assert.equal(h.data.state.status,'blocked');assert.equal(h.counts.resume,0);assert.equal(h.counts.text,0);
});
test('v11 upgrade: already dispatched resume is preserved for observation, never turned into a new send',async()=>{
 const h=harness();await h.initialize();delete h.data.config.settings.resumeSelection;
 Object.assign(h.data.state,{version:'0.1.10',workflow:'reply',status:'blocked',task:{phase:'robot_execute',chatKey:'chat:j1',effectPayload:{kind:'resume',resume:{name:'原附件.pdf'}}},pending:{id:'old-op',kind:'resume',stage:'dispatched',evidence:{resumeStage:'submit'}}});
 const before=JSON.stringify({task:h.data.state.task,pending:h.data.state.pending});await vm.runInContext('setup()',h.context);
 assert.equal(JSON.stringify({task:h.data.state.task,pending:h.data.state.pending}),before);assert.equal(h.counts.resume,0);assert.equal(h.counts.text,0);
});

// v0.2 scenarios explicitly enable the new default. Legacy scenarios above opt out.
async function beginWatch(h,configure=()=>{}){await h.initialize();h.data.config.robot.keepListening=true;h.data.config.robot.sendResume=false;h.data.config.settings.sendResume=false;configure(h.data.config);await h.req('START_REPLY',{consent:true,continuous:true});}
async function spin(h,until,max=500){for(let i=0;i<max&&!until();i++){assert.equal(h.data.state.status,'running',h.data.state.reason);await h.pulse();}assert.ok(until(),'timed out '+JSON.stringify({task:h.data.state.task,reason:h.data.state.reason,summary:h.data.state.robot?.summary,queue:h.data.state.replyQueue}));}
async function pulses(h,n){for(let i=0;i<n;i++)await h.pulse();}
test('v02 open-jobs button creates official URL without any send, leaves resume page alone',async()=>{
 const h=harness();await h.initialize();h.tabs.get(1).url='https://www.zhipin.com/web/geek/resume';const r=await h.req('OPEN_JOBS');assert.equal(r.url,'https://www.zhipin.com/web/geek/jobs?ka=header-jobs');assert.equal(h.counts.contact+h.counts.text+h.counts.resume,0);assert.match(h.tabs.get(1).url,/resume$/);const second=await h.req('OPEN_JOBS');assert.equal(second.id,r.id);
});
test('v02 batch immediately hands off to sixth-step continuous watcher preserving outcome and no extra job',async()=>{
 const h=harness({jobCount:3,realActivity:true});await h.initialize();h.data.config.settings.autoReplyAfterBatch=true;h.data.config.settings.sendResume=false;h.data.config.robot.sendResume=false;
 await h.req('START',{consent:true,mode:'live'});await spin(h,()=>h.data.state.workflow==='reply');assert.equal(h.data.state.robot.source,'batch-complete');assert.equal(h.data.state.robot.continuous,true);assert.equal(h.data.state.completedCycles,1);assert.equal(h.data.state.liveVerified,1);assert.equal(h.data.state.stats.contacts,1);assert.ok(h.data.state.outreachCheckpoint.savedAt);assert.equal(h.data.state.idleAutomation.armed,false);await pulses(h,80);assert.equal(h.counts.contact,1);assert.equal(h.data.state.status,'running');await h.req('PAUSE');
});
test('v02 insufficient loaded jobs also enters watcher instead of waiting two hours',async()=>{
 const h=harness({realActivity:true});await h.initialize();h.data.config.settings.autoReplyAfterBatch=true;h.data.config.settings.batchLimit=3;h.data.config.settings.sendResume=false;await h.req('START',{consent:true,mode:'live'});await spin(h,()=>h.data.state.workflow==='reply');assert.match(h.data.state.outreachCheckpoint.reason,/未达目标/);assert.equal(h.counts.contact,1);await h.req('PAUSE');
});
test('v02 single failed job does not prevent completed-batch handoff',async()=>{
 const h=harness({preclickFailures:99,realActivity:true});await h.initialize();h.data.config.settings.autoReplyAfterBatch=true;await h.req('START',{consent:true,mode:'live'});await spin(h,()=>h.data.state.workflow==='reply');assert.equal(h.counts.contact,0);assert.equal(h.data.state.completedCycles,1);assert.equal(h.data.state.outreachCheckpoint.liveVerified,0);await h.req('PAUSE');
});
test('v02 continuous watcher traverses pages, opens blank right pane and ignores lifetime count=1',async()=>{
 const h=harness({jobCount:5,pageSize:2,blankUntilRowClick:true,realActivity:true});await beginWatch(h,c=>{c.robot.limit=1;});await spin(h,()=>h.data.state.robot.summary.introductions===5);assert.equal(new Set(h.effects.filter(x=>x.kind==='intro').map(x=>x.job)).size,5);assert.equal(h.counts.resume,0);assert.ok(h.effects.some(x=>x.kind==='conversations_more'));await pulses(h,30);assert.equal(h.counts.text,5);assert.equal(h.data.state.status,'running');await h.req('PAUSE');
});
test('v02 newly appearing contact is automatically replied to after the original list is processed',async()=>{
 const h=harness({realActivity:true});await beginWatch(h);await spin(h,()=>h.data.state.robot.summary.introductions===1&&h.data.state.task.phase==='robot_watch');h.jobs.push({key:'job:new',title:'测试新岗位',company:'新测试公司',summary:'测试'});h.inboxes.set('job:new',[{id:'new-msg',side:'in',text:'你好'}]);await h.notify();await spin(h,()=>h.effects.some(x=>x.kind==='intro'&&x.job==='job:new'));await pulses(h,30);assert.equal(h.counts.text,2);await h.req('PAUSE');
});
test('v02 active new HR question without unread badge is replied exactly once under repeated observer notifications',async()=>{
 const h=harness({realActivity:true});await beginWatch(h,c=>{c.answers.skills='已确认的工具清单';});await spin(h,()=>h.data.state.robot.summary.introductions===1&&h.data.state.task.phase==='robot_watch');h.inboxes.get('job:j1').push({id:'q-new',side:'in',text:'会哪些软件？'});for(let i=0;i<20;i++)await h.notify();await spin(h,()=>h.data.state.robot.summary.replies===1);await pulses(h,50);assert.equal(h.effects.filter(x=>x.kind==='reply').length,1);assert.equal(h.effects.find(x=>x.kind==='reply').text,'已确认的工具清单');await h.req('PAUSE');
});
test('v02 watcher reads own-last histories but never adds introductions or unsolicited attachments',async()=>{
 const h=harness({realActivity:true});h.inboxes.set('job:j1',[{id:'hr',side:'in',text:'你好'},{id:'manual',side:'out',text:'已经手动回复'}]);await beginWatch(h,c=>{c.robot.sendResume=true;});await spin(h,()=>h.data.state.robot.summary.processed>=1);await pulses(h,40);assert.equal(h.counts.text,0);assert.equal(h.counts.resume,0);await h.req('PAUSE');
});
test('v02 unread contact is selected ahead of older read-unanswered contact',async()=>{
 const h=harness({jobCount:3,realActivity:true,rowProperties:{'job:j3':{unread:true}}});await beginWatch(h);await spin(h,()=>h.effects.some(x=>x.kind==='openChat'));assert.equal(h.effects.find(x=>x.kind==='openChat').job,'job:j3');await h.req('PAUSE');
});
test('v02 missing salary fact stays manual but next conversation is handled',async()=>{
 const h=harness({jobCount:2,realActivity:true});h.inboxes.set('job:j1',[{id:'salary',side:'in',text:'期望薪资多少？'}]);await beginWatch(h);await spin(h,()=>h.data.state.robot.summary.processed>=2);assert.equal(h.data.state.conversations['chat:j1'].status,'manual');assert.equal(h.data.state.robot.summary.replies,0);assert.ok(h.effects.some(x=>x.kind==='intro'&&x.job==='job:j2'));await h.req('PAUSE');
});
test('v02 ambiguous apology gets no pressure, ordinary refusal one question and hard stop no send',async()=>{
 const h=harness({jobCount:3,realActivity:true});h.inboxes.set('job:j1',[{id:'apology',side:'in',text:'抱歉'}]);h.inboxes.set('job:j2',[{id:'soft',side:'in',text:'对不起，不符合要求'}]);h.inboxes.set('job:j3',[{id:'hard',side:'in',text:'不要再联系我'}]);await beginWatch(h);await spin(h,()=>h.data.state.robot.summary.processed>=3);await pulses(h,40);assert.equal(h.effects.filter(x=>x.kind==='rejection').length,1);assert.ok(!h.effects.some(x=>['intro','reply','rejection'].includes(x.kind)&&x.job!=='job:j2'));await h.req('PAUSE');
});
test('v02 watcher requests system-level keep-awake and prevents tab discard; pause releases both',async()=>{
 const h=harness({realActivity:true});await beginWatch(h);await spin(h,()=>h.data.state.robot.watch.lastCheckAt>0);const id=h.data.state.chatTabId;assert.equal(h.tabs.get(id).autoDiscardable,false);assert.ok(h.powerEvents.includes('system'));assert.ok(!h.powerEvents.includes('display'));await h.req('PAUSE');assert.equal(h.tabs.get(id).autoDiscardable,true);assert.equal(h.powerEvents.at(-1),'release');await pulses(h,12);assert.equal(h.data.state.status,'paused');
});
test('v02 honors disabled sleep prevention and preserves previously non-discardable tab setting',async()=>{
 const h=harness({realActivity:true});await h.initialize();h.tabs.get(1).url='https://www.zhipin.com/web/geek/chat';h.tabs.get(1).autoDiscardable=false;h.data.config.settings.keepAwake=false;await h.req('START_REPLY',{consent:true,continuous:true});await pulses(h,10);await h.req('PAUSE');assert.equal(h.tabs.get(1).autoDiscardable,false);assert.ok(!h.powerEvents.includes('system'));
});
test('v02 closed idle watch tab reconnects safely without replaying messages',async()=>{
 const h=harness({realActivity:true});await beginWatch(h);await spin(h,()=>h.data.state.robot.summary.introductions===1&&h.data.state.task.phase==='robot_watch');const old=h.data.state.chatTabId;h.tabs.delete(old);await pulses(h,2);assert.notEqual(h.data.state.chatTabId,old);await pulses(h,35);assert.equal(h.counts.text,1);assert.equal(h.data.state.status,'running');await h.req('PAUSE');
});
test('v02 discarded/frozen watch page is reactivated before reading',async()=>{
 const h=harness({realActivity:true});await beginWatch(h);await spin(h,()=>h.data.state.task.phase==='robot_watch');const tab=h.tabs.get(h.data.state.chatTabId);tab.frozen=true;tab.discarded=true;tab.active=false;await h.pulse();assert.equal(tab.active,true);assert.equal(tab.frozen,false);assert.match(h.data.state.logs[0].text,/冻结|卸载/);await h.req('PAUSE');
});
test('v02 login failure pauses instead of auto-reopening and bypassing login',async()=>{
 const options={realActivity:true},h=harness(options);await beginWatch(h);await spin(h,()=>h.data.state.task.phase==='robot_watch');const tab=h.tabs.get(h.data.state.chatTabId);tab.url='https://www.zhipin.com/web/user/?login';options.loggedIn=false;const size=h.tabs.size;await h.pulse();assert.equal(h.data.state.status,'blocked');assert.match(h.data.state.reason,/登录/);assert.equal(h.tabs.size,size);assert.equal(h.powerEvents.at(-1),'release');
});
test('v02 new continuous session still requires explicit user authorization',async()=>{const h=harness();await h.initialize();await assert.rejects(h.req('START_REPLY',{continuous:true}),/点击/);assert.equal(h.counts.text,0);});
test('v02 dry-run request cannot enable persistent sending',async()=>{const h=harness();await h.initialize();h.data.config.robot.sendResume=false;await h.req('START_REPLY',{continuous:true,dryRun:true});await finishRobot(h);assert.equal(h.data.state.robot.continuous,false);assert.equal(h.counts.text+h.counts.resume,0);});
test('v02 stop-new button transitions safely into continuous reply instead of old queue-only monitor',async()=>{
 const h=harness({realActivity:true});await h.initialize();h.data.config.settings.autoReplyAfterBatch=true;h.data.config.settings.sendResume=false;await h.req('START',{consent:true,mode:'live'});await h.req('STOP_NEW');await spin(h,()=>h.data.state.workflow==='reply');assert.equal(h.data.state.robot.continuous,true);await h.req('PAUSE');
});
test('v02 explicit pause and browser restart do not auto-rearm continuous sending',async()=>{
 const h=harness({realActivity:true});await beginWatch(h);await spin(h,()=>h.data.state.robot.summary.introductions===1);await h.events.startup();assert.equal(h.data.state.status,'paused');const n=h.counts.text;await pulses(h,15);assert.equal(h.counts.text,n);assert.equal(h.data.state.status,'paused');assert.equal(h.powerEvents.at(-1),'release');
});
test('v02 a closed tab with a pending external operation stops rather than transferring the write to another tab',async()=>{
 const h=harness({realActivity:true});await beginWatch(h);await spin(h,()=>h.data.state.task.phase==='robot_watch');const id=h.data.state.chatTabId;h.data.state.pending={id:'pending-v02',tabId:id,kind:'reply',stage:'dispatched',payload:{chatKey:'chat:j1',text:'未核验消息'},runId:h.data.state.runId};h.tabs.delete(id);const n=h.tabs.size;await h.pulse();assert.equal(h.data.state.status,'blocked');assert.equal(h.data.state.pending.id,'pending-v02');assert.equal(h.tabs.size,n);assert.match(h.data.state.reason,/待核验/);
});
test('v02 migration preserves user facts and dedup history while adding handoff defaults',async()=>{
 const h=harness();await h.initialize();delete h.data.config.settings.autoReplyAfterBatch;h.data.config.settings.keepAwake=false;h.data.config.answers.education='本人已确认学历';h.data.state.version='0.1.11';h.data.state.seenJobs['job:existing']={status:'complete'};await h.events.installed();assert.equal(h.data.config.settings.autoReplyAfterBatch,true);assert.equal(h.data.config.settings.keepAwake,true);assert.equal(h.data.config.answers.education,'本人已确认学历');assert.equal(h.data.config.answers.salary,'');assert.equal(h.data.state.seenJobs['job:existing'].status,'complete');
});
