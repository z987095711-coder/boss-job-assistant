const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
function fixture(path='/web/geek/chat'){
 const timers=[],intervals=[],sent=[],handlers={};let observer,listener,token='initial',writes=0,owned=null;
 const A={setSelectors:()=>{},activity:()=>({rows:[{key:'chat:one',token,unread:true}],active:null}),blocker:()=>'',navigate:async()=>{writes++;},action:async()=>{writes++;}};
 const chrome={runtime:{id:'fixture',onMessage:{addListener:f=>{listener=f;}},sendMessage:async m=>{sent.push(m);return {ok:true,data:{accepted:true,selectors:{}}};}}};
 A.isWritingInput=e=>owned===e;
 const context=vm.createContext({SBLAdapter:A,SBLCore:{VERSION:'0.1.5'},chrome,document:{documentElement:{},addEventListener:(type,fn)=>{handlers[type]=fn;}},location:{pathname:path},MutationObserver:class{constructor(f){observer=f;}observe(){}},setTimeout:f=>{timers.push(f);return timers.length;},setInterval:f=>{intervals.push(f);},Date});
 vm.runInContext(fs.readFileSync(__dirname+'/../extension/content.js','utf8'),context);
 return {timers,intervals,sent,handlers,setOwned:e=>{owned=e;},mutate:()=>observer(),change:v=>{token=v;},writes:()=>writes,request:()=>new Promise(r=>listener({sbl:true,type:'ACTIVITY'},{id:'fixture'},r))};
}
test('content input: native owned edit does not self-pause, later human edit still pauses',async()=>{
 const f=fixture(),editor={isContentEditable:true};f.setOwned(editor);f.handlers.input({isTrusted:true,target:editor});assert.equal(f.sent.length,0);
 f.setOwned(null);f.handlers.input({isTrusted:true,target:editor});assert.deepEqual(f.sent.map(x=>x.type),['HUMAN_INPUT']);
});
test('content observer: many DOM mutations produce one read-only activity notification',async()=>{
 const f=fixture();for(let i=0;i<50;i++)f.mutate();assert.equal(f.timers.length,1);
 await f.timers[0]();assert.deepEqual(f.sent.map(x=>x.type),['CHAT_ACTIVITY']);assert.equal(f.writes(),0);
});
test('content observer: unchanged notifications are deduplicated and changed content is reported',async()=>{
 const f=fixture();await f.intervals[0]();await f.intervals[0]();assert.equal(f.sent.length,1);
 f.change('new-message');await f.intervals[0]();assert.equal(f.sent.length,2);assert.equal(f.writes(),0);
});
test('content observer: periodic scan never navigates a jobs page into chat',async()=>{
 const f=fixture('/web/geek/jobs');await f.intervals[0]();assert.equal(f.sent.length,0);assert.equal(f.writes(),0);
});
test('content observer: worker activity request is also read-only',async()=>{
 const f=fixture(),r=await f.request();assert.equal(r.ok,true);assert.equal(r.data.rows[0].key,'chat:one');assert.equal(f.writes(),0);
});
