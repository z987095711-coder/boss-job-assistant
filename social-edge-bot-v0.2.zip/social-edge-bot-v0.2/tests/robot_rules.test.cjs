const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../extension/core.js');
const msg=(text,id='q1',side='in')=>({text,id,side});
const snap=(messages=[],title='视频制作',company='测试影视公司')=>({chat:{key:'chat:one',title,company},messages});
function config(){return C.cleanConfig({settings:{resumeSelection:'bound'},profiles:[{name:'视频制作',greeting:'本人确认的视频介绍',matchKeywords:['剪辑'],overrides:{experience:'方向经历'}},{name:'AI训练',greeting:'本人确认的AI介绍',matchKeywords:['标注'],overrides:{skills:'方向工具'}}],answers:{experience:'通用经历',skills:'通用工具',previousJob:'上一份真实工作',roleUnderstanding:'岗位目标和任务'},industries:[{name:'影视',keywords:['影视'],greeting:'影视相关真实经历',answers:{experience:'行业经历'}}]});}
test('robot rules: 18 common topics and three retained basics; missing facts remain blank',()=>{
 const c=C.cleanConfig({answers:{education:'原学历',location:'原城市',availability:'原日期'}});
 assert.equal(C.FAQ.length,18);assert.equal(C.ALL_FAQ.length,21);
 for(const q of C.FAQ)assert.equal(c.answers[q.id],'');assert.equal(c.answers.education,'原学历');assert.equal(c.industries.length,0);
});
test('robot rules: actual prior job, experience, role understanding and tools remain separate',()=>{
 const c=config();
 for(const [text,key,answer] of [['上家公司是做什么的？','previousJob','上一份真实工作'],['有相关经验吗？','experience','行业经历'],['你对这个岗位有什么理解？','roleUnderstanding','岗位目标和任务'],['会哪些软件？','skills','通用工具']]){
   const p=C.robotPlan(snap([msg(text)]),c);assert.deepEqual(p.keys,[key]);assert.equal(p.steps.find(x=>x.kind==='reply')?.text,answer);
 }
});
test('robot rules: same question chooses industry then direction then generic answer',()=>{
 const c=config(),q=[msg('有相关经验吗？')];
 assert.equal(C.robotPlan(snap(q),c).steps.at(-1).text,'行业经历');
 assert.equal(C.robotPlan(snap(q,'剪辑','其他公司'),c).steps.at(-1).text,'方向经历');
 assert.equal(C.robotPlan(snap(q,'未知岗位','其他公司'),c).steps.at(-1).text,'通用经历');
});
test('robot rules: ambiguous industry/direction falls back without guessing history',()=>{
 const c=config();c.industries.push({name:'电商',keywords:['影视'],greeting:'电商介绍',answers:{}});
 const w=C.wording(c,{title:'未知',company:'影视公司'});assert.equal(w.industry,'');
 const unknown=C.wording(c,{title:'未知',company:'其他公司'});assert.equal(unknown.profile,null);assert.equal(unknown.greeting,c.robot.greeting);
});
test('robot rules: no messages still produces introduction',()=>{
 const c=config(),p=C.robotPlan(snap(),c);assert.deepEqual(p.steps.map(x=>x.kind),['intro']);
});
test('robot rules: manual answered history suppresses duplicate answers, but platform hello is not introduction',()=>{
 const c=config(),p=C.robotPlan(snap([msg('您好，对职位很感兴趣，希望沟通。','o0','out'),msg('会哪些软件？'),msg('已手动说明具体工具','o1','out')]),c);
 assert.deepEqual(p.steps.map(x=>x.kind),['intro']);assert.ok(p.history.seenInbound.includes('q1'));
 const again=C.robotPlan(snap([msg('影视相关真实经历','i','out'),msg('会哪些软件？')]),c);assert.deepEqual(again.steps.map(x=>x.kind),['reply']);
});
test('robot rules: unknown/blank question never fabricates an answer; approved intro is still sent',()=>{
 const c=config();const p=C.robotPlan(snap([msg('期望薪资多少？')]),c);assert.deepEqual(p.steps.map(x=>x.kind),['intro']);assert.deepEqual(p.missing,['salary']);assert.equal(p.needsAnswer,true);
 const x=C.robotPlan(snap([msg('请解释某个未准备的技术原理？')]),c);assert.equal(x.needsAnswer,true);assert.ok(!x.steps.some(s=>s.kind==='reply'));
});
test('robot rules: ordinary decline permits intro and one polite reason question, never repeats it',()=>{
 const c=config(),messages=[msg('很抱歉，看了您的履历，与我们岗位不太匹配。')];
 const p=C.robotPlan(snap(messages),c);assert.deepEqual(p.steps.map(x=>x.kind),['intro','rejection']);assert.ok(p.steps.every(x=>x.allowSoftRejection));
 const repeat=C.robotPlan(snap([...messages,msg('影视相关真实经历','intro','out'),msg(c.robot.rejectionText,'reason','out')]),c,{rejectionAsked:true});assert.equal(repeat.steps.length,0);
 const persistent=C.robotPlan(snap(messages),c,{introVerified:true,rejectionAsked:true});assert.equal(persistent.steps.length,0);
});
test('robot rules: stop-contact instruction blocks intro, resume and rejection question',()=>{
 const c=config();for(const text of ['不用再联系我了','不要再发消息','不再继续沟通','别再打扰']){const p=C.robotPlan(snap([msg(text)]),c,{},2);assert.deepEqual(p.steps,[]);assert.equal(p.hardStop,true);}
});
test('robot rules: a new question after soft rejection can get its approved answer',()=>{
 const c=config(),p=C.robotPlan(snap([msg('岗位不合适'),msg(c.robot.rejectionText,'ask','out'),msg('那你会哪些软件？','new')]),c,{introVerified:true,rejectionAsked:true});
 assert.deepEqual(p.steps.map(s=>s.kind),['reply']);assert.equal(p.steps[0].text,'通用工具');assert.equal(p.steps[0].allowSoftRejection,true);
});
test('robot rules: first round accepts resume card; second round proactively offers only once',()=>{
 const c=config(),m={...msg('我想要一份你的附件简历'),resumeRequest:true};
 assert.deepEqual(C.robotPlan(snap([m]),c).steps.map(x=>x.kind),['intro','resumeConsent']);
 const conv={introVerified:true,roundInbound:[]};assert.deepEqual(C.robotPlan(snap(),c,conv,1).steps,[]);
 assert.deepEqual(C.robotPlan(snap(),c,conv,2).steps.map(x=>x.kind),['resumeOffer']);
 for(const resumeStatus of ['sent','waiting'])assert.deepEqual(C.robotPlan(snap(),c,{...conv,resumeStatus},2).steps,[]);
 assert.ok(!C.robotPlan(snap([msg('不用发简历')]),c,conv,2).steps.some(x=>x.kind.startsWith('resume')));
});
test('robot rules: resume card is accepted even when a separate question lacks approved facts',()=>{
 const c=config(),p=C.robotPlan(snap([{...msg('我想要一份你的附件简历','r'),resumeRequest:true},msg('期望薪资多少？','q')]),c);
 assert.deepEqual(p.steps.map(x=>x.kind),['intro','resumeConsent']);assert.equal(p.needsAnswer,true);assert.deepEqual(p.steps[1].ids,['r']);
});
test('robot rules: reply then resume interrupted by new greeting retains resume obligation',()=>{
 const c=config(),p=C.robotPlan(snap([msg('会哪些软件？发份简历。')]),c);assert.equal(p.steps.find(x=>x.kind==='reply').wantsResume,true);
 const replanned=C.robotPlan(snap([msg('好的','ack')]),c,{introVerified:true,resumeRequested:true});assert.ok(replanned.steps.some(x=>x.kind==='resumeOffer'));
});
test('robot rules: uncertain write and unknown sender cannot be retried through another run',()=>{
 const c=config();assert.equal(C.robotPlan(snap(),c,{uncertainWrite:true}).steps.length,0);assert.equal(C.robotPlan(snap([msg('会哪些软件？','u','unknown')]),c).steps.length,0);
});
test('robot rules: all ten added FAQ slots match their intended common questions',()=>{
 const c=config();for(const q of C.FAQ.slice(8)){c.answers[q.id]='已确认回答 '+q.id;const p=C.robotPlan(snap([msg(q.keys[0]+'怎么样？')]),c,{introVerified:true});assert.deepEqual(p.keys,[q.id],q.id);assert.equal(p.steps[0]?.text,c.answers[q.id],q.id);}
});
test('robot rules: visible pending resume request prevents duplicate offer even without saved state',()=>{
 const c=config();assert.deepEqual(C.robotPlan({...snap(),resumeWaiting:true},c,{introVerified:true,roundInbound:[]},2).steps,[]);
});
test('robot rules: HR native request can be accepted after an earlier proactive request was waiting',()=>{
 const c=config(),p=C.robotPlan({...snap([{...msg('我想要一份你的附件简历'),resumeRequest:true}]),resumeWaiting:true},c,{introVerified:true,resumeStatus:'waiting'});
 assert.deepEqual(p.steps.map(s=>s.kind),['resumeConsent']);
});
