// Reconstructed DOM with the classes/hierarchy actually present in diagnostic (4).
// Behavioral delays are simulated; this file does not connect to a live BOSS account.
const test=require('node:test'),assert=require('node:assert/strict');
const {harness}=require('./dom-harness.cjs');
function reportedChat({neverReady=false}={}){
  const h=harness(),{el,document}=h;h.context.KeyboardEvent=h.context.Event;h.context.performance={now:()=>performance.now()};
  h.context.location.pathname='/web/geek/chat';h.context.location.href='https://www.zhipin.com/web/geek/chat';
  const caption=()=>el('div',{class:'title-box'}).append(el('span',{class:'name-text'},'测试女士'),el('span',{},'测试公司'),el('span',{},'招聘专员'));
  const row=el('div',{class:'friend-content selected'}).append(el('div',{class:'figure'}).append(el('img',{class:'image-circle'})),el('div',{class:'text'}).append(el('span',{class:'time'},'23:03'),caption(),el('div',{class:'gray last-msg'},'网站预设招呼')));
  const labels=el('div',{class:'label-list'}).append(el('ul').append(el('li',{},'全部'),el('li',{class:'filter-item'}).append(el('img',{class:'filter-icon'}),el('span',{},'AI筛选'))));
  const left=el('div',{class:'chat-user v2'}).append(el('input',{class:'boss-search-input',placeholder:'搜索30天内的联系人'}),labels,el('div',{class:'chat-content'}).append(el('div',{class:'user-list'}).append(el('div',{class:'user-list-content'}).append(el('ul').append(el('li',{role:'listitem'}).append(el('div',{class:'friend-content-warp'}).append(row)))))));
  const list=el('ul',{class:'im-list'});list.append(el('li',{class:'message-item item-myself','data-mid':'site-greeting'}).append(el('div',{class:'message-content'}).append(el('span',{class:'text'},'网站预设招呼'))));
  const editor=el('div',{id:'chat-input',class:'chat-input',contenteditable:'true'}),send=el('button',{class:'btn-v2 btn-sure-v2 btn-send disabled'},'发送');
  // Native disabled is FALSE in the observed failure; only the CSS state blocks the action.
  send.disabled=false;let model='',ready=false;const actions=[];
  editor.addEventListener('input',()=>{model=editor.innerText;actions.push('input');});
  editor.addEventListener('keyup',e=>{assert.notEqual(e.key,'Enter');actions.push('keyup');if(!neverReady)setTimeout(()=>{ready=true;send.className='btn-v2 btn-sure-v2 btn-send';actions.push('enabled');},3);});
  send.onclick=()=>{actions.push('click');assert.equal(ready,true,'Must not click the disabled-class button');list.append(el('li',{class:'message-item item-myself','data-mid':'intro-result'}).append(el('div',{class:'message-content'}).append(el('span',{class:'text'},model))));editor.textContent='';};
  const chat=el('div',{class:'chat-conversation'}).append(el('div',{class:'top-info-content'}).append(caption(),el('div',{class:'chat-position-content'}).append(el('span',{},'研究员'),el('span',{},'8-12K'),el('a',{},'查看职位'))),el('div',{class:'message-content'}).append(el('div',{class:'chat-record'}).append(el('div',{class:'chat-message'}).append(list))),el('div',{class:'message-controls'}).append(el('div',{class:'chat-im chat-editor'}).append(el('div',{class:'chat-controls'}).append(el('div',{class:'toolbar-btn unable'},'发简历')),el('div',{class:'editor-container'}).append(editor,el('div',{class:'chat-op'}).append(send)))));
  document.body.append(el('div',{class:'chat-container page-container'}).append(el('div',{class:'chat-wrap'}).append(left,chat)));
  const payload={chatKey:h.A.snapshot().chat?.key,title:'研究员',company:'测试公司',text:'这是已确认的自我介绍。',robot:true};
  return {h,row,editor,send,actions,payload,list};
}
test('reported failure: wait until disabled CLASS clears before clicking send',async()=>{
  const f=reportedChat();assert.ok(f.payload.chatKey);assert.equal(f.h.A.snapshot().conversations.length,1,'AI filter icon is not a recruiter');let checkpoints=0;
  const result=await f.h.A.action('intro',f.payload,async()=>{},async()=>{checkpoints++;assert.ok(!f.send.className.includes('disabled'));});
  assert.equal(result.verified,true);assert.equal(f.send.clicks,1);assert.equal(checkpoints,1);assert.deepEqual(f.actions,['input','keyup','enabled','click']);assert.equal(f.editor.innerText,'');
});
test('reported failure: perpetually disabled class is never recorded as dispatched',async()=>{
  const f=reportedChat({neverReady:true});let checkpoints=0;await assert.rejects(f.h.A.action('intro',f.payload,async()=>{},async()=>{checkpoints++;}),e=>e.beforeClick===true);
  assert.equal(f.send.clicks,0);assert.equal(checkpoints,0);assert.ok(!f.h.A.inspect().uiTrace.some(x=>x.event==='send_clicked'));
});
test('reported failure: exact configured draft from earlier attempt is sent, not abandoned',async()=>{
  const f=reportedChat();f.editor.textContent=f.payload.text;const result=await f.h.A.action('intro',f.payload,async()=>{});assert.equal(result.verified,true);assert.equal(f.send.clicks,1);assert.ok(f.h.A.inspect().uiTrace.some(x=>x.event==='draft_reused'));
});
test('reported failure: unrelated draft remains unchanged',async()=>{
  const f=reportedChat();f.editor.textContent='用户正在写的不同内容';await assert.rejects(f.h.A.action('intro',f.payload,async()=>{}),/不同草稿/);assert.equal(f.editor.innerText,'用户正在写的不同内容');assert.equal(f.send.clicks,0);
});
test('reported failure: button disabled during checkpoint is not clicked',async()=>{
  const f=reportedChat();await assert.rejects(f.h.A.action('intro',f.payload,async()=>{},async()=>{f.send.className+=' disabled';}),e=>e.beforeClick===true);assert.equal(f.send.clicks,0);
});
test('contenteditable native edit is scoped, preserves text, and cannot become a trusted human pause',async()=>{
  const f=reportedChat(),doc=f.h.document;let native=0,ownedEvent=false;
  doc.createRange=()=>({selectNodeContents:()=>{}});doc.getSelection=()=>({removeAllRanges:()=>{},addRange:()=>{}});
  doc.execCommand=(command,ui,text)=>{assert.equal(command,'insertText');native++;f.editor.textContent=text;ownedEvent=f.h.A.isWritingInput(f.editor);return true;};
  const result=await f.h.A.action('intro',f.payload,async()=>{});assert.equal(result.verified,true);assert.equal(native,1);assert.equal(ownedEvent,true);assert.equal(f.h.A.isWritingInput(f.editor),false);
});
