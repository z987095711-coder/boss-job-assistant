"""Synthetic fixtures for 0.1.1. These do NOT establish real BOSS compatibility."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,zipfile,io
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];results=[]
def ok(name,v):
    if not v: raise AssertionError(name)
    results.append({'name':name,'passed':True});print('PASS',name,flush=True)
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1280,'height':1000})
    def reset(body):
        page.goto('about:blank');page.set_content('<style>article,li{display:block;width:330px;padding:16px;margin:8px;background:#eee}span{display:inline-block;margin:3px}div{margin:4px}</style>'+body)
        for f in ['core.js','adapter.js']:page.add_script_tag(path=str(ROOT/'extension'/f))
    reset('''<div class="job-card-wrapper">Loading placeholder</div><ul class="job-list"><li class="job-card-wrap"><div class="job-title"><span class="job-name" title="完整的测试岗位名称">完整的测试…</span><span class="salary">150-200元/天</span></div><div class="company-name">测试公司甲</div></li><li class="job-card-wrap"><span class="job-name">研究助理</span><span class="salary">10-15K</span><div class="company-name">测试公司乙</div></li></ul>''')
    jobs=page.evaluate('SBLAdapter.jobs()')
    ok('New wrapper selector parsed even when an earlier selector matches an empty skeleton',len(jobs)==2)
    ok('Full title attribute preferred over visual ellipsis',jobs[0]['title']=='完整的测试岗位名称')
    diag=page.evaluate('SBLAdapter.inspect()');ok('Diagnostic distinguishes candidate and parsed counts',diag['parsedJobsCount']==2 and diag['jobCandidatesCount']>=3)
    ok('Diagnostic contains field booleans not employer or job text','测试公司' not in json.dumps(diag,ensure_ascii=False) and 'hasCompany' in json.dumps(diag))
    reset('''<article class="job-card-wrap"><div class="job-title">AI 研究实习 <span class="salary">150-200元/天</span></div><div class="company-title">测试公司</div></article>''')
    ok('Daily-pay title cleaned without deleting job name',page.evaluate('SBLAdapter.jobs()[0].title')=='AI 研究实习')
    reset('''<div class="job-card-wrap"><span class="job-name">岗位一</span><span class="company-name">公司一</span><span class="job-name">岗位二</span><span class="company-name">公司二</span></div>''')
    ok('A list container containing multiple titles is not treated as one job',page.evaluate('SBLAdapter.jobs().length')==0)
    reset('''<div class="job-card-wrap"><span class="job-name">缺公司岗位</span></div>''')
    ok('Missing company still blocks job acceptance',page.evaluate('SBLAdapter.jobs().length')==0)
    reset('''<nav><span>推荐</span><span>兼职</span><span id="d1">导演/编导(长沙)</span><span id="d2">数据标注/...</span></nav><script>window.hit='';d1.onclick=()=>hit='d1';d2.onclick=()=>hit='d2';</script>''')
    page.evaluate("SBLAdapter.navigate('direction',{label:'导演/编导'})")
    ok('Direction nav fallback handles location suffix',page.evaluate('hit')=='d1')
    page.evaluate("SBLAdapter.navigate('direction',{label:'数据标注/AI训练师'})")
    ok('Direction fallback handles literal truncated tabs',page.evaluate('hit')=='d2')
    reset('''<section class="tiles"><article class="tile active"><div class="head"><span class="position-label">测试岗位一</span><span class="pay">10-12K</span></div><div class="foot"><span class="organization-label">测试公司一</span><span class="city">测试市</span></div></article><article class="tile"><div class="head"><span class="position-label">测试岗位二</span><span class="pay">10-12K</span></div><div class="foot"><span class="organization-label">测试公司二</span><span class="city">测试市</span></div></article></section><script>window.siteClicks=0;document.querySelector('.tiles').addEventListener('click',()=>siteClicks++);</script>''')
    ok('Unknown structure starts unreadable rather than guessing',page.evaluate('SBLAdapter.jobs().length')==0)
    page.evaluate('window.calResult=null;SBLAdapter.calibrate().then(r=>calResult=r).catch(e=>calResult={error:e.message});void 0;')
    page.locator('.position-label').first.click();page.locator('.organization-label').first.click();page.wait_for_function('calResult!==null')
    result=page.evaluate('calResult');ok('Two clicks produce usable local selectors',result.get('count')==2 and 'selectors' in result)
    ok('Calibration suppresses the website click action',page.evaluate('siteClicks')==0)
    page.evaluate('(r)=>SBLAdapter.setSelectors(r.selectors)',result)
    ok('Saved calibration reads both cards correctly',page.evaluate('SBLAdapter.jobs().length')==2)
    ok('Calibration selectors exclude selected-state class','active' not in result['selectors']['jobCards'])
    page.evaluate('window.cancelled=null;SBLAdapter.calibrate().catch(e=>cancelled=e.message);void 0;');page.keyboard.press('Escape')
    ok('Escape cancels local calibration and removes overlay',page.evaluate("cancelled==='已取消校准'&&!document.querySelector('[data-sbl-calibration]')"))
    # ZIP/image importer exercised with a neutral synthetic test asset, not the user's artwork.
    page.goto('about:blank');page.set_content('''<img id="brandIcon"><details id="branding"></details><input type="file" id="logoFile"><button id="pickLogo"></button><button id="downloadLogo" hidden></button><p id="logoResult"></p>''')
    page.add_script_tag(path=str(ROOT/'extension/branding.js'))
    f=io.BytesIO();Image.new('RGB',(90,120),(128,90,30)).save(f,format='PNG')
    page.locator('#logoFile').set_input_files({'name':'synthetic-test.png','mimeType':'image/png','buffer':f.getvalue()})
    page.wait_for_function('!document.querySelector("#downloadLogo").hidden')
    with page.expect_download() as d:page.click('#downloadLogo')
    download=d.value
    with zipfile.ZipFile(download.path()) as z:
        ok('Icon update archive has four static manifest-icon paths',set(z.namelist())=={f'extension/icons/{n}.png' for n in [16,32,48,128]})
        ok('Icon ZIP passes CRC validation',z.testzip() is None)
        ok('All generated icon sizes match manifest sizes',all(Image.open(io.BytesIO(z.read(f'extension/icons/{n}.png'))).size==(n,n) for n in [16,32,48,128]))
    ok('Icon UI explicitly distinguishes preview from installed static files','还没有改写安装文件' in page.locator('#logoResult').inner_text())
    browser.close()
(ROOT/'tests/revision-browser-results.json').write_text(json.dumps({'environment':'Offline synthetic DOM and image; no real BOSS session or user artwork','tests':results},ensure_ascii=False,indent=2))
print(json.dumps({'passed':len(results),'total':len(results)},ensure_ascii=False))
