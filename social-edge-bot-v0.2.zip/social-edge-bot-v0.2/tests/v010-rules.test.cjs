const test=require('node:test'),assert=require('node:assert/strict'),C=require('../extension/core.js');
const sent=(text,patch={})=>({id:'new',stableId:true,side:'out',text,delivery:'observed',...patch});
test('v10 receipt: whitespace and zero-width layout do not cause a false unknown result',()=>{
 assert.equal(C.textReceipt([sent('第一段 \n第\u200b二段')],'第一段\n第二段',{beforeCount:0,beforeIds:[]}).verified,true);
});
test('v10 receipt: inbound identical text is never my outgoing receipt',()=>{
 assert.equal(C.textReceipt([sent('介绍',{side:'in'})],'介绍',{beforeCount:0,beforeIds:[]}).verified,false);
});
test('v10 receipt: old exact outgoing text alone is not evidence of a new send',()=>{
 assert.equal(C.textReceipt([sent('介绍',{id:'old'})],'介绍',{beforeCount:1,beforeIds:['old']}).verified,false);
});
test('v10 receipt: stable native ID verifies a new bubble even when older messages unload',()=>{
 assert.equal(C.textReceipt([sent('介绍')],'介绍',{beforeCount:1,beforeIds:['old']}).verified,true);
});
test('v10 receipt: generated fallback IDs cannot serve as stable native send evidence',()=>{
 assert.equal(C.textReceipt([sent('介绍',{stableId:false})],'介绍',{beforeCount:1,beforeIds:['old']}).verified,false);
});
test('v10 receipt: failed bubble is a failure, not a success count',()=>{
 const r=C.textReceipt([sent('介绍',{delivery:'failed'})],'介绍',{beforeCount:0,beforeIds:[]});assert.equal(r.verified,false);assert.equal(r.definitiveFailure,true);
});
test('v10 receipt: sending spinner remains pending, not delivered',()=>{
 const r=C.textReceipt([sent('介绍',{delivery:'sending'})],'介绍',{beforeCount:0,beforeIds:[]});assert.equal(r.verified,false);assert.notEqual(r.definitiveFailure,true);
});
test('v10 receipt: actual message-body words such as 未读 are never stripped',()=>{
 assert.notEqual(C.messageKey('这句话含未读二字'),C.messageKey('这句话含二字'));
});
test('v10 priority: stored unanswered flag ranks before unknown or own-last conversations',()=>{
 assert.ok(C.replyPriority({}, {pendingReply:true}).rank<C.replyPriority({}).rank);assert.ok(C.replyPriority({unread:true}).rank<C.replyPriority({needsReply:true}).rank);
});
test('v10 idle: default enabled is configurable, explicit false persists through normalization',()=>{
 assert.equal(C.defaults().settings.idleReplyEnabled,true);assert.equal(C.cleanConfig({settings:{idleReplyEnabled:false}}).settings.idleReplyEnabled,false);
});
test('v10 automatic policy: own last message causes no second-round proactive resume or followup',()=>{
 const c=C.defaults();c.robot.greeting='测试介绍';c.robot.sendResume=true;const ms=[{id:'i1',side:'in',text:'你好'},sent('手动回复')];
 assert.equal(C.robotPlan({messages:ms,chat:{}},c,{},2,{onlyPending:true}).steps.length,0);
});
test('v10 automatic policy: unknown questions are left for manual handling, never invented',()=>{
 const c=C.defaults();c.robot.greeting='测试介绍';const ms=[sent('测试介绍'),{id:'i1',side:'in',text:'解释这个全新的专业问题？'}];const plan=C.robotPlan({messages:ms,chat:{}},c,{introVerified:true},1,{onlyPending:true});
 assert.equal(plan.steps.length,0);assert.equal(plan.needsAnswer,true);
});
test('v10 automatic policy: supported ordinary rejection question remains controlled separately',()=>{
 const c=C.defaults();c.robot.greeting='测试介绍';c.robot.followRejection=false;const ms=[{id:'r',side:'in',text:'暂时不考虑，谢谢'}];assert.equal(C.robotPlan({messages:ms,chat:{}},c,{},1,{onlyPending:true}).steps.length,0);
});

test('v10 automatic policy: a stale pending flag cannot override a new manual answer',()=>{
 const c=C.defaults();c.robot.greeting='测试介绍';c.answers.skills='审核过的工具答案';const ms=[sent('测试介绍'),{id:'q',side:'in',text:'会哪些工具？'},sent('刚刚已由本人亲自答复',{id:'manual'})];const conv={introVerified:true,pendingReply:true,introText:'测试介绍',lastBotOutboundText:'测试介绍'};
 assert.equal(C.robotPlan({messages:ms,chat:{}},c,conv,1,{onlyPending:true}).steps.length,0);
});
test('v10 automatic policy: after its own introduction the bot can still answer the pending question',()=>{
 const c=C.defaults();c.robot.greeting='测试介绍';c.answers.skills='审核过的工具答案';const ms=[{id:'q',side:'in',text:'会哪些工具？'},sent('测试介绍')];const conv={introVerified:true,pendingReply:true,introText:'测试介绍',lastBotOutboundText:'测试介绍'};
 assert.equal(C.robotPlan({messages:ms,chat:{}},c,conv,1,{onlyPending:true}).steps[0]?.kind,'reply');
});

test('v10 automatic policy: replying to a mixed question does not drop the pending requested resume',()=>{
 const c=C.defaults();c.robot.greeting='测试介绍';c.robot.sendResume=true;c.robot.allowDefaultResume=true;c.answers.skills='审核过的工具答案';const ms=[sent('测试介绍'),{id:'q',side:'in',text:'会哪些工具？发一份简历'},sent('审核过的工具答案',{id:'answer'})];const conv={introVerified:true,pendingReply:true,resumeRequested:true,seenInbound:['q'],answered:['skills'],introText:'测试介绍',lastBotOutboundText:'审核过的工具答案'};
 assert.equal(C.robotPlan({messages:ms,chat:{}},c,conv,1,{onlyPending:true}).steps[0]?.kind,'resume');
});
