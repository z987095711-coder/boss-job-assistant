// Small offline DOM test double. This is not a browser or a captured user session.
const vm=require('node:vm'),fs=require('node:fs');
function harness(versionPath=__dirname+'/../extension'){
  let document;const effects=[];
  const selectors=s=>s.split(',').map(x=>x.trim()).filter(Boolean);
  function compound(e,s){
    const nth=s.match(/:nth-of-type\((\d+)\)/);if(nth){if(e.parentElement?.children.filter(x=>x.tagName===e.tagName).indexOf(e)!==Number(nth[1])-1)return false;s=s.replace(nth[0],'');}
    if(s.includes(':checked')){if(!e.checked)return false;s=s.replace(':checked','');}
    const attrs=[...s.matchAll(/\[([\w-]+)(?:([*^$~]?=)["']?([^"'\]]*)["']?)?\]/g)];
    for(const [,name,op,value] of attrs){const a=e.getAttribute(name);if(a===null)return false;if(op==='='&&a!==value)return false;if(op==='*='&&!a.includes(value))return false;if(op==='^='&&!a.startsWith(value))return false;if(op==='$='&&!a.endsWith(value))return false;}
    s=s.replace(/\[[^\]]+\]/g,'');const tag=s.match(/^[a-z][\w-]*/i)?.[0];if(tag&&e.tagName.toLowerCase()!==tag.toLowerCase())return false;
    if([...s.matchAll(/\.([\w-]+)/g)].some(x=>!e.classList.includes(x[1])))return false;
    const id=s.match(/#([\w-]+)/)?.[1];if(id&&e.id!==id)return false;return true;
  }
  function matches(e,selector){
    const parts=selector.replace(/\s*>\s*/g,' > ').trim().split(/\s+/);let i=parts.length-1,p=e;
    if(!compound(p,parts[i--]))return false;
    while(i>=0){if(parts[i]==='>'){p=p.parentElement;if(!p||!compound(p,parts[--i]))return false;i--;}
      else{p=p.parentElement;while(p&&!compound(p,parts[i]))p=p.parentElement;if(!p)return false;i--;}}
    return true;
  }
  class Element{
    constructor(tag,attrs={},text=''){this.tagName=tag.toUpperCase();this.attrs={...attrs};this.children=[];this.parentElement=null;this.ownText=text;this.style={};this.disabled=false;this.listeners={};this.clicks=0;}
    get id(){return this.attrs.id||'';}set id(v){this.attrs.id=v;}get className(){return this.attrs.class||'';}set className(v){this.attrs.class=v;}
    get classList(){const a=this.className.split(/\s+/).filter(Boolean);Object.defineProperty(a,'toggle',{value:(name,force)=>{const on=force===undefined?!a.includes(name):force;this.className=[...a.filter(x=>x!==name),...(on?[name]:[])].join(' ');return on;}});return a;}
    get dataset(){const attrs=this.attrs;return new Proxy({},{get:(_,k)=>attrs['data-'+k.replace(/[A-Z]/g,x=>'-'+x.toLowerCase())],set:(_,k,v)=>(attrs['data-'+k.replace(/[A-Z]/g,x=>'-'+x.toLowerCase())]=String(v),true)});}
    get lastElementChild(){return this.children.at(-1)||null;}
    get textContent(){return this.ownText+this.children.map(c=>c.textContent).join('');}set textContent(v){this.ownText=v;for(const c of this.children)c.parentElement=null;this.children=[];}
    get innerText(){return this.ownText+this.children.filter(c=>c.style.display!=='none').map(c=>c.innerText).join(' ');}
    get isConnected(){let p=this;while(p.parentElement)p=p.parentElement;return p===document;}
    get isContentEditable(){return this.getAttribute('contenteditable')==='true';}
    get href(){const v=this.getAttribute('href');return v?new URL(v,'https://www.zhipin.com/web/geek/jobs').href:'';}
    getAttribute(k){return this.attrs[k]??null;}setAttribute(k,v){this.attrs[k]=String(v);}
    append(...nodes){for(const n of nodes){n.parentElement=this;this.children.push(n);}return this;}
    replaceChildren(...nodes){for(const c of this.children)c.parentElement=null;this.children=[];this.ownText='';this.append(...nodes);}
    contains(e){for(let p=e;p;p=p.parentElement)if(p===this)return true;return false;}
    matches(s){return selectors(s).some(x=>matches(this,x));}
    closest(s){for(let p=this;p;p=p.parentElement)if(p.matches(s))return p;return null;}
    querySelectorAll(s){const out=[];const walk=e=>{for(const c of e.children){if(c.matches(s))out.push(c);walk(c);}};walk(this);return out;}
    querySelector(s){return this.querySelectorAll(s)[0]||null;}
    getClientRects(){for(let p=this;p;p=p.parentElement)if(p.style.display==='none')return [];return this.isConnected?[{}]:[];}
    focus(){document.activeElement=this;}
    addEventListener(type,fn){(this.listeners[type]||=[]).push(fn);}
    dispatchEvent(event){event.target=this;for(const fn of this.listeners[event.type]||[])fn(event);return true;}
    click(){this.clicks++;effects.push(this.id||this.className||this.tagName);const event={target:this};for(let p=this;p;p=p.parentElement)p.onclick?.(event);}
  }
  class TextArea extends Element{get value(){return this._value||'';}set value(v){this._value=v;}}
  class Input extends Element{get value(){return this._value||'';}set value(v){this._value=v;}}
  const el=(tag,attrs={},text='')=>new (tag==='textarea'?TextArea:tag==='input'?Input:Element)(tag,attrs,text);
  document=el('document');document.body=el('body');document.append(document.body);
  let time=0;class Clock extends Date{static now(){return time+=250;}}
  class Event{constructor(type,opts={}){this.type=type;Object.assign(this,opts);}}
  const context=vm.createContext({document,Element,HTMLTextAreaElement:TextArea,HTMLInputElement:Input,Event,InputEvent:Event,URL,Date:Clock,location:{href:'https://www.zhipin.com/web/geek/jobs',pathname:'/web/geek/jobs'},getComputedStyle:e=>({display:'block',visibility:'visible',opacity:'1',...e.style}),setTimeout:fn=>setTimeout(fn,0),clearTimeout});
  vm.runInContext(fs.readFileSync(versionPath+'/core.js','utf8'),context);
  vm.runInContext(fs.readFileSync(versionPath+'/adapter.js','utf8'),context);
  return {A:context.SBLAdapter,el,document,effects,context};
}
function jobFixture(h,{tooltip='查看职位详情',override='.job-title',detailTitle='AI设计师（高奖金）'}={}){
  const {el,document,A}=h;
  const list=el('ul',{class:'rec-job-list'}),wrap=el('div',{class:'job-card-wrap active'}),card=el('li',{class:'job-card-box'});
  const title=el('a',{class:'job-name',href:'/job_detail/test-job.html',title:tooltip},'AI设计师（高奖金）');
  const titleRow=el('div',{class:'job-title clearfix',title:tooltip}).append(title,el('span',{class:'job-salary'},'10–15K'));
  card.append(el('div',{class:'job-info'}).append(titleRow),el('div',{class:'job-card-footer'}).append(el('span',{class:'company-location'},'测试公司')));
  list.append(wrap.append(card));
  const cta=el('a',{class:'op-btn op-btn-chat',id:'contact'},'立即沟通');
  const heading=el('span',{class:'job-name',title:'职位信息'},detailTitle);
  const detail=el('div',{class:'job-detail-box'}).append(el('div',{class:'job-detail-header'}).append(el('div',{class:'job-header-info'}).append(el('div',{class:'job-detail-info'}).append(heading)),el('div',{class:'job-detail-op clearfix'}).append(cta)));
  const next=el('a',{id:'continue'},'继续沟通'),modal=el('div',{class:'greet-boss-dialog'},'已向BOSS发送消息').append(next);modal.style.display='none';
  cta.onclick=()=>{modal.style.display='block';};
  document.body.append(list,el('div',{class:'job-detail-container'}).append(detail),modal);
  A.setSelectors({jobCards:'.job-card-box',jobCompany:'.company-location',jobTitle:override});
  return {card,wrap,title,heading,cta,next,modal,detail};
}
function chatFixture(h){
  const {el,document}=h;
  const row=el('div',{'data-sbl-conversation':'hr-test',class:'active'});
  const editor=el('textarea',{'data-sbl-editor':''});
  const send=el('button',{'data-sbl-send':'',id:'send'},'发送');
  const chat=el('div',{'data-sbl-chat':'','data-job-id':'test-job'}).append(el('span',{'data-sbl-chat-job':''},'AI设计师（高奖金）'),el('span',{'data-sbl-chat-company':''},'测试公司'),editor,send);
  send.onclick=()=>{chat.append(el('div',{'data-sbl-message':'','data-sbl-side':'out'},editor.value));editor.value='';};
  document.body.append(row,chat);return {editor,send,chat};
}
module.exports={harness,jobFixture,chatFixture};
