"""Load the actual MV3 extension into isolated Chromium. All zhipin traffic is intercepted.
No real login, recruiters or job applications are involved."""
from pathlib import Path
from tempfile import TemporaryDirectory
from playwright.sync_api import sync_playwright
import json, time
ROOT=Path(__file__).resolve().parents[1]
results=[]
def ok(name,value):
    if not value:raise AssertionError(name)
    results.append({'name':name,'passed':True})
fixture=(ROOT/'tests/fixture.html').read_text()
# Emulate actual route separation and same-tab navigation.
extra='''<script>
const route=location.pathname;
if(route.includes('/resume')){document.querySelectorAll('#jobs,[data-sbl-detail],#chat-list,[data-sbl-chat]').forEach(e=>e.style.display='none');}
else if(route.includes('/chat')){document.querySelectorAll('#profile,#jobs,[data-sbl-detail]').forEach(e=>e.style.display='none');}
else{document.querySelectorAll('#profile,#chat-list,[data-sbl-chat]').forEach(e=>e.style.display='none');}
const old=document.querySelector('#initiate').onclick;
document.querySelector('#initiate').onclick=()=>{old();document.querySelector('#go-chat').onclick=()=>setTimeout(()=>location.href='/web/geek/chat',50);};
</script>'''
fixture=fixture.replace('</body>',extra+'</body>')
with TemporaryDirectory() as userdir,sync_playwright() as p:
    context=p.chromium.launch_persistent_context(userdir,headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox',f'--disable-extensions-except={ROOT/"extension"}',f'--load-extension={ROOT/"extension"}'],viewport={'width':1100,'height':1050})
    context.route('https://www.zhipin.com/**',lambda route:route.fulfill(status=200,content_type='text/html',body=fixture))
    workers=context.service_workers
    worker=workers[0] if workers else context.wait_for_event('serviceworker')
    eid=worker.url.split('/')[2]
    ui=context.new_page();errors=[];ui.on('pageerror',lambda e:errors.append(str(e)))
    ui.goto(f'chrome-extension://{eid}/panel.html');ui.wait_for_selector('#answer-status')
    ok('MV3 service worker loads',bool(eid))
    ok('Five-step settings interface loads',ui.locator('#steps button').count()==5)
    ok('8 FAQ fields plus 2 followups',ui.locator('#questions textarea').count()==8 and ui.locator('#followups textarea').count()==2)
    ui.screenshot(path=str(ROOT/'docs/ui-desktop.png'),full_page=True)
    ui.set_viewport_size({'width':390,'height':844});ui.screenshot(path=str(ROOT/'docs/ui-sidepanel.png'),full_page=True)
    ok('Side panel has no horizontal overflow',ui.evaluate('document.documentElement.scrollWidth<=window.innerWidth'))
    def req(kind,**kwargs):
        out=ui.evaluate('(m)=>chrome.runtime.sendMessage(m)',{'sbl':True,'type':kind,**kwargs})
        if not out.get('ok'):raise RuntimeError(out.get('error'))
        return out.get('data')
    site=context.new_page();site.goto('https://www.zhipin.com/web/geek/job');site.wait_for_timeout(300)
    tab=req('TABS')[0]['id']
    info=req('INSPECT',tabId=tab)
    ok('Content-script bridge reads only mocked site',info['canReadJobs'])
    config=req('GET')['config']
    config['attachments']=[{'key':'r-fixture','name':'研究简历.pdf','meta':'2026.08.02 10:00 | 200KB'}]
    config['profiles']=[{'name':'创作方向','sourceLabel':'创作方向','sourceUrl':'https://www.zhipin.com/web/geek/job','resumeKey':'r-fixture','greeting':'我的测试方向介绍','enabled':True,'overrides':{}}]
    config['settings']['batchLimit']=1
    req('SAVE',config=config)
    req('START',tabId=tab,mode='preview',consent=False)
    def pulse():
        worker.evaluate("async()=>{const {state}=await chrome.storage.local.get('state');state.nextAt=0;await chrome.storage.local.set({state});await chrome.alarms.create('sbl-tick',{when:Date.now()+20});}")
        ui.wait_for_timeout(600)
    for i in range(5):
        pulse()
        if req('GET')['state']['status']!='running':break
    st=req('GET')['state']
    ok('Preview produces a plan',st['stats']['preview']==1)
    ok('Preview does not click contact/send',site.evaluate('initiated===0 && sentTexts.length===0 && sentFiles.length===0'))
    req('START',tabId=tab,mode='live',consent=True)
    phases=[]
    for i in range(35):
        pulse();st=req('GET')['state'];phase=(st.get('task') or {}).get('phase','')
        phases.append([st['status'],phase,st['reason']])
        if st['status']!='running':break
        if st['liveVerified']>=1 and st['stats']['resumes']>=1:break
    (ROOT/'tests/extension-phases.json').write_text(json.dumps(phases,ensure_ascii=False,indent=2))
    ok('Live fixture workflow does not block',st['status']=='running')
    ok('Live fixture confirms one initial contact',st['stats']['contacts']==1)
    ok('Live fixture confirms exact attachment receipt',st['stats']['resumes']==1)
    ok('Workflow returns to list and records verified completion',st['liveVerified']==1)
    ok('Managed conversation stores immutable profile/resume binding',len(st['conversations'])==1 and next(iter(st['conversations'].values()))['resume']['name']=='研究简历.pdf')
    req('PAUSE');st=req('GET')['state'];ok('Global Pause persists',st['status']=='paused')
    # Privacy settings: page-side scripts can request selectors, never access personal config.
    level=worker.evaluate("async()=>{try{return await chrome.storage.local.get('config')}catch(e){return {error:e.message}}}")
    ok('Settings are retained in extension local storage','config' in level)
    ok('No uncaught UI errors',not errors)
    context.close()
(ROOT/'tests/extension-results.json').write_text(json.dumps({'environment':'Actual Manifest V3 extension; isolated Chromium; intercepted synthetic zhipin routes only','tests':results},ensure_ascii=False,indent=2))
print(json.dumps({'passed':len(results),'total':len(results)},ensure_ascii=False))
