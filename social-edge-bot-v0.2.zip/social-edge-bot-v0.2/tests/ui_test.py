"""Browser-rendered UI with a mocked chrome.runtime. No extension loading or external website."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json, re, base64
ROOT=Path(__file__).resolve().parents[1]
results=[]
def ok(name,v):
    if not v:raise AssertionError(name)
    results.append({'name':name,'passed':True})
mock=r'''(()=>{
 let config=null,state=null;
 const mock={runtime:{getURL:p=>'file:///unused/'+p,sendMessage:async m=>{
  config ||= SBLCore.defaults();state ||= SBLCore.initialState();
  if(m.type==='GET')return {ok:true,data:{config:structuredClone(config),state:structuredClone(state)}};
  if(m.type==='SAVE'){config=SBLCore.cleanConfig(m.config);return {ok:true,data:{config:structuredClone(config)}};}
  if(m.type==='TABS')return {ok:true,data:[{id:9,title:'刚导入的简历页',url:'https://www.zhipin.com/web/geek/resume',active:false},{id:1,title:'离线模拟职位页',url:'https://www.zhipin.com/web/geek/jobs',active:true}]};
  if(m.type==='INSPECT')return {ok:true,data:{loggedIn:true,canReadJobs:m.tabId===1,blocker:'',counts:{jobCards:m.tabId===1?2:0}}};
  if(m.type==='READ_PROFILE')return {ok:true,data:{directions:['创作方向','金融方向','数据方向'],attachments:[{key:'a',name:'创作简历.pdf',meta:'2026.08.01 | 100KB'},{key:'b',name:'研究简历.pdf',meta:'2026.08.02 | 200KB'},{key:'c',name:'通用简历.pdf',meta:'2026.08.03 | 300KB'}]}};
  return {ok:true,data:{}};
 }},tabs:{create:async()=>({id:1})}};
 Object.assign(window.chrome,mock);
})();'''
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1100,'height':1100})
    page.add_init_script(mock);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    html=(ROOT/'extension/panel.html').read_text()
    html=re.sub(r'<script[^>]*>.*?</script>','',html,flags=re.S)
    html=re.sub(r'<link[^>]*>','',html)
    page.set_content(html);page.locator('#brandIcon').evaluate('(e,s)=>e.src=s','data:image/png;base64,'+base64.b64encode((ROOT/'extension/icons/128.png').read_bytes()).decode());page.add_style_tag(content=(ROOT/'extension/panel.css').read_text());page.evaluate(mock)
    page.add_script_tag(content=(ROOT/'extension/core.js').read_text());page.add_script_tag(content=(ROOT/'extension/panel.js').read_text());page.wait_for_selector('#answer-status',state='attached')
    ok('Five wizard steps rendered',page.locator('#steps button').count()==5)
    ok('Eight FAQ questions rendered',page.locator('#questions textarea').count()==8)
    ok('Three retained basic questions rendered separately',page.locator('#basicQuestions textarea').count()==3)
    ok('Two optional followups default disabled',not page.locator('#follow-enabled-0').is_checked() and not page.locator('#follow-enabled-1').is_checked())
    page.screenshot(path=str(ROOT/'docs/ui-desktop.png'),full_page=True)
    page.locator('#steps button').nth(1).click();page.click('#readProfile')
    page.wait_for_function('document.querySelectorAll("#profiles .card").length===3')
    ok('Import creates three direction bindings',page.locator('#profiles .card').count()==3)
    page.locator('#steps button').nth(2).click()
    ok('Each binding has three available resume files plus placeholder',page.locator('#profiles select').first.locator('option').count()==4)
    page.locator('#profiles select').first.select_option('b')
    page.locator('#profiles textarea').first.fill('真实项目介绍，不编造经历。')
    page.locator('#workTab').select_option('9')
    page.click('#bindSource')
    page.wait_for_function('document.querySelector("#sourceResult").textContent.startsWith("已记录")')
    ok('Active jobs page overrides stale resume tab and binding persists',page.locator('#sourceResult').inner_text().startswith('已记录'))
    page.set_viewport_size({'width':390,'height':844})
    ok('Mobile-width side panel has no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    page.evaluate('window.scrollTo(0,0)');page.screenshot(path=str(ROOT/'docs/ui-sidepanel.png'),full_page=True)
    page.locator('#steps button').nth(3).click()
    page.locator('summary').filter(has_text='用一条 HR 消息测试规则').click()
    page.fill('#testMessage','暂时不考虑，请不要再联系我')
    page.click('#testRule')
    ok('On-screen rule test shows stop decision','"action": "close"' in page.locator('#testResult').inner_text())
    ok('No uncaught UI errors',not errors)
    browser.close()
(ROOT/'tests/ui-results.json').write_text(json.dumps({'environment':'Chromium rendered UI, chrome.runtime mocked; not a native extension load','tests':results},ensure_ascii=False,indent=2))
print(json.dumps({'passed':len(results),'total':len(results)},ensure_ascii=False))
