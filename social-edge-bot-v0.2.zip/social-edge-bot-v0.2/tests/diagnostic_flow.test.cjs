const test=require('node:test'),assert=require('node:assert/strict');
const {harness,jobFixture,chatFixture}=require('./dom-harness.cjs');
test('v7 DOM: actual website inbox link receives click, no hardcoded location rewrite',async()=>{
 const h=harness(),entry=h.el('a',{href:'/web/geek/chat?from=header'},'沟通').append(h.el('span',{class:'nav-chat-num'},'87'));
 h.document.body.append(entry);entry.onclick=()=>chatFixture(h);await h.A.navigate('inbox');assert.equal(entry.clicks,1);assert.equal(h.A.snapshot().route,'chat');assert.equal(h.context.location.pathname,'/web/geek/jobs');
});
test('v7 DOM: invalid early selector match cannot hide a later usable conversation row',()=>{
 const h=harness(),invalid=h.el('div',{'data-sbl-conversation':''});h.document.body.append(invalid);
 const list=h.el('div',{class:'chat-list'}),row=h.el('div',{class:'geek-item active','data-id':'hr-later'});list.append(row);h.document.body.append(list);
 assert.equal(h.A.snapshot().conversations.length,1);assert.equal(h.A.snapshot().conversations[0].key,'chat:hr-later');
});
test('v7 DOM: unfamiliar chat/editor classes are retained in structural diagnostic without messages',()=>{
 const h=harness(),box=h.el('div',{class:'zpchat-session-module__container__abc'}),editor=h.el('div',{class:'zpchat-editor-module__input__abc',contenteditable:'true'},'敏感草稿不导出');box.append(editor);h.document.body.append(box);
 const report=h.A.inspect();assert.ok(report.surface.chatCandidates.some(x=>x.classes.includes('zpchat-session-module__container__abc')));assert.ok(report.surface.editorCandidates.some(x=>x.editable==='true'));assert.ok(!JSON.stringify(report).includes('敏感草稿不导出'));
});
test('v7 DOM: read-only structural diagnosis omits query parameters from current and frame URLs',()=>{
 const h=harness();h.context.location.href='https://www.zhipin.com/web/geek/jobs?privateToken=never-export';h.document.body.append(h.el('iframe',{src:'https://other.example/chat?secret=never-export'}));const report=h.A.inspect();assert.ok(!JSON.stringify(report).includes('never-export'));assert.equal(report.surface.frames[0].accessible,false);
});
test('v7 DOM: accessible iframe conversation and its own-realm textarea can be read and typed',async()=>{
 const outer=harness(),inner=harness(),f=chatFixture(inner),frame=outer.el('iframe',{src:'/web/geek/chat'});frame.contentDocument=inner.document;
 inner.document.defaultView={getComputedStyle:inner.context.getComputedStyle,HTMLTextAreaElement:inner.context.HTMLTextAreaElement,HTMLInputElement:inner.context.HTMLInputElement};
 inner.context.Element.prototype.nodeType=1;inner.context.Element.prototype.ownerDocument=inner.document;
 outer.document.body.append(frame);const snap=outer.A.snapshot();assert.equal(snap.conversations[0].key,'chat:hr-test');assert.equal(snap.chat.key,'chat:hr-test');
 const result=await outer.A.action('intro',{chatKey:'chat:hr-test',jobKey:'job:test-job',title:'AI设计师（高奖金）',company:'测试公司',text:'合成跨框架测试'},async()=>{});
 assert.equal(result.verified,true);assert.equal(f.send.clicks,1);assert.equal(f.editor.value,'');
});
test('diagnostic DOM: canonical job text overrides unrelated calibrated container tooltip',()=>{
 const h=harness();jobFixture(h);const jobs=h.A.jobs();assert.equal(jobs.length,1);assert.equal(jobs[0].title,'AI设计师(高奖金)');assert.equal(jobs[0].key,'job:test-job');
});
test('diagnostic DOM: actual adapter clicks contact and Continue after matching title',async()=>{
 const h=harness(),f=jobFixture(h);let stages=0;const job=h.A.jobs()[0];
 const result=await h.A.action('initiate',job,async()=>{},async evidence=>{stages++;assert.equal(evidence.title,job.title);});
 assert.equal(result.verified,true);assert.equal(f.cta.clicks,1);assert.equal(stages,1);
 await h.A.navigate('continue',job);assert.equal(f.next.clicks,1);
});
test('diagnostic DOM: actual adapter enters text, fires input event, clicks send and reads message',async()=>{
 const h=harness(),f=chatFixture(h);let inputs=0,stages=0;
 f.editor.addEventListener('input',()=>inputs++);
 const p={jobKey:'job:test-job',chatKey:'chat:hr-test',title:'AI设计师（高奖金）',company:'测试公司',text:'这是本人确认的项目介绍。'};
 const result=await h.A.action('intro',p,async()=>{},async evidence=>{stages++;assert.equal(evidence.beforeCount,0);});
 assert.equal(result.verified,true);assert.equal(inputs,1);assert.equal(stages,1);assert.equal(f.send.clicks,1);assert.equal(f.editor.value,'');assert.ok(h.A.snapshot().messages.some(x=>x.side==='out'&&x.text===p.text));
});
test('diagnostic DOM: mismatched detail title must still prevent contact click',async()=>{
 const h=harness(),f=jobFixture(h,{detailTitle:'完全不同的岗位'});let stages=0;
 await assert.rejects(h.A.action('initiate',h.A.jobs()[0],async()=>{},async()=>{stages++;}),/详情标题未匹配/);
 assert.equal(f.cta.clicks,0);assert.equal(stages,0);
 const info=h.A.inspect();assert.equal(info.titleComparison.activeCard,true);assert.equal(info.titleComparison.detailTitle,'完全不同的岗位');
});
test('diagnostic DOM: switching clicks card and bubbles to wrapper, not its separate title hyperlink',async()=>{
 const h=harness(),f=jobFixture(h);f.wrap.className='job-card-wrap';let bubbled=0;f.wrap.onclick=()=>bubbled++;
 await h.A.navigate('job',{key:h.A.jobs()[0].key});assert.equal(f.card.clicks,1);assert.equal(bubbled,1);assert.equal(f.title.clicks,0);
});
test('diagnostic DOM: known header is preferred over another job-name in detail body',async()=>{
 const h=harness(),f=jobFixture(h);f.detail.children.unshift(h.el('div',{class:'job-name'},'关联职位'));
 f.detail.children[0].parentElement=f.detail;
 const result=await h.A.action('initiate',h.A.jobs()[0],async()=>{},async()=>{});assert.equal(result.verified,true);assert.equal(f.cta.clicks,1);
});
test('diagnostic DOM: invisible separators do not prevent click or contaminate later chat title',async()=>{
 const h=harness(),f=jobFixture(h,{detailTitle:'AI设\u200b计师（高奖金）'});
 const result=await h.A.action('initiate',h.A.jobs()[0],async()=>{},async()=>{});assert.equal(result.verified,true);assert.equal(result.title,'AI设计师(高奖金)');
});
test('diagnostic DOM: selected card with stale detail is reopened and can then initiate',async()=>{
 const h=harness(),f=jobFixture(h,{detailTitle:'尚未刷新的其他职位'});const job=h.A.jobs()[0];
 f.card.onclick=()=>{f.heading.textContent='AI设计师（高奖金）';};
 await h.A.navigate('job',{key:job.key});assert.equal(f.card.clicks,1);
 const result=await h.A.action('initiate',job,async()=>{},async()=>{});assert.equal(result.verified,true);assert.equal(f.cta.clicks,1);
});
test('diagnostic DOM: forced retry really clicks even if the card is already selected',async()=>{
 const h=harness(),f=jobFixture(h);await h.A.navigate('job',{key:h.A.jobs()[0].key,force:true});assert.equal(f.card.clicks,1);
});
const chatPayload={jobKey:'job:test-job',chatKey:'chat:hr-test',title:'AI设计师（高奖金）',company:'测试公司'};
test('diagnostic DOM: activity reports badge and visible incoming changes without clicks',()=>{
 const h=harness(),f=chatFixture(h),row=h.document.querySelector('[data-sbl-conversation]');
 row.append(h.el('span',{'data-sbl-unread':'2'},'2'),h.el('span',{'data-sbl-preview':''},'会哪些软件？'));
 const first=h.A.activity();assert.equal(first.rows[0].unread,true);assert.equal(h.effects.length,0);
 f.chat.append(h.el('div',{'data-sbl-message':'','data-sbl-side':'in','data-message-id':'q1'},'会哪些软件？'));
 const second=h.A.activity();assert.notEqual(second.active.token,first.active.token);assert.equal(second.active.hasInbound,true);assert.equal(h.effects.length,0);
});
test('diagnostic DOM: only actual recipient-bearing public chat links use the background route',async()=>{
 const h=harness(),f=jobFixture(h),job=h.A.jobs()[0];await h.A.action('initiate',job,async()=>{});
 f.next.setAttribute('href','/web/geek/chat?public-context=test');assert.match(h.A.chatTarget(job).url,/public-context=test/);
 f.next.setAttribute('href','/web/geek/chat');assert.equal(h.A.chatTarget(job).url,'');
 f.next.setAttribute('href','https://other.example/web/geek/chat?a=b');assert.equal(h.A.chatTarget(job).url,'');assert.equal(f.next.clicks,0);
});
test('diagnostic DOM: a direct matching chat after contact is a valid receipt',async()=>{
 const h=harness(),f=jobFixture(h),job=h.A.jobs()[0];f.cta.onclick=()=>chatFixture(h);
 const result=await h.A.action('initiate',job,async()=>{});assert.equal(result.verified,true);assert.equal(f.cta.clicks,1);
});
test('diagnostic DOM: an old reply plan is not typed after a new inbound message',async()=>{
 const h=harness(),f=chatFixture(h);f.chat.append(h.el('div',{'data-sbl-message':'','data-sbl-side':'in','data-message-id':'new'},'新问题'));
 await assert.rejects(h.A.action('reply',{...chatPayload,text:'旧回答',inboundToken:h.context.SBLCore.hash('')},async()=>{}),/新消息已变化/);
 assert.equal(f.editor.value,'');assert.equal(f.send.clicks,0);
});
test('diagnostic DOM: recipient switch after typing cancels the send and clears only owned draft',async()=>{
 const h=harness(),f=chatFixture(h),row=h.document.querySelector('[data-sbl-conversation]');
 f.editor.addEventListener('input',()=>row.setAttribute('data-sbl-conversation','someone-else'));
 await assert.rejects(h.A.action('intro',{...chatPayload,text:'确认的介绍'},async()=>{}),/对象已改变/);
 assert.equal(f.send.clicks,0);assert.equal(f.editor.value,'');
});
function resumeFixture(h,{wrongFile=false,waiting=false,noCancel=false}={}){
 const f=chatFixture(h),open=h.el('button',{},'发简历'),row=h.el('div',{'data-sbl-resume-row':''}).append(h.el('span',{'data-sbl-file-name':''},wrongFile?'其他简历.pdf':'指定简历.pdf'));
 const submit=h.el('button',{},'发送'),cancel=h.el('button',{},'取消');
 const modal=h.el('div',{role:'dialog'},'请选择要发送的简历').append(row,submit);if(!noCancel)modal.append(cancel);modal.style.display='none';
 f.chat.append(open);h.document.body.append(modal);open.onclick=()=>{modal.style.display='block';};row.onclick=()=>{row.className='selected';};cancel.onclick=()=>{modal.style.display='none';};
 submit.onclick=()=>{modal.style.display='none';f.chat.append(h.el('div',{'data-sbl-message':'','data-sbl-side':'system'},waiting?'简历请求已发送，等待对方同意':'您的附件简历 指定简历.pdf 已发送给Boss'));};
 return {...f,row,submit,cancel,modal,open};
}
test('diagnostic DOM: resume chooses the exact bound file before sending',async()=>{
 const h=harness(),f=resumeFixture(h);const result=await h.A.action('resume',{...chatPayload,resume:{name:'指定简历.pdf',meta:''}},async()=>{});
 assert.equal(result.resumeStatus,'sent');assert.equal(f.row.clicks,1);assert.equal(f.submit.clicks,1);
});
test('diagnostic DOM: mismatched resume cancels the chooser without submitting',async()=>{
 const h=harness(),f=resumeFixture(h,{wrongFile:true});await assert.rejects(h.A.action('resume',{...chatPayload,resume:{name:'指定简历.pdf',meta:''}},async()=>{}),/附件缺失/);
 assert.equal(f.submit.clicks,0);assert.equal(f.cancel.clicks,1);assert.equal(f.modal.style.display,'none');
});
test('diagnostic DOM: an unclosable resume chooser blocks switching to another recipient',async()=>{
 const h=harness(),f=resumeFixture(h,{wrongFile:true,noCancel:true});await assert.rejects(h.A.action('resume',{...chatPayload,resume:{name:'指定简历.pdf',meta:''}},async()=>{}),/附件弹窗未关闭/);
 assert.equal(f.submit.clicks,0);
});
test('diagnostic DOM: resume permission request is waiting, not delivered',async()=>{
 const h=harness(),f=resumeFixture(h,{waiting:true});const result=await h.A.action('resume',{...chatPayload,resume:{name:'指定简历.pdf',meta:''}},async()=>{});
 assert.equal(result.resumeStatus,'waiting');assert.equal(f.submit.clicks,1);
});
test('diagnostic DOM: prior contact confirmation must be dismissed before another job',async()=>{
 const h=harness(),f=jobFixture(h);f.modal.style.display='block';
 await assert.rejects(h.A.navigate('return_list'),/沟通弹窗未关闭/);
 const stay=h.el('button',{},'留在此页');stay.onclick=()=>{f.modal.style.display='none';};f.modal.append(stay);
 await h.A.navigate('return_list');assert.equal(stay.clicks,1);assert.equal(f.modal.style.display,'none');
});
function requestCard(h,chat,onAgree){
 const agree=h.el('button',{},'同意'),decline=h.el('button',{},'拒绝'),card=h.el('div',{'data-sbl-message':'','data-sbl-side':'in','data-message-id':'resume-request'},'我想要一份你的附件简历，您是否同意？').append(decline,agree);agree.onclick=onAgree;chat.append(card);return {agree,decline,card};
}
const robotPayload={...chatPayload,robot:true,allowDefaultResume:true};
test('reply DOM: resume request clicks exactly the card agree button and detects native delivery',async()=>{
 const h=harness(),f=chatFixture(h),card=requestCard(h,f.chat,()=>f.chat.append(h.el('div',{'data-sbl-message':'','data-sbl-side':'system'},'您的附件简历 指定简历.pdf 已发送给Boss')));
 const unrelated=h.el('button',{},'同意');f.chat.append(unrelated);let checkpoints=0;
 assert.equal(h.A.snapshot().messages[0].resumeRequest,true);
 const result=await h.A.action('resumeConsent',robotPayload,async()=>{},async()=>{assert.equal(card.agree.clicks,0);checkpoints++;});
 assert.equal(result.resumeStatus,'sent');assert.equal(card.agree.clicks,1);assert.equal(card.decline.clicks,0);assert.equal(unrelated.clicks,0);assert.equal(checkpoints,1);
});
test('reply DOM: consent opening chooser is followed by actual bound-file selection and submit',async()=>{
 const h=harness(),f=resumeFixture(h),card=requestCard(h,f.chat,()=>{f.modal.style.display='block';});
 const first=await h.A.action('resumeConsent',{...robotPayload,resume:{name:'指定简历.pdf',meta:''}},async()=>{});assert.equal(first.resumeStatus,'selecting');assert.equal(f.submit.clicks,0);
 const second=await h.A.action('resume',{...robotPayload,resume:{name:'指定简历.pdf',meta:''}},async()=>{});assert.equal(second.resumeStatus,'sent');assert.equal(card.agree.clicks,1);assert.equal(f.row.clicks,1);assert.equal(f.submit.clicks,1);
});
test('reply DOM: proactive toolbar can return waiting request without reporting resume delivered',async()=>{
 const h=harness(),f=chatFixture(h),button=h.el('button',{},'发简历');f.chat.append(button);button.onclick=()=>f.chat.append(h.el('div',{'data-sbl-message':'','data-sbl-side':'system'},'简历请求已发送，等待对方同意'));
 const result=await h.A.action('resumeOffer',robotPayload,async()=>{});assert.equal(result.resumeStatus,'waiting');assert.equal(button.clicks,1);
 const recovered=await h.A.observe('resumeOffer',robotPayload,{});assert.equal(recovered.resumeStatus,'waiting');
});
test('reply DOM: native consent requires explicit configured allowance',async()=>{
 const h=harness(),f=chatFixture(h),card=requestCard(h,f.chat,()=>{});await assert.rejects(h.A.action('resumeConsent',{...robotPayload,allowDefaultResume:false},async()=>{}),/未启用/);assert.equal(card.agree.clicks,0);
});
test('reply DOM: identical prior introduction does not touch editor or send again',async()=>{
 const h=harness(),f=chatFixture(h);f.chat.append(h.el('div',{'data-sbl-message':'','data-sbl-side':'out'},'确认的介绍'));
 const result=await h.A.action('intro',{...robotPayload,text:'确认的介绍'},async()=>{});assert.equal(result.already,true);assert.equal(f.send.clicks,0);assert.equal(f.editor.value,'');
});
test('reply DOM: soft rejection follow-up uses the real text input/send path',async()=>{
 const h=harness(),f=chatFixture(h);f.chat.append(h.el('div',{'data-sbl-message':'','data-sbl-side':'in'},'岗位不太匹配'));
 const result=await h.A.action('rejection',{...robotPayload,allowSoftRejection:true,text:'方便说一下主要不匹配的要求吗？'},async()=>{});assert.equal(result.verified,true);assert.equal(f.send.clicks,1);
});
test('reply DOM: explicit no-contact arriving during typing cancels even an introduction',async()=>{
 const h=harness(),f=chatFixture(h);f.editor.addEventListener('input',()=>f.chat.append(h.el('div',{'data-sbl-message':'','data-sbl-side':'in'},'不要再联系我')));
 await assert.rejects(h.A.action('intro',{...robotPayload,allowSoftRejection:true,text:'确认的介绍'},async()=>{}),/停止联系/);assert.equal(f.send.clicks,0);assert.equal(f.editor.value,'');
});
test('reply DOM: stale header from previous chat is loading, never an authorized recipient',async()=>{
 const h=harness(),f=chatFixture(h),row=h.document.querySelector('[data-sbl-conversation]');row.append(h.el('span',{'data-sbl-row-job':''},'另一个岗位'),h.el('span',{'data-sbl-company':''},'另一家公司'));
 assert.equal(h.A.snapshot().chatLoading,true);await assert.rejects(h.A.action('intro',{...robotPayload,text:'确认的介绍'},async()=>{}),/等待加载/);assert.equal(f.send.clicks,0);
});
test('reply DOM: navigation scrolls a conversation list instead of refreshing the page',async()=>{
 const h=harness(),list=h.el('div',{'data-sbl-conversation-list':''});list.scrollHeight=2000;list.clientHeight=500;list.scrollTop=0;h.document.body.append(list);
 await h.A.navigate('conversations_more');assert.ok(list.scrollTop>0);await h.A.navigate('conversations_top');assert.equal(list.scrollTop,0);
});
test('reply DOM: prior visible resume request is observed without another toolbar click',async()=>{
 const h=harness(),f=chatFixture(h),button=h.el('button',{},'发简历');f.chat.append(button,h.el('div',{'data-sbl-message':'','data-sbl-side':'system'},'简历请求已发送，等待对方同意'));
 assert.equal(h.A.snapshot().resumeWaiting,true);const r=await h.A.action('resumeOffer',robotPayload,async()=>{});assert.equal(r.already,true);assert.equal(r.resumeStatus,'waiting');assert.equal(button.clicks,0);
});
test('reply DOM: missing resume binding closes an already open chooser before moving to another chat',async()=>{
 const h=harness(),f=resumeFixture(h);f.modal.style.display='block';await assert.rejects(h.A.action('resume',robotPayload,async()=>{}),/缺少已绑定附件/);assert.equal(f.submit.clicks,0);assert.equal(f.modal.style.display,'none');assert.equal(f.cancel.clicks,1);
});
test('fixed resume sequence: file selection, submit, confirmation, then delivery receipt',async()=>{
 const h=harness(),f=resumeFixture(h),order=[];
 const confirm=h.el('button',{},'确认投递'),cancel=h.el('button',{},'取消'),modal=h.el('div',{role:'dialog'},'请确认投递简历 指定简历.pdf').append(confirm,cancel);modal.style.display='none';h.document.body.append(modal);
 f.open.onclick=()=>{order.push('toolbar');f.modal.style.display='block';};f.row.onclick=()=>{order.push('file');f.row.className='selected';};
 f.submit.onclick=()=>{order.push('submit');f.modal.style.display='none';modal.style.display='block';};
 confirm.onclick=()=>{order.push('confirm');modal.style.display='none';f.chat.append(h.el('div',{'data-sbl-message':'','data-sbl-side':'system'},'您的附件简历 指定简历.pdf 已发送给Boss'));};cancel.onclick=()=>{modal.style.display='none';};
 const result=await h.A.action('resume',{...chatPayload,resume:{name:'指定简历.pdf',meta:''}},async()=>{});
 assert.equal(result.resumeStatus,'sent');assert.deepEqual(order,['toolbar','file','submit','confirm']);assert.equal(confirm.clicks,1);assert.equal(cancel.clicks,0);
 assert.ok(h.A.inspect().uiTrace.some(x=>x.event==='resume_confirm_clicked'));
});
test('fixed resume sequence: wrong file in confirmation is cancelled without confirming',async()=>{
 const h=harness(),f=resumeFixture(h),confirm=h.el('button',{},'确认投递'),cancel=h.el('button',{},'取消');
 const modal=h.el('div',{role:'dialog'},'确认发送简历').append(h.el('span',{},'其他简历.pdf'),confirm,cancel);modal.style.display='none';h.document.body.append(modal);
 f.submit.onclick=()=>{f.modal.style.display='none';modal.style.display='block';};cancel.onclick=()=>{modal.style.display='none';};
 await assert.rejects(h.A.action('resume',{...chatPayload,resume:{name:'指定简历.pdf',meta:''}},async()=>{}),/其他文件/);
 assert.equal(confirm.clicks,0);assert.equal(cancel.clicks,1);assert.equal(modal.style.display,'none');
});
