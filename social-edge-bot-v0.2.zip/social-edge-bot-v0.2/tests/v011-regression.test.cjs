// v0.1.11 regressions reconstructed from the user's diagnostic structure.
// Uses invented file/company labels, not the uploaded private diagnostic files.
const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../extension/core.js');
const {harness,jobFixture,chatFixture}=require('./dom-harness.cjs');
const expected={chatKey:'chat:hr-test',jobKey:'job:test-job',title:'AI设计师（高奖金）',company:'测试公司',robot:true,resumeSelection:'first'};
function chooser(h,{initial=false,close=true,files=['第一份.pdf','第二份.pdf','第三份.pdf'],selected=true}={}){
 const f=chatFixture(h),open=h.el('div',{class:'toolbar-btn tooltip tooltip-top'},'发简历');f.chat.append(open);
 const mod=h.el('div',{class:'test-layer-content'}),header=h.el('div',{class:'test-layer-header'}).append(h.el('h3',{},'请选择要发送的简历'));
 const x=h.el('button',{'aria-label':'关闭'},'×');if(close)header.append(x);
 const ul=h.el('ul',{class:'resume-list'}),rows=files.map(name=>h.el('li',{class:'list-item'}).append(h.el('div',{class:'item-body'}).append(h.el('div').append(h.el('span',{class:'resume-name'},name),h.el('a',{},'预览'))),h.el('span',{},'更新于2026.08.01 10:00 123.4KB')));
 ul.append(...rows);const send=h.el('button',{},'发送');send.disabled=true;
 mod.append(header,h.el('div',{class:'dialog-body'}).append(ul),h.el('div',{class:'test-footer'}).append(send));h.document.body.append(mod);mod.style.display=initial?'block':'none';
 open.onclick=()=>mod.style.display='block';x.onclick=()=>mod.style.display='none';
 rows.forEach(row=>row.onclick=()=>{for(const r of rows)r.className='list-item';if(selected)row.className='list-item is-selected';send.disabled=!selected;});
 send.onclick=()=>{mod.style.display='none';f.chat.append(h.el('div',{'data-sbl-message':'','data-sbl-side':'system'},'您的附件简历 第一份.pdf 已发送给Boss'));};
 return {...f,mod,rows,send,open,x,ul};
}
test('v11: new/default/migrated configs select first displayed file; prior bindings are retained',()=>{
 const raw={profiles:[{name:'测试方向',resumeKey:'r2',greeting:'已确认介绍'}],attachments:[{key:'r2',name:'第二份.pdf'}]};
 for(const c of [C.defaults(),C.cleanConfig(raw)])assert.equal(c.settings.resumeSelection,'first');
 const c=C.cleanConfig(raw);assert.equal(c.profiles[0].resumeKey,'r2');assert.equal(c.attachments[0].name,'第二份.pdf');
 assert.equal(C.cleanConfig({settings:{resumeSelection:'bound'}}).settings.resumeSelection,'bound');
});
test('v11: first-file mode does not require an imported resume; bound-file mode still does',()=>{
 const c=C.cleanConfig({profiles:[{name:'测试方向',greeting:'真实介绍',sourceLabel:'测试方向'}]});assert.deepEqual(C.validate(c),[]);
 c.settings.resumeSelection='bound';assert.ok(C.validate(c).some(e=>e.includes('附件')));
});
for(const [a,b,match] of [
 ['编剧-双休','编剧',true],['编剧（双休）','编剧',true],['周末双休 · 编剧','编剧',true],['编剧-五险一金+双休','编剧',true],
 ['编剧助理','编剧',false],['AI导演','导演',false],['研究员-行业研究','研究员',false],['销售经理','销售',false],['','',false],
 ['编剧-男频','编剧',false],['编剧-双休','编剧-女频',false]
])test(`v11: title identity ${a}/${b} = ${match}`,()=>assert.equal(C.compatibleJobTitle(a,b),match));
test('v11: reported selected 编剧-双休 card and 编剧 detail initiate exactly once',async()=>{
 const h=harness(),f=jobFixture(h,{detailTitle:'编剧'});f.title.textContent='编剧-双休';
 const job=h.A.jobs()[0];await h.A.navigate('job',{key:job.key,force:true});const r=await h.A.action('initiate',job,async()=>{});
 assert.equal(r.verified,true);assert.equal(f.cta.clicks,1);assert.equal(r.title,'编剧');assert.equal(h.A.inspect().titleComparison.benefitMatch,true);
});
test('v11: mismatching job ID remains a veto even with a selected matching title',async()=>{
 const h=harness(),f=jobFixture(h,{detailTitle:'编剧'});f.title.textContent='编剧-双休';f.detail.setAttribute('data-job-id','someone-else');
 await assert.rejects(h.A.action('initiate',h.A.jobs()[0],async()=>{}),/ID/);assert.equal(f.cta.clicks,0);
});
test('v11: benefit-tolerant matching still requires a selected card when detail lacks a company',async()=>{
 const h=harness(),f=jobFixture(h,{detailTitle:'编剧'});f.title.textContent='编剧-双休';f.wrap.className='job-card-wrap';
 await assert.rejects(h.A.action('initiate',h.A.jobs()[0],async()=>{}),/未点击/);assert.equal(f.cta.clicks,0);
});
test('v11: unrelated title is never accepted merely because the card is selected',async()=>{
 const h=harness(),f=jobFixture(h,{detailTitle:'编剧助理'});f.title.textContent='编剧-双休';
 await assert.rejects(h.A.action('initiate',h.A.jobs()[0],async()=>{}),/详情标题/);assert.equal(f.cta.clicks,0);
});
test('v11: three-file picker selects displayed index zero, ignores old binding, then sends once',async()=>{
 const h=harness(),f=chooser(h),stages=[];
 const r=await h.A.action('resume',{...expected,resume:{name:'第三份.pdf',meta:''}},async()=>{},async e=>stages.push(e));
 assert.equal(r.verified,true);assert.equal(r.resumeStatus,'sent');assert.equal(r.resumeName,'第一份.pdf');assert.equal(r.resumeSelection,'first');
 assert.deepEqual(f.rows.map(r=>r.clicks),[1,0,0]);assert.equal(f.send.clicks,1);assert.equal(f.open.clicks,1);
 assert.deepEqual(stages.map(x=>x.resumeStage),['opening-picker','submit']);
});
test('v11: existing chooser after native consent continues without reopening or needing a bound file',async()=>{
 const h=harness(),f=chooser(h,{initial:true});const r=await h.A.action('resume',expected,async()=>{});
 assert.equal(r.resumeStatus,'sent');assert.equal(f.open.clicks,0);assert.equal(f.rows[0].clicks,1);assert.equal(f.send.clicks,1);
});
test('v11: picker diagnostic reads exactly three file rows and the actual disabled send control',()=>{
 const h=harness();chooser(h,{initial:true});const x=h.A.inspect().resumePicker;
 assert.equal(x.open,true);assert.equal(x.rows.length,3);assert.equal(x.sendControls.length,1);assert.equal(x.sendControls[0].enabled,false);
 assert.equal(x.closeControls.length,1);assert.equal(h.A.snapshot().resumePickerOpen,true);
});
test('v11: a read-only recovery of opening-picker returns selecting, never sent; submit does not replay',async()=>{
 const h=harness(),f=chooser(h,{initial:true});const r=await h.A.observe('resume',expected,{resumeStage:'opening-picker'});
 assert.equal(r.resumeStatus,'selecting');assert.equal(r.candidate.name,'第一份.pdf');assert.equal(f.send.clicks,0);
 assert.equal((await h.A.observe('resume',expected,{resumeStage:'submit'})).verified,false);assert.equal(f.send.clicks,0);
});
test('v11: first file must actually be selected; no send on missing selection state',async()=>{
 const h=harness(),f=chooser(h,{selected:false});
 await assert.rejects(h.A.action('resume',expected,async()=>{}),/无法确认目标附件已选中/);assert.equal(f.send.clicks,0);assert.equal(f.mod.style.display,'none');
});
test('v11: empty chooser is bounded, not submitted, and can be closed safely',async()=>{
 const h=harness(),f=chooser(h,{files:[]});
 await assert.rejects(h.A.action('resume',expected,async()=>{}),/没有可识别/);assert.equal(f.send.clicks,0);assert.equal(f.mod.style.display,'none');
});
test('v11: pause after row selection vetoes final send',async()=>{
 const h=harness(),f=chooser(h);let stop=false;const click=f.rows[0].onclick;f.rows[0].onclick=()=>{click();stop=true;};
 await assert.rejects(h.A.action('resume',expected,async()=>{if(stop)throw Error('任务已暂停');}),/已暂停/);assert.equal(f.send.clicks,0);
});
test('v11: if visual order changes after row selection, never send a now-nonfirst file',async()=>{
 const h=harness(),f=chooser(h);const click=f.rows[0].onclick;f.rows[0].onclick=()=>{click();f.ul.replaceChildren(f.rows[1],f.rows[0],f.rows[2]);};
 await assert.rejects(h.A.action('resume',expected,async()=>{}),/第一份已发生变化/);assert.equal(f.send.clicks,0);
});
test('v11: no resume may be sent when the chat recipient changes after selection',async()=>{
 const h=harness(),f=chooser(h);const click=f.rows[0].onclick;f.rows[0].onclick=()=>{click();h.document.querySelector('[data-sbl-conversation]').setAttribute('data-sbl-conversation','different');};
 await assert.rejects(h.A.action('resume',expected,async()=>{}),/对象已改变/);assert.equal(f.send.clicks,0);
});
test('v11: unknown questions stay blank and first-file policy does not guess a career from filenames',()=>{
 const c=C.defaults();c.robot.greeting='已确认介绍';c.attachments=[{name:'虚构工具技能.pdf',key:'r'}];
 const p=C.robotPlan({chat:{title:'未知'},messages:[{id:'r',side:'in',text:'请发简历',resumeRequest:true}]},c,{},1);
 assert.deepEqual(p.steps.map(x=>x.kind),['intro','resume']);assert.equal(p.steps.find(x=>x.kind==='resume').text,undefined);assert.equal(c.answers.skills,'');
});
