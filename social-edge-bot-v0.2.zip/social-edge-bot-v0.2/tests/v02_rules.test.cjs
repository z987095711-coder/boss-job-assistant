const test=require('node:test'),assert=require('node:assert/strict'),C=require('../extension/core.js');
const base=()=>{const c=C.defaults();c.robot.greeting='本人确认的介绍';c.answers.skills='已确认的工具技能';return c;};
const snap=messages=>({chat:{key:'chat:x',title:'测试岗位',company:'测试公司'},messages});
const msg=(text,side='in',id='q')=>({id,text,side});
test('v02 defaults: local handoff and system keep-awake on; first file; no timed followups',()=>{
 const c=C.defaults();assert.equal(C.VERSION,'0.2.0');assert.equal(c.settings.autoReplyAfterBatch,true);assert.equal(c.settings.keepAwake,true);assert.equal(c.settings.resumeSelection,'first');assert.equal(c.robot.keepListening,true);assert.ok(c.followups.every(f=>!f.enabled));assert.ok(Object.values(c.answers).every(v=>v===''));
 const disabled=C.cleanConfig({settings:{keepAwake:false,autoReplyAfterBatch:false},robot:{keepListening:false}});assert.equal(disabled.settings.autoReplyAfterBatch,false);assert.equal(disabled.settings.keepAwake,false);assert.equal(disabled.robot.keepListening,false);
});
for(const text of ['抱歉，您的经历不符合岗位要求','对不起，我们无法安排面试','不合适','我们决定选择其他候选人','该岗位已关闭','很遗憾，暂时不考虑'])test('v02 rejection detected: '+text,()=>assert.equal(C.rejectionIntent(text).kind,'soft'));
for(const text of ['抱歉刚看到，会哪些软件？','对不起，回复晚了','不是不符合要求，我需要再确认','并不是您不合适','是不是不符合你的预期？','不好意思，请发一份简历','经验不符合要求也可以培训','不符合我们条件但是可以先沟通']){
 // Last two intentionally contain a real negative qualification; no claim of semantic AI.
 if(text.startsWith('经验')||text.startsWith('不符合'))continue;
 test('v02 apology/negated rejection is not a refusal: '+text,()=>assert.equal(C.rejectionIntent(text).kind,'none'));
}
test('v02 bare apology is uncertain and does not automatically push or fabricate',()=>{const p=C.robotPlan(snap([msg('抱歉')]),base(),{},3,{onlyPending:true});assert.equal(p.needsAnswer,true);assert.equal(p.steps.length,0);});
test('v02 hard stop overrides resume request and apologies',()=>{const p=C.robotPlan(snap([{...msg('对不起，不要再联系我，也不要发简历'),resumeRequest:true}]),base(),{},3,{onlyPending:true});assert.equal(p.hardStop,true);assert.deepEqual(p.steps,[]);});
test('v02 live watch honors explicit pending card even after an own introduction',()=>{
 const c=base(),s=snap([msg('我想要一份您的附件简历'),msg(c.robot.greeting,'out','o')]);s.resumeConsentAvailable=true;
 const p=C.robotPlan(s,c,{introVerified:true},3,{onlyPending:true});assert.deepEqual(p.steps.map(x=>x.kind),['resume']);assert.equal(p.steps[0].requested,true);
 const already=C.robotPlan({...s,resumeReceipt:true},c,{introVerified:true,resumeStatus:'sent'},3,{onlyPending:true});assert.deepEqual(already.steps,[]);
});
test('v02 only-pending watch does not offer resumes or greet old own-last conversations',()=>{const c=base(),p=C.robotPlan(snap([msg('好的'),msg('我的手动答复','out','o')]),c,{},3,{onlyPending:true});assert.deepEqual(p.steps,[]);});
function state(){return {...C.initialState(),status:'running',mode:'live',workflow:'reply',runId:'watch',robot:{continuous:true}};}
test('v02 unknown contacts are discovered only in explicitly authorized continuous workflow',()=>{
 const s=state();C.ingestActivity(s,{rows:[{key:'chat:new',token:'a',lastSide:'in',unread:true,title:'测试职位',company:'测试企业'}]},1000);assert.ok(s.conversations['chat:new']);assert.equal(C.nextQueued(s,2000).chatKey,'chat:new');
 const legacy=C.initialState();C.ingestActivity(legacy,{rows:[{key:'chat:new',token:'a',unread:true}]},1000);assert.equal(Object.keys(legacy.conversations).length,0);
});
test('v02 first read-only inventory inspects own-last cards once but does not requeue own sends',()=>{
 const s=state(),a={rows:[{key:'chat:old',token:'out1',lastSide:'out'}]};C.ingestActivity(s,a,1000);assert.deepEqual(s.replyQueue[0].reasons,['review']);s.replyQueue=[];
 C.ingestActivity(s,a,2000);C.ingestActivity(s,{rows:[{...a.rows[0],token:'out2'}]},3000);assert.equal(s.replyQueue.length,0);
});
test('v02 unread takes priority over read-unanswered and initial own-last inspections',()=>{
 const s=state();C.ingestActivity(s,{rows:[{key:'chat:old',lastSide:'out',token:'a'},{key:'chat:read',lastSide:'in',token:'b'},{key:'chat:unread',lastSide:'in',token:'c',unread:true}]},1000);assert.equal(C.nextQueued(s,2000).chatKey,'chat:unread');s.replyQueue=s.replyQueue.filter(x=>x.chatKey!=='chat:unread');assert.equal(C.nextQueued(s,2000).chatKey,'chat:read');
});
test('v02 observer repeats do not duplicate work, human/manual and closed remain protected',()=>{
 const s=state(),a={rows:[{key:'chat:x',token:'a',lastSide:'in'}]};C.ingestActivity(s,a,1000);for(let i=0;i<30;i++)C.ingestActivity(s,a,1100+i);assert.equal(s.replyQueue.length,1);
 s.conversations['chat:x'].status='manual';C.ingestActivity(s,{rows:[{...a.rows[0],token:'b'}]},2000);assert.equal(C.nextQueued(s,9999),null);
 s.conversations['chat:x'].status='closed';assert.equal(C.nextQueued(s,9999),null);
});
test('v02 untrusted activity cannot seed prototype keys, noncontacts or oversized identity',()=>{const s=state();for(const key of ['__proto__','constructor','prototype','x'.repeat(301),''])C.ingestActivity(s,{rows:[{key,token:'t'}]});C.ingestActivity(s,{rows:[{key:'chat:system',token:'s',system:true}]});assert.equal(Object.keys(s.conversations).length,0);});
