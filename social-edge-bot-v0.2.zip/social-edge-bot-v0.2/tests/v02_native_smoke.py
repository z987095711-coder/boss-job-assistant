"""Attempt native MV3 loading in isolated Chromium. All web traffic blocked; no BOSS account."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,tempfile,time
ROOT=Path(__file__).resolve().parents[1]
report={'version':'0.2.0','mode':'isolated Chromium persistent profile; all web requests blocked','nativeLoaded':False,'realAccount':False,'checks':[]}
try:
 with sync_playwright() as p, tempfile.TemporaryDirectory(prefix='sbl-v02-native-') as profile:
    context=p.chromium.launch_persistent_context(profile,headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-extensions-except='+str(ROOT/'extension'),'--load-extension='+str(ROOT/'extension')])
    context.route('https://**/*',lambda r:r.abort())
    page=context.pages[0] if context.pages else context.new_page()
    try:
        page.goto('chrome://extensions/');page.wait_for_timeout(1000);report['extensionsPageExcerpt']=page.locator('body').inner_text()[:1500]
    except Exception as e:report['extensionsPageError']=str(e).split('\n')[0]
    workers=context.service_workers
    if not workers:
        try:workers=[context.wait_for_event('serviceworker',timeout=6000)]
        except Exception as e:report['loadError']=str(e).split('\n')[0]
    report['workerURLs']=[w.url for w in workers]
    worker=next((w for w in workers if w.url.endswith('/background.mjs')),None)
    if worker:
        report['nativeLoaded']=True
        manifest=worker.evaluate('chrome.runtime.getManifest()');report['manifest']={'name':manifest['name'],'version':manifest['version'],'version_name':manifest.get('version_name')}
        extid=worker.url.split('/')[2];page.goto(f'chrome-extension://{extid}/panel.html');page.wait_for_timeout(1200)
        report['checks'].append({'name':'Native options panel renders six steps','passed':page.locator('#steps button').count()==6})
        report['checks'].append({'name':'Persistent config contains v0.2 defaults','passed':worker.evaluate("chrome.storage.local.get('config').then(d=>d.config.settings.autoReplyAfterBatch&&d.config.settings.keepAwake)")})
        report['checks'].append({'name':'Recurring recovery alarm exists','passed':bool(worker.evaluate("chrome.alarms.get('sbl-tick')"))})
        report['checks'].append({'name':'Power API callable and released (not an OS sleep test)','passed':worker.evaluate("()=>{chrome.power.requestKeepAwake('system');chrome.power.releaseKeepAwake();return true}")})
        page.screenshot(path=str(ROOT/'docs/v02-native-panel.png'),full_page=True)
    else:report['limitation']='No native service worker appeared. Chromium extensions page and load error recorded; no native installation or native runtime behavior claimed.'
    context.close()
except Exception as e:report['error']=str(e)
(ROOT/'tests/v02-native-smoke-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
