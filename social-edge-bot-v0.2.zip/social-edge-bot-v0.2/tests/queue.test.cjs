const test=require('node:test'),assert=require('node:assert/strict'),C=require('../extension/core.js');
function state(){const s=C.initialState();for(const key of ['a','b','c','d'])s.conversations[key]={key,status:'waiting'};return s;}
test('queue: unknown, refused and manual conversations never enter',()=>{
 const s=state();s.conversations.a.status='closed';s.conversations.b.status='manual';
 for(const k of ['a','b','unknown'])C.enqueue(s,k);assert.equal(s.replyQueue.length,0);
});
test('queue: duplicate list observations do not generate duplicate work',()=>{
 const s=state(),a={rows:[{key:'a',token:'one',unread:true}]};
 C.ingestActivity(s,a,100);C.ingestActivity(s,a,200);
 assert.equal(s.replyQueue.length,1);assert.equal(s.replyQueue[0].revision,1);
});
test('queue: list baselines alone do not open all old conversations',()=>{
 const s=state();C.ingestActivity(s,{rows:['a','b','c'].map(key=>({key,token:'old',unread:false}))},100);
 assert.equal(s.replyQueue.length,0);
});
test('queue: incoming changes merge with bounded settling time',()=>{
 const s=state();for(let i=0;i<10;i++)C.ingestActivity(s,{rows:[{key:'a',token:''+i,unread:true}]},100+i*500);
 assert.equal(s.replyQueue.length,1);assert.equal(s.replyQueue[0].dueAt,2600);assert.equal(s.replyQueue[0].revision,10);
});
test('queue: pending replies outrank proactive attachments and followups',()=>{
 const s=state();C.enqueue(s,'a','followup',0);C.enqueue(s,'b','resume',10);C.enqueue(s,'c','message',20);C.enqueue(s,'d','resume-request',30);
 assert.equal(C.nextQueued(s,1000).chatKey,'c');
});
test('queue: finishing an old revision cannot discard a newly arrived message',()=>{
 const s=state();C.enqueue(s,'a','message',0);const task={chatKey:'a',queueRevision:1};
 C.enqueue(s,'a','message',100);C.finishQueued(s,task);
 assert.equal(s.replyQueue.length,1);assert.equal(s.replyQueue[0].revision,2);
 C.finishQueued(s,{chatKey:'a',queueRevision:2});assert.equal(s.replyQueue.length,0);
});
test('queue: active chat inbound change is detected without an unread badge',()=>{
 const s=state();C.ingestActivity(s,{active:{key:'a',token:'in1',hasInbound:true}},100);
 assert.equal(s.replyQueue.length,1);C.finishQueued(s,{chatKey:'a',queueRevision:1});
 C.ingestActivity(s,{active:{key:'a',token:'in1',hasInbound:true}},200);assert.equal(s.replyQueue.length,0);
 C.ingestActivity(s,{active:{key:'a',token:'in2',hasInbound:true}},300);assert.equal(s.replyQueue.length,1);
});
test('queue: new batch keeps pending inbound work and recipient bindings',()=>{
 const s=state();C.enqueue(s,'a','message',100);s.replyStreak=3;
 const n=C.newBatch(s,'live');assert.equal(n.replyQueue[0].chatKey,'a');assert.equal(n.replyStreak,0);assert.equal(n.conversations.a,s.conversations.a);
});
