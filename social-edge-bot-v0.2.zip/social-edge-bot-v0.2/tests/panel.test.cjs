// Execute the actual panel script in a local DOM double; this is not Chromium validation.
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {harness}=require('./dom-harness.cjs');
async function panel(){
 const h=harness(),{document,el,context}=h;
 document.createElement=tag=>el(tag);document.getElementById=id=>document.querySelector('#'+id);
 const body=fs.readFileSync(__dirname+'/../extension/panel.html','utf8').split('<body>')[1].split('</body>')[0],stack=[document.body];
 for(const token of body.matchAll(/<\/?([a-z][\w-]*)\b([^>]*)>/gi)){
  const [full,tag,rest]=token;if(full.startsWith('</')){if(!['input','img','br','meta','link','hr'].includes(tag)&&stack.length>1)stack.pop();continue;}
  const attrs={};for(const a of rest.matchAll(/([\w-]+)(?:="([^"]*)"|='([^']*)')?/g))attrs[a[1]]=a[2]??a[3]??'';
  const e=el(tag,attrs);if('hidden' in attrs)e.hidden=true;if('checked' in attrs)e.checked=true;if('value' in attrs)e.value=attrs.value;
  stack.at(-1).append(e);if(!['input','img','br','meta','link','hr'].includes(tag))stack.push(e);
 }
 const C=context.SBLCore,db={config:C.cleanConfig({profiles:[{name:'视频制作',greeting:'确认介绍',overrides:{}}]}),state:C.initialState()},calls=[];
 context.structuredClone=structuredClone;context.Option=function(label,value){const e=el('option',{},label);e.value=value;return e;};context.setInterval=()=>0;
 context.navigator={clipboard:{writeText:async()=>{}}};context.chrome={runtime:{getURL:p=>'chrome-extension://test/'+p,sendMessage:async m=>{
  calls.push(structuredClone(m));let data={};
  if(m.type==='GET')data=structuredClone(db);
  if(m.type==='TABS')data=[];
  if(m.type==='SAVE'){db.config=C.cleanConfig(m.config);data={config:db.config};}
  if(m.type==='START_REPLY'){db.config=C.cleanConfig(m.config);db.state.workflow='reply';db.state.mode=m.dryRun?'reply-preview':'live';}
  return {ok:true,data};
 }}};
 vm.runInContext(fs.readFileSync(__dirname+'/../extension/panel.js','utf8'),context);await new Promise(r=>setImmediate(r));
 const by=id=>document.getElementById(id),click=async id=>{for(const fn of by(id).listeners.click||[])await fn({target:by(id)});};
 return {...h,db,calls,by,click};
}
test('panel: actual six-step script initializes all controls without missing DOM IDs',async()=>{
 const h=await panel();assert.equal(h.by('steps').children.length,6);assert.equal(h.by('step3').hidden,false);assert.equal(h.by('questions').children.filter(x=>x.tagName==='LABEL').length,18);assert.equal(h.by('answer-education').value,'');assert.ok(!h.by('notice').textContent);
});
test('panel: one click starts 237 replies with no preview/inspection confirmation',async()=>{
 const h=await panel();h.by('replyLimit').value='237';await h.click('startReply');const start=h.calls.find(x=>x.type==='START_REPLY');assert.ok(start,h.by('notice').textContent);assert.equal(start.config.robot.limit,237);assert.equal(start.consent,true);assert.equal(start.dryRun,false);assert.ok(!h.calls.some(x=>x.type==='INSPECT'));
});
test('panel: outreach starts without choosing a tab and keeps batch listening off by default',async()=>{
 const h=await panel();h.by('batchLimit').value='10';h.by('mode').value='live';await h.click('start');const start=h.calls.find(x=>x.type==='START');assert.ok(start,h.by('notice').textContent);assert.equal(start.consent,true);assert.equal(start.mode,'live');assert.equal(h.db.config.settings.keepListeningAfterBatch,false);assert.ok(!h.calls.some(x=>x.type==='INSPECT'));
});
test('panel: dry-run button explicitly uses non-sending mode',async()=>{
 const h=await panel();await h.click('previewReply');assert.equal(h.calls.find(x=>x.type==='START_REPLY').dryRun,true);
});
test('panel: direction and industry answers survive reading forms and JSON import',async()=>{
 const h=await panel();h.by('aiJson').value=JSON.stringify({answers:{skills:'通用真实工具'},directionAnswers:[{experience:'方向真实项目'}],industries:[{name:'影视',keywords:['影视','剪辑'],answers:{skills:'行业真实工具'}}]});await h.click('importAI');assert.equal(h.db.config.answers.skills,'通用真实工具');assert.equal(h.db.config.profiles[0].overrides.experience,'方向真实项目');assert.equal(h.db.config.industries[0].answers.skills,'行业真实工具');
 await h.click('save');assert.equal(h.db.config.industries[0].keywords.length,2);assert.equal(h.db.config.answers.salary,'');
});
test('panel: add-industry control creates editable fields that are saved',async()=>{
 const h=await panel();await h.click('addIndustry');const card=h.by('industryRules').lastElementChild;assert.ok(card,h.by('notice').textContent);card.querySelector('[data-industry-name]').value='电商';card.querySelector('[data-industry-keywords]').value='电商，店铺';card.querySelector('[data-industry-answer="projectRole"]').value='本人负责的真实部分';await h.click('save');assert.equal(h.db.config.industries[0].answers.projectRole,'本人负责的真实部分');
});
test('panel: invalid count does not silently send a different batch quantity',async()=>{
 const h=await panel();h.by('replyLimit').value='301';await h.click('startReply');assert.ok(!h.calls.some(x=>x.type==='START_REPLY'));assert.match(h.by('notice').textContent,/1–300/);
});
test('v10 panel: idle permission checkbox is saved and displayed independently of old batch listening',async()=>{
 const h=await panel();assert.equal(h.by('idleReplyEnabled').checked,true);h.by('idleReplyEnabled').checked=false;await h.click('save');assert.equal(h.db.config.settings.idleReplyEnabled,false);assert.equal(h.db.config.settings.keepListeningAfterBatch,false);
});
test('v10 panel: automatic workflow transition shows step six; repeated refresh does not hijack a chosen step',async()=>{
 const h=await panel();vm.runInContext("lastWorkflow='outreach';state.workflow='reply';renderState();",h.context);assert.equal(h.by('step6').hidden,false);vm.runInContext("showStep(4);renderState();",h.context);assert.equal(h.by('step4').hidden,false);
});
