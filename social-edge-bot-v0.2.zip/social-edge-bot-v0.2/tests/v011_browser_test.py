"""v11: rendered Chromium DOM + actual worker/content authorization bridge with mocked chrome APIs.
Fixtures run on about:blank; all external requests are aborted. No native extension installation or real account is used.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,re,base64
ROOT=Path(__file__).resolve().parents[1]
results=[]
def ok(name,v):
    if not v: raise AssertionError(name)
    results.append({'name':name,'passed':True});print('PASS',name,flush=True)
STYLE='''<style>body{font:16px sans-serif;margin:24px}.job-card-box{padding:20px;border:1px solid #ccc}.job-detail-box{margin:20px;padding:24px;background:#eef}button,a{cursor:pointer;padding:8px}.layer{position:fixed;inset:80px auto auto 250px;width:570px;background:white;padding:30px;box-shadow:0 0 0 800px #5558}li.list-item{display:flex;padding:18px;cursor:pointer;border:2px solid transparent}.list-item.active{border-color:#0bb}.resume-name{display:inline-block;width:320px}header{display:flex;justify-content:space-between}footer{text-align:right}#chat-input{min-height:60px;border:1px solid #aaa}.closed{display:none}</style>'''
JOB=STYLE+'''<ul class="rec-job-list"><div class="job-card-wrap active"><li class="job-card-box"><div class="job-info"><div class="job-title"><a class="job-name" href="/job_detail/test-job.html">编剧-双休</a><span class="job-salary">9-14K</span></div></div><div class="job-card-footer"><span class="company-location">测试传媒</span></div></li></div></ul>
<div class="job-detail-container"><div class="job-detail-box"><div class="job-detail-header"><div class="job-header-info"><div class="job-detail-info"><span class="job-name">编剧</span></div></div><div class="job-detail-op"><a class="op-btn op-btn-chat">立即沟通</a></div></div></div></div><div class="greet-boss-dialog" style="display:none">已向BOSS发送消息<a>继续沟通</a></div>
<script>window.actions=[];document.querySelector('.op-btn-chat').onclick=()=>{actions.push({event:'initiate',at:Date.now()});document.querySelector('.greet-boss-dialog').style.display='block'};</script>'''
RESUME=STYLE+'''<div data-sbl-conversation="hr-test" class="active" data-sbl-chat-company="测试传媒"></div><div data-sbl-chat data-job-id="test-job"><span data-sbl-chat-job>编剧</span><span data-sbl-chat-company>测试传媒</span><div id="msgs"><div data-sbl-message data-sbl-side="in" data-mid="request"><span>我想要一份您的附件简历，您是否同意</span><span class="card-btn">同意</span></div></div><div class="message-controls"><div class="chat-im chat-editor"><div class="chat-controls"><div class="toolbar-btn-content"><div class="toolbar-btn tooltip tooltip-top">发简历</div></div></div><div id="chat-input" contenteditable="true"></div><button data-sbl-send>发送</button></div></div></div>
<div class="layer" id="picker" style="display:none"><header><h3>请选择要发送的简历</h3><button aria-label="关闭">×</button></header><div class="dialog-body"><p>已上传附件</p><ul class="resume-list"><li class="list-item"><div class="item-body"><div><span class="resume-name">第一份.pdf</span><a class="preview">预览</a></div><p>更新于2026.08.01 10:00 123.4KB</p></div></li><li class="list-item"><div class="item-body"><div><span class="resume-name">第二份.pdf</span><a class="preview">预览</a></div><p>更新于2026.07.22 10:00 234.5KB</p></div></li><li class="list-item"><div class="item-body"><div><span class="resume-name">第三份.pdf</span><a class="preview">预览</a></div><p>更新于2026.07.01 10:00 345.6KB</p></div></li></ul></div><footer><a>管理附件</a><button id="send-file" disabled>发送</button></footer></div>
<div role="dialog" id="confirm-file" style="display:none"><p>确认投递简历 <span id="confirm-name"></span></p><button id="confirm-yes">确认投递</button><button id="confirm-no">取消</button></div>
<script>window.actions=[];window.sentFiles=[];window.selectedFile='';window.selectionDelay=200;window.confirmRequired=false;window.noReceipt=false;
const picker=document.querySelector('#picker');document.querySelector('.toolbar-btn').onclick=()=>{actions.push('toolbar');picker.style.display='block';};document.querySelector('.card-btn').onclick=()=>{actions.push('agree');picker.style.display='block';};picker.querySelector('[aria-label="关闭"]').onclick=()=>{actions.push('close');picker.style.display='none';};
for(const [i,row] of [...picker.querySelectorAll('.list-item')].entries())row.onclick=()=>{actions.push('file:'+i);setTimeout(()=>{for(const r of picker.querySelectorAll('.list-item'))r.classList.remove('active');row.classList.add('active');selectedFile=row.querySelector('.resume-name').textContent;document.querySelector('#send-file').disabled=false;},selectionDelay)};
function receipt(){if(noReceipt)return;const el=document.createElement('div');el.dataset.sblMessage='';el.dataset.sblSide='system';el.textContent='您的附件简历 '+selectedFile+' 已发送给Boss';document.querySelector('#msgs').append(el);}
document.querySelector('#send-file').onclick=()=>{actions.push('submit');sentFiles.push(selectedFile);picker.style.display='none';if(confirmRequired){document.querySelector('#confirm-name').textContent=selectedFile;document.querySelector('#confirm-file').style.display='block';}else receipt();};
document.querySelector('#confirm-yes').onclick=()=>{actions.push('confirm');document.querySelector('#confirm-file').style.display='none';receipt();};document.querySelector('#confirm-no').onclick=()=>{document.querySelector('#confirm-file').style.display='none';};
</script>'''
PAY={'chatKey':'chat:hr-test','jobKey':'job:test-job','title':'编剧','company':'测试传媒','robot':True,'resumeSelection':'first','allowDefaultResume':True}
CHROME=r'''(()=>{
 const noop=()=>{},event=()=>({addListener:noop}),handlers=[];
 // about:blank is not secure; use deterministic operation IDs in this mock only.
 if(!crypto.randomUUID){let id=0;crypto.randomUUID=()=> 'fixture-operation-'+(++id);}
 window.db={};window.journal=[];
 const clone=v=>v===undefined?undefined:structuredClone(v);
 const dispatch=(fn,m,sender)=>new Promise((resolve,reject)=>{let done=false;const timer=setTimeout(()=>{if(!done)reject(Error('mock runtime timeout '+m.type))},35000);fn(m,sender,r=>{done=true;clearTimeout(timer);resolve(r)});});
 window.chrome={runtime:{id:'test',getURL:p=>'chrome-extension://test/'+p,onInstalled:event(),onStartup:event(),onMessage:{addListener:f=>handlers.push(f)},sendMessage:async m=>{if(m.type==='ACTION_STAGE')journal.push(clone(m.evidence));return dispatch(handlers[0],m,{id:'test',url:'https://www.zhipin.com/web/geek/chat',tab:{id:1}});}},
 storage:{local:{get:async keys=>{const out={};for(const k of keys)if(k in db)out[k]=clone(db[k]);return out;},set:async o=>Object.assign(db,clone(o)),setAccessLevel:async()=>{}}},
 sidePanel:{setPanelBehavior:async()=>{}},action:{setBadgeText:async()=>{},setBadgeBackgroundColor:async()=>{}},power:{releaseKeepAwake:noop,requestKeepAwake:noop},
 alarms:{get:async()=>({}),create:async()=>{},onAlarm:event()},idle:{setDetectionInterval:noop,onStateChanged:event(),queryState:async()=> 'active'},scripting:{executeScript:async()=>{}},
 tabs:{onCreated:event(),get:async id=>{if(id!==1)throw Error('closed');return {id:1,url:'https://www.zhipin.com/web/geek/chat'}},query:async()=>[{id:1,url:'https://www.zhipin.com/web/geek/chat'}],sendMessage:async(id,m)=>dispatch(handlers[1],m,{id:'test'}),update:async()=>({id:1,url:'https://www.zhipin.com/web/geek/chat'})}};
})()'''
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1200,'height':900})
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.route('https://**/*',lambda r:r.abort())
    def load(html,route='chat',version=ROOT):
        page.goto('about:blank');page.set_content(html)
        for file in ['core.js','adapter.js']:page.add_script_tag(content=(version/'extension'/file).read_text())
    # The actual old adapter demonstrably fails the user's decorated title.
    old=ROOT.parent/'social-edge-bot-v0.1.10'
    if old.exists():
        load(JOB,'jobs',old);page.evaluate("SBLAdapter.setSelectors({jobCards:'.job-card-box',jobCompany:'.company-location'})")
        r=page.evaluate("SBLAdapter.action('initiate',SBLAdapter.jobs()[0],async()=>{}).then(r=>r).catch(e=>({error:e.message}))")
        ok('Old v0.1.10 reproduces exact-title rejection without clicking CTA', '详情标题' in r.get('error','') and page.evaluate('actions.length')==0)
    load(JOB,'jobs');page.evaluate("SBLAdapter.setSelectors({jobCards:'.job-card-box',jobCompany:'.company-location'})")
    r=page.evaluate("SBLAdapter.action('initiate',SBLAdapter.jobs()[0],async()=>{})")
    ok('v11 accepts selected 编剧-双休 / 编剧 and clicks one CTA',r.get('verified') and page.evaluate('actions.length')==1)
    load(JOB,'jobs');page.evaluate("""()=>{SBLAdapter.setSelectors({jobCards:'.job-card-box',jobCompany:'.company-location'});document.querySelector('.job-detail-info .job-name').textContent='上一份岗位';document.querySelector('.job-card-box').onclick=()=>{window.cardClickedAt=Date.now();setTimeout(()=>{document.querySelector('.job-detail-info .job-name').textContent='编剧';window.detailUpdatedAt=Date.now()},1400)};}""")
    r=page.evaluate("(async()=>{const j=SBLAdapter.jobs()[0];await SBLAdapter.navigate('job',{key:j.key,force:true});return await SBLAdapter.action('initiate',j,async()=>{});})()")
    ok('Delayed detail rendering waits for the NEW title and stable pane before contact',r['verified'] and page.evaluate('actions[0].at>detailUpdatedAt+650 && actions[0].at>cardClickedAt+1000'))
    load(RESUME);page.evaluate("document.querySelector('#picker').style.display='block'")
    d=page.evaluate('SBLAdapter.inspect().resumePicker')
    ok('Native-shaped header/body/footer resolve as one chooser even while send is disabled',d['open'] and len(d['rows'])==3 and len(d['sendControls'])==1 and not d['sendControls'][0]['enabled'])
    page.screenshot(path=str(ROOT/'docs/v011-picker-fixture.png'))
    r=page.evaluate("p=>SBLAdapter.action('resume',p,async()=>{})",PAY)
    ok('Already-open three-file chooser sends first file with NO imported binding',r['resumeStatus']=='sent' and r['resumeName']=='第一份.pdf')
    ok('First-file execution did not reopen chooser, click preview, or select other files',page.evaluate("JSON.stringify(actions)==JSON.stringify(['file:0','submit']) && sentFiles.length===1"))
    load(RESUME)
    r=page.evaluate("p=>SBLAdapter.action('resume',p,async()=>{})",{**PAY,'resume':{'name':'第三份.pdf'}})
    ok('First-file mode overrides old third-file binding, explicitly selects then sends',r['resumeName']=='第一份.pdf' and page.evaluate("JSON.stringify(actions)==JSON.stringify(['toolbar','file:0','submit'])"))
    load(RESUME)
    r=page.evaluate("p=>SBLAdapter.action('resume',p,async()=>{})",{**PAY,'resumeSelection':'bound','resume':{'name':'第二份.pdf'}})
    ok('Explicit strict-bound option still sends requested second file, not first',r['resumeName']=='第二份.pdf' and page.evaluate("sentFiles[0]==='第二份.pdf'"))
    load(RESUME)
    r=page.evaluate("p=>SBLAdapter.action('resumeConsent',p,async()=>{})",PAY)
    ok('Native consent opening a three-file chooser is selecting, not sent',r['resumeStatus']=='selecting' and r['candidate']['name']=='第一份.pdf' and page.evaluate('sentFiles.length')==0)
    r=page.evaluate("p=>SBLAdapter.action('resume',p,async()=>{})",PAY)
    ok('Consent then first-file continuation completes without modal-block deadlock',r['resumeStatus']=='sent' and page.evaluate("JSON.stringify(actions)==JSON.stringify(['agree','file:0','submit'])"))
    # Exercise the actual content.js -> worker ACTION_STAGE/ALLOW -> adapter, not a no-op callback.
    def worker_bridge(confirm=False):
        load(RESUME);page.evaluate(CHROME);page.add_script_tag(content=(ROOT/'extension/robot.js').read_text())
        source=(ROOT/'extension/background.mjs').read_text();source=re.sub(r"^import .*?;\s*",'',source,flags=re.M)
        page.add_script_tag(content=source);page.add_script_tag(content=(ROOT/'extension/content.js').read_text())
        page.evaluate("""()=>{db.config=SBLCore.defaults();db.state={...SBLCore.initialState(),status:'running',mode:'live',runId:'browser-fixture',epoch:1,workflow:'outreach',jobTabId:1,chatTabId:1,task:{phase:'monitor_read',chatKey:'chat:hr-test'}};ticking=true;}""")
        if confirm:page.evaluate('confirmRequired=true')
        return page.evaluate("""async p=>{const s=structuredClone(db.state);await action(s,1,'resume',p,(st,r)=>{st.fixtureResult=r;st.status='paused'});return {result:db.state.fixtureResult,pending:db.state.pending,reason:db.state.reason,journal:journal,actions:actions,files:sentFiles}}""",PAY)
    r=worker_bridge()
    ok('Actual worker + content authorization bridge allows opening-picker then submit',r.get('result',{}).get('resumeStatus')=='sent' and [s['resumeStage'] for s in r['journal']]==['opening-picker','submit'])
    ok('Real extension source clears pending operation after one synthetic attachment delivery',r['pending'] is None and r['files']==['第一份.pdf'])
    r=worker_bridge(True)
    ok('Actual journal handles distinct opening, submit, and confirmation exactly once',[s['resumeStage'] for s in r['journal']]==['opening-picker','submit','confirm'] and r.get('result',{}).get('resumeStatus')=='sent')
    ok('Actual callback bridge never treats selector consent as attachment delivery',r['files']==['第一份.pdf'] and r['actions']==['toolbar','file:0','submit','confirm'])
    # User pause is checked through real runtime ALLOW, not merely a no-op guard.
    load(RESUME);page.evaluate("""()=>{const el=document.querySelector('.list-item'),original=el.onclick;el.onclick=()=>{original();document.querySelector('[data-sbl-conversation]').dataset.sblConversation='changed';};}""")
    r=page.evaluate("p=>SBLAdapter.action('resume',p,async()=>{}).catch(e=>({error:e.message}))",PAY)
    ok('Recipient switch during file selection prevents final submission', '对象已改变' in r.get('error','') and page.evaluate('sentFiles.length')==0)
    ok('No uncaught Chromium page errors across DOM and actual-runtime bridge tests',not errors)
    browser.close()
report={'environment':'Actual Chromium DOM; actual adapter/core/worker/content source; mock chrome APIs, about:blank synthetic pages with external requests blocked; no native extension install or live BOSS account', 'passed':len(results),'total':len(results),'tests':results}
(ROOT/'tests/v011-browser-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'passed':len(results),'total':len(results)}),flush=True)
